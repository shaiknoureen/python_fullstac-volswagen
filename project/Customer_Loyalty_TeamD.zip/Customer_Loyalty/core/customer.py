from datetime import datetime
 
class Customer:
    _customer_count = 0  # class variable
 
    def __init__(self, customer_id, name):
        if not Customer.validate_customer_id(customer_id):
            raise ValueError("Invalid customer ID")
 
        self.customer_id = customer_id
        self.name = name
        self._points_balance = 0  # encapsulated
        self.orders = []
 
        Customer._customer_count += 1
 
    # Encapsulation via property
    @property
    def points_balance(self):
        return self._points_balance
 
    def add_order(self, order):
        self.orders.append(order)
        self._points_balance += self._calculate_rewards(order.amount)
 
    # Private method
    def _calculate_rewards(self, amount):
        return int(amount * 0.1)
 
    # Class method
    @classmethod
    def total_customers(cls):
        return cls._customer_count
 
    # Static method
    @staticmethod
    def validate_customer_id(customer_id):
        return isinstance(customer_id, str) and len(customer_id) >= 4