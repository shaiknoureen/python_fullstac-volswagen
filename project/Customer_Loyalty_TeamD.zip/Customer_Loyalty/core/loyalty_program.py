class LoyaltyProgram:
    TIERS = {
        "Silver": 0,
        "Gold": 500,
        "Platinum": 1000
    }
 
    MULTIPLIERS = {
        "Silver": 1.0,
        "Gold": 1.5,
        "Platinum": 2.0
    }
 
    @staticmethod
    def get_tier(points):
        if points >= LoyaltyProgram.TIERS["Platinum"]:
            return "Platinum"
        elif points >= LoyaltyProgram.TIERS["Gold"]:
            return "Gold"
        return "Silver"
 
    @staticmethod
    def calculate_points(amount, tier):
        base_points = amount * 0.1
        return int(base_points * LoyaltyProgram.MULTIPLIERS[tier])