from functools import wraps
from datetime import datetime
 
def log_purchase(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        result = func(*args, **kwargs)
        print(f"[LOG] Purchase recorded at {datetime.now()}")
        return result
    return wrapper