from core.customer import Customer
from core.loyalty_program import LoyaltyProgram
 
class PremiumCustomer(Customer):
 
    def _calculate_rewards(self, amount):
        tier = LoyaltyProgram.get_tier(self.points_balance)
        return LoyaltyProgram.calculate_points(amount, tier)