from datetime import datetime
from core.logger import log_purchase
 
class Order:
    def __init__(self, amount):
        self.amount = amount
        self.timestamp = datetime.now()
 
    @log_purchase
    def process(self):
        return {
            "amount": self.amount,
            "timestamp": self.timestamp
        }