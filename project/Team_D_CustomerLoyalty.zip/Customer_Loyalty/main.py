from core.customer import Customer
from core.premium_customer import PremiumCustomer
from core.order import Order
 
customer = Customer("C001", "John")
premium = PremiumCustomer("P001", "Emma")
 
order1 = Order(300)
order2 = Order(700)
 
customer.add_order(order1)
premium.add_order(order2)
 
print(customer.name, customer.points_balance)
print(premium.name, premium.points_balance)
print("Total customers:", Customer.total_customers())