"""
Customer Billing & Subscription Management System
"""

import csv
import os
import json
import time
import random
import webbrowser
from datetime import datetime
from functools import reduce
import tkinter as tk
from tkinter import messagebox, simpledialog, ttk

# ============================================================================
# VARIABLE SCOPE - Global configuration (Topic 6)
# ============================================================================

# Subscription Plans
PLANS = {
    "basic": {"monthly": 99, "annual": 999},
    "premium": {"monthly": 199, "annual": 1999},
    "elite": {"monthly": 299, "annual": 2999}
}

# Tax Rates by Region
TAX_RATES = {
    "IN": 18,
    "US": 8.5,
    "UK": 20
}

# LAMBDA FUNCTIONS for discount calculations (Topic 5)
DISCOUNT_RULES = {
    "student": lambda amount: amount * 0.15,
    "senior": lambda amount: amount * 0.10,
    "loyalty": lambda amount: amount * 0.12,
    "bulk": lambda amount: amount * 0.20
}


# ============================================================================
# TOPIC 2 & 3 & 4: Type Conversion + Functions + **kwargs
# ============================================================================

def create_customer(name, email, region, **kwargs):
    """
    Create customer with flexible additional attributes
    Topic 2: Type conversion for validation
    Topic 4: **kwargs for flexible parameters
    """
    # TYPE CONVERSION - Convert and validate inputs
    try:
        name = str(name).strip()
        email = str(email).lower().strip()
        region = str(region).upper()
        
        if not name or not email:
            raise ValueError("Name and email cannot be empty")
            
    except Exception as e:
        print(f"Error: Invalid customer data - {e}")
        return None
    
    customer = {
        "name": name,
        "email": email,
        "region": region,
        "plan": None,
        "billing_type": None,
        "quantity": 1
    }
    
    # Add any additional attributes from **kwargs
    customer.update(kwargs)
    
    return customer


# ============================================================================
# TOPIC 2 & 4 & 7: Type Conversion + *args + Exception Handling with else
# ============================================================================

def select_plan(customer, plan_name, billing_type="monthly", quantity=1, *add_ons):
    """
    Select subscription plan with validation
    Topic 2: Type conversion for quantity
    Topic 4: *args for additional add-ons
    Topic 7: Exception handling with else clause
    """
    try:
        # TYPE CONVERSION - Ensure correct types
        plan_name = str(plan_name).lower()
        billing_type = str(billing_type).lower()
        quantity = int(quantity)  # Convert to integer
        
        # Validation
        if plan_name not in PLANS:
            raise ValueError(f"Plan '{plan_name}' not available")
        
        if billing_type not in ["monthly", "annual"]:
            raise ValueError("Billing type must be 'monthly' or 'annual'")
        
        if quantity < 1:
            raise ValueError("Quantity must be at least 1")
            
    except ValueError as e:
        print(f"❌ Error: {e}")
        return False
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        return False
    else:
        # SUCCESS - This runs only if no exception occurred (Topic 7)
        customer["plan"] = plan_name
        customer["billing_type"] = billing_type
        customer["quantity"] = quantity
        customer["price"] = PLANS[plan_name][billing_type]
        customer["add_ons"] = list(add_ons)  # Store additional items from *args
        print(f"✓ Plan selected: {plan_name} ({billing_type}) x{quantity}")
        if add_ons:
            print(f"  Add-ons: {', '.join(add_ons)}")
        return True


# ============================================================================
# TOPIC 1: Math Operators & Expressions
# ============================================================================

def calculate_bill(customer):
    """
    Calculate bill using math operators
    Topic 1: Math operators (+, -, *, /, %, **)
    """
    # MATH OPERATORS - Calculate base amount
    price = customer["price"]
    quantity = customer["quantity"]
    
    # Multiplication for base
    base_amount = price * quantity
    
    # Add add-on costs if any
    add_on_cost = 0
    if customer.get("add_ons"):
        # Each add-on costs 10% of base price
        add_on_cost = len(customer["add_ons"]) * (price * 0.10)
    
    # Total base with add-ons (Addition)
    total_base = base_amount + add_on_cost
    
    # Apply discount if exists
    discount_amount = customer.get("discount_amount", 0)
    
    # Subtraction for discount
    subtotal = total_base - discount_amount
    
    # Store calculations
    customer["base_amount"] = base_amount
    customer["add_on_cost"] = add_on_cost
    customer["total_base"] = total_base
    customer["subtotal"] = subtotal
    
    return subtotal


# ============================================================================
# TOPIC 4 & 5: *args/**kwargs + Lambda/Map/Filter/Reduce
# ============================================================================

def apply_discount(customer, *discount_codes, **custom_discounts):
    """
    Apply multiple discounts using lambda/map/reduce
    Topic 4: *args for multiple discount codes, **kwargs for custom discounts
    Topic 5: Lambda, map, filter, reduce for processing
    """
    base = customer.get("total_base", customer["price"] * customer["quantity"])
    
    if not discount_codes and not custom_discounts:
        customer["discount_amount"] = 0
        return
    
    # MAP - Apply lambda to calculate each discount (Topic 5)
    discount_amounts = list(map(
        lambda code: DISCOUNT_RULES.get(code, lambda x: 0)(base),
        discount_codes
    ))
    
    # Add custom discounts from **kwargs
    for discount_name, discount_percent in custom_discounts.items():
        discount_amounts.append(base * (float(discount_percent) / 100))
    
    # FILTER - Remove zero discounts (Topic 5)
    valid_discounts = list(filter(lambda x: x > 0, discount_amounts))
    
    # REDUCE - Sum all discounts (Topic 5)
    if valid_discounts:
        total_discount = reduce(lambda x, y: x + y, valid_discounts)
        # Cap at 50% maximum
        max_discount = base * 0.50
        total_discount = min(total_discount, max_discount)
    else:
        total_discount = 0
    
    customer["discount_codes"] = list(discount_codes)
    customer["custom_discounts"] = custom_discounts
    customer["discount_amount"] = total_discount
    
    if total_discount > 0:
        discount_percent = (total_discount / base) * 100
        print(f"✓ Total discount: {discount_percent:.1f}% (₹{total_discount:.2f})")


# ============================================================================
# TOPIC 1 & 6: Math Operators + Variable Scope
# ============================================================================

def apply_tax(customer):
    """
    Apply tax rules using variable scope
    Topic 1: Math operators for tax calculation
    Topic 6: Variable scope - access global TAX_RATES
    """
    # VARIABLE SCOPE - Access global TAX_RATES dictionary
    region = customer["region"]
    tax_rate = TAX_RATES.get(region, 10)  # Default 10% if region not found
    
    customer["tax_rate"] = tax_rate
    
    subtotal = customer.get("subtotal", 0)
    
    # MATH OPERATORS - Division and multiplication for percentage
    tax_amount = subtotal * (tax_rate / 100)
    
    # Addition for final total
    total_amount = subtotal + tax_amount
    
    customer["tax_amount"] = tax_amount
    customer["total_amount"] = total_amount


# ============================================================================
# PDF OPENER - Auto open PDF in default viewer
# ============================================================================

def open_pdf(pdf_file):
    """Open PDF invoice automatically in default viewer"""
    try:
        webbrowser.open('file://' + os.path.abspath(pdf_file))
        print("🚀 Opening PDF invoice...")
        return True
    except Exception as e:
        print(f"⚠️  Could not auto-open PDF: {e}")
        print(f"📄 Please open manually: {pdf_file}")
        return False


# ============================================================================
# PDF GENERATION - Using only standard library (no external dependencies)
# ============================================================================

def create_invoice_pdf(customer):
    """
    Generate a valid PDF invoice using standard library only
    """
    # ENSURE BILLING DATA EXISTS - Calculate if missing
    if 'base_amount' not in customer:
        calculate_bill(customer)
    if 'tax_amount' not in customer:
        apply_tax(customer)
    
    pdf_filename = f"invoice_{customer['invoice_id']}.pdf"
    
    try:
        from io import BytesIO
        
        # Build PDF content stream first
        content_lines = []
        
        # Draw border
        content_lines.append("0.5 w")
        content_lines.append("40 40 532 712 re S")
        
        # Header box
        content_lines.append("0.9 0.9 0.9 rg 50 700 512 40 re f")
        content_lines.append("0 0 0 RG 50 700 512 40 re S")
        
        # Title
        content_lines.append("BT /F1 24 Tf 0 0 0.5 rg 220 714 Td (INVOICE) Tj ET")
        
        # Invoice details
        content_lines.append("BT /F2 9 Tf 0 0 0 rg 60 680 Td")
        content_lines.append(f"(Invoice #: {customer['invoice_id']}) Tj ET")
        
        content_lines.append("BT /F2 9 Tf 420 680 Td")
        date_str = customer['date'].replace('(', '').replace(')', '')
        content_lines.append(f"(Date: {date_str}) Tj ET")
        
        # Customer Details Section
        content_lines.append("0.2 0.4 0.6 rg 50 640 512 20 re f")
        content_lines.append("BT /F1 12 Tf 1 1 1 rg 60 646 Td (CUSTOMER DETAILS) Tj ET")
        
        # Customer info
        name_clean = customer['name'].replace('(', '').replace(')', '')
        email_clean = customer['email'].replace('(', '').replace(')', '')
        
        content_lines.append("BT /F2 10 Tf 0 0 0 rg 60 620 Td")
        content_lines.append(f"(Name: {name_clean}) Tj ET")
        content_lines.append("BT /F2 10 Tf 60 605 Td")
        content_lines.append(f"(Email: {email_clean}) Tj ET")
        content_lines.append("BT /F2 10 Tf 60 590 Td")
        content_lines.append(f"(Region: {customer['region']}) Tj ET")
        
        # Subscription Section
        content_lines.append("0.2 0.4 0.6 rg 50 560 512 20 re f")
        content_lines.append("BT /F1 12 Tf 1 1 1 rg 60 566 Td (SUBSCRIPTION DETAILS) Tj ET")
        
        content_lines.append("BT /F2 10 Tf 0 0 0 rg 60 540 Td")
        content_lines.append(f"(Plan: {customer['plan'].upper()}) Tj")
        content_lines.append(f"200 540 Td (Billing: {customer['billing_type'].title()}) Tj")
        content_lines.append(f"350 540 Td (Qty: {customer['quantity']}) Tj ET")
        
        # Billing Breakdown
        content_lines.append("0.2 0.4 0.6 rg 50 510 512 20 re f")
        content_lines.append("BT /F1 12 Tf 1 1 1 rg 60 516 Td (BILLING BREAKDOWN) Tj ET")
        
        y = 490
        items = [
            ("Base Amount", f"Rs. {customer['base_amount']:.2f}"),
            ("Add-ons Cost", f"Rs. {customer.get('add_on_cost', 0):.2f}"),
            ("Discount", f"-Rs. {customer.get('discount_amount', 0):.2f}"),
        ]
        
        for label, value in items:
            content_lines.append(f"BT /F2 10 Tf 0 0 0 rg 60 {y} Td ({label}) Tj ET")
            content_lines.append(f"BT /F2 10 Tf 450 {y} Td ({value}) Tj ET")
            y -= 15
        
        # Line
        y -= 5
        content_lines.append(f"60 {y} m 552 {y} l S")
        
        # Subtotal
        y -= 15
        content_lines.append(f"BT /F1 10 Tf 0 0 0 rg 60 {y} Td (Subtotal) Tj ET")
        content_lines.append(f"BT /F1 10 Tf 450 {y} Td (Rs. {customer['subtotal']:.2f}) Tj ET")
        
        # Tax
        y -= 15
        content_lines.append(f"BT /F2 10 Tf 0 0 0 rg 60 {y} Td (Tax ({customer['tax_rate']}%)) Tj ET")
        content_lines.append(f"BT /F2 10 Tf 450 {y} Td (Rs. {customer['tax_amount']:.2f}) Tj ET")
        
        # Total line
        y -= 10
        content_lines.append(f"2 w 60 {y} m 552 {y} l S 0.5 w")
        
        # Total
        y -= 20
        content_lines.append(f"0.95 0.95 0.7 rg 50 {y-5} 512 25 re f")
        content_lines.append(f"BT /F1 14 Tf 0 0 0 rg 60 {y} Td (TOTAL AMOUNT) Tj ET")
        content_lines.append(f"BT /F1 14 Tf 0 0.5 0 rg 430 {y} Td (Rs. {customer['total_amount']:.2f}) Tj ET")
        
        # Payment status
        if customer.get('payment_status'):
            y -= 40
            status = customer['payment_status']
            status_color = "0 0.6 0" if status == "PAID" else "0.8 0 0"
            content_lines.append(f"BT /F1 11 Tf {status_color} rg 60 {y} Td (Payment Status: {status}) Tj ET")
            
            if customer.get('transaction_id'):
                y -= 15
                content_lines.append(f"BT /F2 9 Tf 0 0 0 rg 60 {y} Td (Transaction ID: {customer['transaction_id']}) Tj ET")
        
        # Footer
        content_lines.append("BT /F3 10 Tf 0.3 0.3 0.3 rg 170 60 Td (Thank you for your business!) Tj ET")
        
        content_stream = '\n'.join(content_lines)
        
        # Build PDF with proper structure
        pdf_objects = []
        
        # Object 1: Catalog
        pdf_objects.append("1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj")
        
        # Object 2: Pages
        pdf_objects.append("2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj")
        
        # Object 3: Page
        pdf_objects.append(
            "3 0 obj\n"
            "<< /Type /Page /Parent 2 0 R\n"
            "/Resources << /Font <<\n"
            "/F1 << /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>\n"
            "/F2 << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\n"
            "/F3 << /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Oblique >>\n"
            ">> >>\n"
            "/MediaBox [0 0 612 792]\n"
            "/Contents 4 0 R >>\n"
            "endobj"
        )
        
        # Object 4: Content stream
        stream_data = content_stream.encode('latin-1', errors='replace')
        pdf_objects.append(
            f"4 0 obj\n<< /Length {len(stream_data)} >>\nstream\n"
            f"{content_stream}\nendstream\nendobj"
        )
        
        # Build complete PDF
        pdf_header = "%PDF-1.4\n%âãÏÓ\n"
        pdf_body = '\n'.join(pdf_objects) + '\n'
        
        # Calculate xref positions
        xref_positions = [0]  # Object 0
        current_pos = len(pdf_header.encode('latin-1'))
        
        for obj in pdf_objects:
            xref_positions.append(current_pos)
            current_pos += len((obj + '\n').encode('latin-1'))
        
        # Build xref table
        xref_start = current_pos
        xref = f"xref\n0 {len(xref_positions)}\n"
        xref += "0000000000 65535 f \n"
        for pos in xref_positions[1:]:
            xref += f"{pos:010d} 00000 n \n"
        
        # Trailer
        trailer = (
            f"trailer\n<< /Size {len(xref_positions)} /Root 1 0 R >>\n"
            f"startxref\n{xref_start}\n%%EOF"
        )
        
        # Write complete PDF
        with open(pdf_filename, 'wb') as f:
            f.write(pdf_header.encode('latin-1'))
            f.write(pdf_body.encode('latin-1', errors='replace'))
            f.write(xref.encode('latin-1'))
            f.write(trailer.encode('latin-1'))
        
        print(f"✓ PDF invoice generated: {pdf_filename}")
        open_pdf(pdf_filename)
        return pdf_filename
        
    except Exception as e:
        print(f"❌ Error generating PDF: {e}")
        import traceback
        traceback.print_exc()
        return None


# ============================================================================
# TOPIC 7 & 8: Exception Handling + CSV Files
# ============================================================================

def generate_invoice(customer, filename="invoices.csv"):
    """
    Generate and save invoice to CSV
    Topic 7: Exception handling for file operations
    Topic 8: CSV file writing
    """
    try:
        invoice_id = f"INV{datetime.now().strftime('%Y%m%d%H%M%S%f')}"
        customer["invoice_id"] = invoice_id
        customer["date"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Print invoice
        print("\n" + "="*50)
        print(f"         INVOICE #{invoice_id}")
        print("="*50)
        print(f"Customer: {customer['name']}")
        print(f"Email: {customer['email']}")
        print(f"Region: {customer['region']}")
        print(f"Plan: {customer['plan'].upper()} ({customer['billing_type']})")
        print(f"Quantity: {customer['quantity']}")
        print("-"*50)
        print(f"Base Amount: ₹{customer['base_amount']:.2f}")
        
        if customer.get("add_on_cost", 0) > 0:
            print(f"Add-ons: +₹{customer['add_on_cost']:.2f}")
        
        if customer.get("discount_amount", 0) > 0:
            print(f"Discount: -₹{customer['discount_amount']:.2f}")
        
        print(f"Subtotal: ₹{customer['subtotal']:.2f}")
        print(f"Tax ({customer['tax_rate']}%): +₹{customer['tax_amount']:.2f}")
        print("-"*50)
        print(f"TOTAL: ₹{customer['total_amount']:.2f}")
        print("="*50 + "\n")
        
    except KeyError as e:
        print(f"❌ Error: Missing required field - {e}")
        return False
    except Exception as e:
        print(f"❌ Error generating invoice: {e}")
        return False
    else:
        # CSV FILE WRITING (Topic 8)
        try:
            # Check if file exists to determine if we need header
            file_exists = os.path.exists(filename)
            
            with open(filename, mode='a', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)
                
                # Write header if new file
                if not file_exists:
                    writer.writerow([
                        "Invoice ID", "Date", "Customer", "Email", "Region",
                        "Plan", "Billing Type", "Quantity", "Base", "Add-ons",
                        "Discount", "Subtotal", "Tax", "Total"
                    ])
                
                # Write invoice data
                writer.writerow([
                    invoice_id, customer["date"], customer["name"], customer["email"],
                    customer["region"], customer["plan"], customer["billing_type"],
                    customer["quantity"], f"{customer['base_amount']:.2f}",
                    f"{customer.get('add_on_cost', 0):.2f}",
                    f"{customer.get('discount_amount', 0):.2f}",
                    f"{customer['subtotal']:.2f}", f"{customer['tax_amount']:.2f}",
                    f"{customer['total_amount']:.2f}"
                ])
            
            print(f"✓ Invoice saved to {filename}")
            
            # Generate PDF invoice automatically
            # pdf_file = create_invoice_pdf(customer)
            # if pdf_file:
            #     print(f"✓ PDF invoice ready: {pdf_file}")
            
            return True
            
        except IOError as e:
            print(f"❌ Error writing to CSV: {e}")
            return False
        except Exception as e:
            print(f"❌ Unexpected error saving invoice: {e}")
            return False


# ============================================================================
# NEW: API INTEGRATION - Simulated Payment Gateway
# ============================================================================

def process_payment_api(customer, payment_method="credit_card"):
    """
    Simulated API call to payment gateway
    Demonstrates API integration concept
    """
    print(f"\n💳 Processing payment via {payment_method.upper()} API...")
    
    # Simulate API request payload
    api_payload = {
        "invoice_id": customer.get("invoice_id", "PENDING"),
        "customer_email": customer["email"],
        "amount": customer["total_amount"],
        "currency": "INR",
        "payment_method": payment_method,
        "timestamp": datetime.now().isoformat()
    }
    
    print(f"📤 Sending API request: {json.dumps(api_payload, indent=2)}")
    
    # Simulate API processing delay
    time.sleep(1)
    
    # ALWAYS SUCCESS - Remove random failure
    success = True  # Changed from: random.random() < 0.9
    
    if success:
        transaction_id = f"TXN{random.randint(100000, 999999)}"
        api_response = {
            "status": "success",
            "transaction_id": transaction_id,
            "message": "Payment processed successfully",
            "timestamp": datetime.now().isoformat()
        }
        print(f"📥 API Response: {json.dumps(api_response, indent=2)}")
        print("✅ Payment Successful!")
        customer["transaction_id"] = transaction_id
        customer["payment_status"] = "PAID"
        return True
    else:
        api_response = {
            "status": "failed",
            "error_code": "PAYMENT_DECLINED",
            "message": "Payment declined by bank",
            "timestamp": datetime.now().isoformat()
        }
        print(f"📥 API Response: {json.dumps(api_response, indent=2)}")
        print("❌ Payment Failed!")
        customer["payment_status"] = "FAILED"
        return False


def send_email_api(customer):
    """
    Simulated email API integration
    """
    print(f"\n📧 Sending invoice via Email API...")
    
    email_payload = {
        "to": customer["email"],
        "subject": f"Invoice #{customer['invoice_id']}",
        "body": f"Dear {customer['name']}, Your invoice total is ₹{customer['total_amount']:.2f}",
        "attachment": "invoice.pdf"
    }
    
    print(f"📤 Email API request: {json.dumps(email_payload, indent=2)}")
    time.sleep(0.5)
    
    print("✅ Email sent successfully!")
    return True


# ============================================================================
# NEW: GUI WITH POP-UPS - Interactive Interface
# ============================================================================

class BillingSystemGUI:
    """
    Tkinter GUI with pop-ups for billing system
    """
    
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Customer Billing System")
        self.root.geometry("500x600")
        self.root.configure(bg="#f0f0f0")
        self.customer = None
        
    def show_welcome(self):
        """Welcome pop-up"""
        messagebox.showinfo(
            "Welcome",
            "Welcome to Customer Billing & Subscription System!\n\n"
            "Click OK to create a new invoice."
        )
    
    def create_customer_popup(self):
        """Pop-up to get customer details"""
        name = simpledialog.askstring("Customer Details", "Enter customer name:")
        if not name:
            return None
            
        email = simpledialog.askstring("Customer Details", "Enter email address:")
        if not email:
            return None
            
        region = simpledialog.askstring("Customer Details", "Enter region (IN/US/UK):")
        if not region:
            return None
            
        self.customer = create_customer(name, email, region)
        
        if self.customer:
            messagebox.showinfo("Success", f"Customer '{name}' created successfully!")
        return self.customer
    
    def select_plan_popup(self):
        """Pop-up to select subscription plan"""
        if not self.customer:
            messagebox.showerror("Error", "Please create customer first!")
            return
        
        # Plan selection window
        plan_window = tk.Toplevel(self.root)
        plan_window.title("Select Plan")
        plan_window.geometry("400x300")
        
        tk.Label(plan_window, text="Select Subscription Plan", 
                font=("Arial", 14, "bold")).pack(pady=10)
        
        plan_var = tk.StringVar(value="basic")
        billing_var = tk.StringVar(value="monthly")
        
        # Plan options
        for plan in ["basic", "premium", "elite"]:
            price_m = PLANS[plan]["monthly"]
            price_a = PLANS[plan]["annual"]
            tk.Radiobutton(
                plan_window, 
                text=f"{plan.upper()} - Monthly: ₹{price_m} | Annual: ₹{price_a}",
                variable=plan_var,
                value=plan,
                font=("Arial", 10)
            ).pack(anchor='w', padx=20)
        
        tk.Label(plan_window, text="\nBilling Type:", font=("Arial", 10, "bold")).pack()
        tk.Radiobutton(plan_window, text="Monthly", variable=billing_var, 
                      value="monthly").pack()
        tk.Radiobutton(plan_window, text="Annual", variable=billing_var, 
                      value="annual").pack()
        
        def confirm_plan():
            plan = plan_var.get()
            billing = billing_var.get()
            if select_plan(self.customer, plan, billing):
                messagebox.showinfo("Success", f"Plan selected: {plan} ({billing})")
                plan_window.destroy()
            else:
                messagebox.showerror("Error", "Failed to select plan!")
        
        tk.Button(plan_window, text="Confirm", command=confirm_plan, 
                 bg="#4CAF50", fg="white", font=("Arial", 12)).pack(pady=20)
    
    def apply_discount_popup(self):
        """Pop-up to apply discounts"""
        if not self.customer:
            messagebox.showerror("Error", "Please create customer and select plan first!")
            return
        
        discount_window = tk.Toplevel(self.root)
        discount_window.title("Apply Discount")
        discount_window.geometry("350x250")
        
        tk.Label(discount_window, text="Select Discount Type", 
                font=("Arial", 12, "bold")).pack(pady=10)
        
        discount_var = tk.StringVar(value="none")
        
        tk.Radiobutton(discount_window, text="No Discount", 
                      variable=discount_var, value="none").pack()
        tk.Radiobutton(discount_window, text="Student (15% off)", 
                      variable=discount_var, value="student").pack()
        tk.Radiobutton(discount_window, text="Senior (10% off)", 
                      variable=discount_var, value="senior").pack()
        tk.Radiobutton(discount_window, text="Loyalty (12% off)", 
                      variable=discount_var, value="loyalty").pack()
        tk.Radiobutton(discount_window, text="Bulk (20% off)", 
                      variable=discount_var, value="bulk").pack()
        
        def confirm_discount():
            discount = discount_var.get()
            if discount == "none":
                apply_discount(self.customer)
            else:
                apply_discount(self.customer, discount)
            messagebox.showinfo("Success", "Discount applied!")
            discount_window.destroy()
        
        tk.Button(discount_window, text="Apply", command=confirm_discount,
                 bg="#2196F3", fg="white", font=("Arial", 12)).pack(pady=20)
    
    def generate_invoice_popup(self):
        """Calculate and show invoice in pop-up"""
        if not self.customer or not self.customer.get("plan"):
            messagebox.showerror("Error", "Please complete all steps first!")
            return
        
        # Calculate bill
        calculate_bill(self.customer)
        apply_tax(self.customer)
        generate_invoice(self.customer)
        
        # Show invoice details in pop-up
        invoice_text = f"""
        INVOICE SUMMARY
        ════════════════════════════════════
        Customer: {self.customer['name']}
        Email: {self.customer['email']}
        Plan: {self.customer['plan'].upper()}
        Billing: {self.customer['billing_type']}
        ════════════════════════════════════
        Base Amount: ₹{self.customer['base_amount']:.2f}
        Discount: -₹{self.customer.get('discount_amount', 0):.2f}
        Subtotal: ₹{self.customer['subtotal']:.2f}
        Tax ({self.customer['tax_rate']}%): +₹{self.customer['tax_amount']:.2f}
        ════════════════════════════════════
        TOTAL: ₹{self.customer['total_amount']:.2f}
        ════════════════════════════════════
        """
        
        result = messagebox.askyesno(
            "Invoice Generated",
            invoice_text + "\n\nProcess payment now?"
        )
        
        if result:
            # Process payment via API
            if process_payment_api(self.customer, "credit_card"):
                send_email_api(self.customer)
                
                # Regenerate PDF with payment status and auto-open in browser
                print("\n🔄 Generating PDF invoice with payment confirmation...")
                pdf_file = create_invoice_pdf(self.customer)
                
                messagebox.showinfo("Complete", 
                    f"Payment successful!\nTransaction ID: {self.customer['transaction_id']}\n\n"
                    "✅ Invoice emailed to customer\n"
                    "🚀 PDF invoice opening in browser...")
            else:
                messagebox.showwarning("Payment Failed", 
                    "Payment could not be processed. Please try again.")
    
    def run(self):
        """Main GUI loop"""
        # Title
        title = tk.Label(self.root, text="Customer Billing System", 
                        font=("Arial", 18, "bold"), bg="#f0f0f0")
        title.pack(pady=20)
        
        # Buttons
        btn_style = {"width": 30, "height": 2, "font": ("Arial", 11)}
        
        tk.Button(self.root, text="1. Create Customer", 
                 command=self.create_customer_popup, bg="#FF9800", 
                 fg="white", **btn_style).pack(pady=10)
        
        tk.Button(self.root, text="2. Select Plan", 
                 command=self.select_plan_popup, bg="#2196F3", 
                 fg="white", **btn_style).pack(pady=10)
        
        tk.Button(self.root, text="3. Apply Discount", 
                 command=self.apply_discount_popup, bg="#9C27B0", 
                 fg="white", **btn_style).pack(pady=10)
        
        tk.Button(self.root, text="4. Generate Invoice & Pay", 
                 command=self.generate_invoice_popup, bg="#4CAF50", 
                 fg="white", **btn_style).pack(pady=10)
        
        tk.Button(self.root, text="Exit", 
                 command=self.root.quit, bg="#f44336", 
                 fg="white", **btn_style).pack(pady=10)
        
        # Show welcome
        self.root.after(500, self.show_welcome)
        
        # Run
        self.root.mainloop()


# ============================================================================
# MAIN FUNCTION - Demonstrates ALL Topics
# ============================================================================

def main():
    """
    Connect all modules - demonstrates all 8 Python topics
    """
    print("\n" + "="*60)
    print("🚀 BILLING SYSTEM ")
    print("="*60 + "\n")
    
    # Clear old file
    if os.path.exists("invoices.csv"):
        os.remove("invoices.csv")
    
    # ========================================================================
    # Example 1: Basic with type conversion and exception handling
    # ========================================================================
    print("📌 Example 1: Type Conversion + Exception Handling")
    print("-" * 60)
    c1 = create_customer("Rahul Kumar", "rahul@email.com", "in", 
                         phone="9876543210")  # **kwargs
    if c1:
        select_plan(c1, "basic", "monthly", 1)
        apply_discount(c1)  # No discount
        calculate_bill(c1)
        apply_tax(c1)
        generate_invoice(c1, "invoices.csv")
    
    # ========================================================================
    # Example 2: Multiple discounts with lambda/map/reduce
    # ========================================================================
    print("\n📌 Example 2: Lambda/Map/Filter/Reduce (Multiple Discounts)")
    print("-" * 60)
    c2 = create_customer("Priya Sharma", "priya@email.com", "IN",
                         student_id="STU123")  # **kwargs
    if c2:
        select_plan(c2, "premium", "annual")
        apply_discount(c2, "student", "loyalty", corporate=5)  # *args + **kwargs
        calculate_bill(c2)
        apply_tax(c2)
        generate_invoice(c2, "invoices.csv")
    
    # ========================================================================
    # Example 3: Bulk with add-ons (*args) and custom discount (**kwargs)
    # ========================================================================
    print("\n📌 Example 3: *args/*kwargs + Math Operators")
    print("-" * 60)
    c3 = create_customer("Tech Corp", "admin@techcorp.com", "US",
                         company="Tech Corp Ltd", gst="GST123")  # **kwargs
    if c3:
        select_plan(c3, "elite", "monthly", 5, "support", "training")  # *args
        apply_discount(c3, "bulk", "loyalty", special_offer=10)  # **kwargs
        calculate_bill(c3)
        apply_tax(c3)
        generate_invoice(c3, "invoices.csv")
    
    # ========================================================================
    # Example 4: Error handling demonstration
    # ========================================================================
    print("\n📌 Example 4: Exception Handling (Invalid Input)")
    print("-" * 60)
    c4 = create_customer("Test User", "test@email.com", "UK")
    if c4:
        # This will trigger exception handling (invalid quantity)
        select_plan(c4, "premium", "monthly", "invalid")  # Invalid type
    
    # ========================================================================
    # Summary using filter and reduce
    # ========================================================================
    print("\n" + "="*60)
    print("📊 SUMMARY - Using Filter/Reduce")
    print("="*60)
    
    # Read CSV and calculate totals (Topic 5 & 8)
    try:
        with open("invoices.csv", 'r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            invoices = list(reader)
            
            # FILTER - Get successful invoices (Topic 5)
            valid_invoices = list(filter(lambda inv: float(inv['Total']) > 0, invoices))
            
            # MAP - Extract total amounts (Topic 5)
            totals = list(map(lambda inv: float(inv['Total']), valid_invoices))
            
            # REDUCE - Sum all totals (Topic 5)
            if totals:
                grand_total = reduce(lambda x, y: x + y, totals)
                print(f"Total Invoices: {len(valid_invoices)}")
                print(f"Grand Total Revenue: ₹{grand_total:.2f}")
            
            print(f"\n✅ All invoices saved to 'invoices.csv'")
            
    except FileNotFoundError:
        print("No invoices generated")
    except Exception as e:
        print(f"Error reading invoices: {e}")
    
    print("\n" + "="*60)
    print("✅ DEMO COMPLETED")
    print("="*60 + "\n")


def main_with_gui():
    """
    Launch GUI version with pop-ups and API integration
    """
    print("\n" + "="*60)
    print("🚀 LAUNCHING GUI VERSION")
    print("="*60)
    print("Opening interactive billing system with pop-ups...")
    print("Follow the on-screen buttons to create invoices.\n")
    
    app = BillingSystemGUI()
    app.run()


if __name__ == "__main__":
    # Use GUI dialog to choose version (works in read-only terminals)
    print("\n" + "="*60)
    print("Customer Billing & Subscription Management System")
    print("="*60)
    print("\nOpening mode selection dialog...")
    
    # Create temporary root window for dialog
    temp_root = tk.Tk()
    temp_root.withdraw()  # Hide the main window
    
    # Show dialog box to choose mode
    choice = messagebox.askquestion(
        "Choose Mode",
        "Customer Billing & Subscription Management System\n\n"
        "Choose execution mode:\n\n"
        "YES = GUI Version (Pop-ups + API Integration)\n"
        "NO = Command Line Demo \n\n"
        "Click YES for interactive GUI or NO for automated demo",
        icon='question'
    )
    
    temp_root.destroy()
    
    if choice == "yes":
        print("\n✓ GUI Mode selected")
        print("="*60)
        main_with_gui()
    else:
        print("\n✓ Command Line Demo selected")
        print("="*60)
        main()