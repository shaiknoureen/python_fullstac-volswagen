#!/usr/bin/env python
"""
Debug script to check CourseRequest votes
"""
from app import create_app, db
from models import CourseRequest, CourseRequestVote, User

app = create_app()

with app.app_context():
    # Get all course requests
    requests = CourseRequest.query.all()
    
    for req in requests:
        votes = CourseRequestVote.query.filter_by(request_id=req.id).all()
        print(f"\nCourse Request: {req.title}")
        print(f"Total Votes: {len(votes)}")
        
        for vote in votes:
            user = User.query.get(vote.student_id)
            user_name = user.name if user else f"DELETED USER (ID: {vote.student_id})"
            print(f"  - Vote from: {user_name}")
    
    # Count total users
    total_users = User.query.count()
    print(f"\n\nTotal active users: {total_users}")
