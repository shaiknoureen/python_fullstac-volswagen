#!/usr/bin/env python
"""
Delete the python course request and its votes
"""
from app import create_app, db
from models import CourseRequest, CourseRequestVote

app = create_app()

with app.app_context():
    # Find and delete the python course request
    python_req = CourseRequest.query.filter_by(title='python').first()
    
    if python_req:
        print(f"Found Course Request: {python_req.title} (ID: {python_req.id})")
        
        # Delete all votes for this request
        votes = CourseRequestVote.query.filter_by(request_id=python_req.id).all()
        print(f"Deleting {len(votes)} votes...")
        for vote in votes:
            db.session.delete(vote)
        
        # Delete the request itself
        db.session.delete(python_req)
        db.session.commit()
        
        print("Course request and all its votes deleted successfully!")
    else:
        print("No python course request found")
