from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required, current_user
from extensions import db, bcrypt
from models import User, CourseRequest, InstructorInterest
import re

auth_bp = Blueprint('auth', __name__)

def validate_password_strength(password, role='user'):
    """
    Validate password strength.
    - For regular users: minimum 8 chars, must include uppercase, lowercase, number, and special char
    - For admin: no strength requirements
    """
    if role == 'admin':
        return True, "Password accepted"
    
    if len(password) < 8:
        return False, "Password must be at least 8 characters long"
    
    if not re.search(r'[A-Z]', password):
        return False, "Password must contain at least one uppercase letter"
    
    if not re.search(r'[a-z]', password):
        return False, "Password must contain at least one lowercase letter"
    
    if not re.search(r'[0-9]', password):
        return False, "Password must contain at least one number"
    
    if not re.search(r'[!@#$%^&*()_+\-=\[\]{};:\'\"\\|,.<>\/?]', password):
        return False, "Password must contain at least one special character (!@#$%^&*)"
    
    return True, "Password is strong"

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect_role(current_user)

    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        user = User.query.filter_by(email=email).first()

        if user and bcrypt.check_password_hash(user.password, password):
            login_user(user)
            flash('Login Successful!', 'success')
            return redirect_role(user)
        else:
            flash('Login unsuccessful. Please check email and password.', 'danger')

    return render_template('auth/login.html')

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect_role(current_user)

    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        password = request.form.get('password')
        role = request.form.get('role')

        if role == 'admin':
            flash('Admin registration is disabled. Please contact the system administrator.', 'warning')
            return redirect(url_for('auth.register'))

        # Check existing email
        if User.query.filter_by(email=email).first():
            flash('Email already exists.', 'warning')
            return redirect(url_for('auth.register'))

        # Validate password strength for non-admin users
        is_valid, message = validate_password_strength(password, role)
        if not is_valid:
            flash(f'Password Error: {message}', 'danger')
            return redirect(url_for('auth.register'))

        hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
        user = User(name=name, full_name=name, email=email, password=hashed_password, role=role)
        db.session.add(user)
        db.session.commit()
        
        if role == 'instructor':
            selected_requests = request.form.getlist('course_interest_ids')
            for request_id in selected_requests:
                if CourseRequest.query.get(request_id):
                    db.session.add(InstructorInterest(instructor_id=user.id, request_id=request_id))
            db.session.commit()
        
        flash(f'Account created for {name}! You can now login.', 'success')
        return redirect(url_for('auth.login'))

    return render_template('auth/register.html')

@auth_bp.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('auth.login'))

@auth_bp.route('/reset-password', methods=['GET', 'POST'])
def reset_password():
    if current_user.is_authenticated:
        return redirect_role(current_user)
    
    if request.method == 'POST':
        email = request.form.get('email')
        user = User.query.filter_by(email=email).first()
        
        if not user:
            flash('No account found with that email address.', 'danger')
            return redirect(url_for('auth.reset_password'))
        
        if user.role == 'admin':
            flash('Admin password reset must be done by system administrator.', 'warning')
            return redirect(url_for('auth.reset_password'))
        
        # In a production environment, you would generate a token and send an email
        # For this implementation, we'll redirect to a password change page with email verification
        return redirect(url_for('auth.change_password', email=email))
    
    return render_template('auth/reset_password.html')

@auth_bp.route('/change-password', methods=['GET', 'POST'])
def change_password():
    if current_user.is_authenticated:
        return redirect_role(current_user)
    
    email = request.args.get('email')
    if not email:
        flash('Invalid password reset request.', 'danger')
        return redirect(url_for('auth.reset_password'))
    
    user = User.query.filter_by(email=email).first()
    if not user:
        flash('Invalid password reset request.', 'danger')
        return redirect(url_for('auth.reset_password'))
    
    if request.method == 'POST':
        new_password = request.form.get('new_password')
        confirm_password = request.form.get('confirm_password')
        
        if new_password != confirm_password:
            flash('Passwords do not match!', 'danger')
            return redirect(url_for('auth.change_password', email=email))
        
        # Validate password strength
        is_valid, message = validate_password_strength(new_password, user.role)
        if not is_valid:
            flash(f'Password Error: {message}', 'danger')
            return redirect(url_for('auth.change_password', email=email))
        
        # Update password
        hashed_password = bcrypt.generate_password_hash(new_password).decode('utf-8')
        user.password = hashed_password
        db.session.commit()
        
        flash('Your password has been successfully reset! You can now login with your new password.', 'success')
        return redirect(url_for('auth.login'))
    
    return render_template('auth/change_password.html', email=email)

def redirect_role(user):
    if user.role == 'admin':
        return redirect(url_for('admin.dashboard'))
    elif user.role == 'instructor':
        return redirect(url_for('instructor.dashboard'))
    elif user.role == 'student':
        return redirect(url_for('student.dashboard'))
    else:
        return redirect(url_for('main.home'))
