from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from extensions import db
from models import User, Course, CourseRequest, CourseRequestVote, InstructorInterest, Result, Enrollment, UserProfile, Message, Notification, UserBadge
from sqlalchemy import func

admin_bp = Blueprint('admin', __name__)

@admin_bp.route('/dashboard')
@login_required
def dashboard():
    if current_user.role != 'admin':
        return redirect(url_for('main.home'))
    users = User.query.order_by(User.created_at.desc()).all()
    courses = Course.query.order_by(Course.created_at.desc()).all()
    pending_courses = [c for c in courses if c.status == 'Pending']

    eligible_requests = db.session.query(
        CourseRequest,
        func.count(CourseRequestVote.id).label('votes')
    ).outerjoin(CourseRequestVote, CourseRequest.id == CourseRequestVote.request_id) \
     .filter(CourseRequest.status == 'pending') \
     .group_by(CourseRequest.id) \
     .having(func.count(CourseRequestVote.id) >= 4) \
     .order_by(func.count(CourseRequestVote.id).desc(), CourseRequest.created_at.desc()) \
     .all()

    instructors = User.query.filter_by(role='instructor', status='active').order_by(User.full_name.asc()).all()

    eligible_request_interests = {}
    for req, _votes in eligible_requests:
        interests = db.session.query(User).join(InstructorInterest, InstructorInterest.instructor_id == User.id) \
            .filter(InstructorInterest.request_id == req.id).order_by(User.full_name.asc()).all()
        eligible_request_interests[req.id] = interests

    return render_template('admin_dashboard.html',
                           user=current_user,
                           users=users,
                           courses=courses,
                           pending_courses=pending_courses,
                           eligible_requests=eligible_requests,
                           instructors=instructors,
                           eligible_request_interests=eligible_request_interests)

@admin_bp.route('/approve-course/<int:course_id>')
@login_required
def approve_course(course_id):
    if current_user.role != 'admin':
        return redirect(url_for('main.home'))
    course = Course.query.get_or_404(course_id)
    course.status = 'Approved'
    db.session.commit()
    flash(f'Course "{course.title}" approved!', 'success')
    return redirect(url_for('admin.dashboard'))

@admin_bp.route('/reject-course/<int:course_id>')
@login_required
def reject_course(course_id):
    if current_user.role != 'admin':
        return redirect(url_for('main.home'))
    course = Course.query.get_or_404(course_id)
    course.status = 'Rejected'
    db.session.commit()
    flash('Course rejected.', 'info')
    return redirect(url_for('admin.dashboard'))

@admin_bp.route('/delete-user/<int:user_id>')
@login_required
def delete_user(user_id):
    if current_user.role != 'admin':
        return redirect(url_for('main.home'))

    user = User.query.get_or_404(user_id)

    if user.role == 'admin':
        flash('Cannot delete an admin.', 'danger')
    else:
        # Handle notifications associated with the user
        Notification.query.filter_by(user_id=user_id).delete()

        # Handle messages associated with the user
        default_receiver = User.query.filter(User.id != user_id).first()
        if not default_receiver:
            flash('Cannot delete user. No default receiver available to reassign messages.', 'danger')
            return redirect(url_for('admin.dashboard'))

        Message.query.filter_by(receiver_id=user_id).update({"receiver_id": default_receiver.id})

        # Handle courses associated with the instructor
        if user.role == 'instructor':
            default_instructor = User.query.filter(User.role == 'instructor', User.id != user_id).first()
            if not default_instructor:
                flash('Cannot delete instructor. No other instructor available to reassign courses.', 'danger')
                return redirect(url_for('admin.dashboard'))

            Course.query.filter_by(instructor_id=user_id).update({"instructor_id": default_instructor.id})

        # Delete badges associated with the user
        UserBadge.query.filter_by(user_id=user_id).delete()

        # Delete related records in dependent tables
        UserProfile.query.filter_by(user_id=user_id).delete()
        Result.query.filter_by(user_id=user_id).delete()
        Enrollment.query.filter_by(user_id=user_id).delete()
        CourseRequestVote.query.filter_by(student_id=user_id).delete()

        # Delete the user
        db.session.delete(user)
        db.session.commit()
        flash('User and related data deleted.', 'info')

    return redirect(url_for('admin.dashboard'))

@admin_bp.route('/users')
@login_required
def admin_users():
    if current_user.role != 'admin':
        return redirect(url_for('main.home'))
    users = User.query.order_by(User.created_at.desc()).all()
    return render_template('admin_users.html', users=users)

@admin_bp.route('/analytics')
@login_required
def admin_analytics():
    if current_user.role != 'admin':
        return redirect(url_for('main.home'))

    enrollment_data = db.session.query(
        Course.title,
        func.count(Enrollment.id).label('count')
    ).outerjoin(Enrollment, Enrollment.course_id == Course.id) \
     .filter(Course.status == 'Approved') \
     .group_by(Course.id).order_by(func.count(Enrollment.id).desc()).limit(10).all()

    performance_data = db.session.query(
        User.full_name,
        func.avg(Result.percentage).label('avg_percentage')
    ).join(Result, Result.user_id == User.id) \
     .filter(User.role == 'student').group_by(User.id).order_by(func.avg(Result.percentage).desc()).limit(10).all()

    # Course-wise student performance
    from models import Quiz
    course_performance = db.session.query(
        Course.title.label('course_title'),
        func.count(func.distinct(Enrollment.user_id)).label('enrolled_students'),
        func.count(func.distinct(Result.user_id)).label('students_attempted'),
        func.avg(Result.percentage).label('avg_score'),
        func.max(Result.percentage).label('max_score'),
        func.min(Result.percentage).label('min_score')
    ).join(Enrollment, Enrollment.course_id == Course.id) \
     .outerjoin(Quiz, Quiz.course_id == Course.id) \
     .outerjoin(Result, Result.quiz_id == Quiz.id) \
     .filter(Course.status == 'Approved') \
     .group_by(Course.id, Course.title) \
     .order_by(func.count(Enrollment.user_id).desc()).all()

    course_perf_data = [
        {
            'course': row.course_title,
            'enrolled': row.enrolled_students,
            'attempted': row.students_attempted or 0,
            'avg_score': round(row.avg_score, 1) if row.avg_score else 0,
            'max_score': round(row.max_score, 1) if row.max_score else 0,
            'min_score': round(row.min_score, 1) if row.min_score else 0
        }
        for row in course_performance
    ]

    return render_template('admin_analytics.html',
                           enrollment_data=enrollment_data,
                           performance_data=performance_data,
                           course_performance=course_perf_data)

@admin_bp.route('/assign-faculty/<int:request_id>', methods=['POST'])
@login_required
def assign_faculty(request_id):
    if current_user.role != 'admin':
        return redirect(url_for('main.home'))

    instructor_id = request.form.get('instructor_id')
    if not instructor_id:
        flash('Please select an instructor to assign.', 'warning')
        return redirect(url_for('admin.dashboard'))

    req = CourseRequest.query.get_or_404(request_id)
    course = Course(title=req.title, description=req.description or '', instructor_id=instructor_id, status='Approved')
    db.session.add(course)
    req.status = 'assigned'
    db.session.commit()

    # Notify the student who requested the course
    notification = Notification(
        user_id=req.requested_by,
        title='Course Request Approved',
        message=f'Your course request "{req.title}" has been approved and assigned to an instructor!',
        notification_type='course_approved'
    )
    db.session.add(notification)
    db.session.commit()

    flash('Faculty assigned and course published successfully!', 'success')
    return redirect(url_for('admin.dashboard'))

@admin_bp.route('/course-requests')
@login_required
def course_requests():
    if current_user.role != 'admin':
        return redirect(url_for('main.home'))
    
    # Get all course requests with vote counts, sorted by popularity
    all_requests = db.session.query(
        CourseRequest,
        func.count(CourseRequestVote.id).label('votes'),
        User.full_name.label('requester_name')
    ).outerjoin(CourseRequestVote, CourseRequest.id == CourseRequestVote.request_id) \
     .join(User, CourseRequest.requested_by == User.id) \
     .group_by(CourseRequest.id) \
     .order_by(func.count(CourseRequestVote.id).desc(), CourseRequest.created_at.desc()) \
     .all()
    
    # Get all active instructors for dropdown
    instructors = User.query.filter_by(role='instructor', status='active').order_by(User.full_name.asc()).all()
    
    return render_template('admin_course_requests.html',
                           user=current_user,
                           all_requests=all_requests,
                           instructors=instructors)

@admin_bp.route('/reject-request/<int:request_id>', methods=['POST'])
@login_required
def reject_request(request_id):
    if current_user.role != 'admin':
        return redirect(url_for('main.home'))
    
    req = CourseRequest.query.get_or_404(request_id)
    req.status = 'rejected'
    db.session.commit()
    
    # Notify the student who requested the course
    notification = Notification(
        user_id=req.requested_by,
        title='Course Request Rejected',
        message=f'Your course request "{req.title}" has been rejected by the administrator.',
        notification_type='course_rejected'
    )
    db.session.add(notification)
    db.session.commit()
    
    flash(f'Course request "{req.title}" has been rejected.', 'info')
    return redirect(url_for('admin.course_requests'))

@admin_bp.route('/delete-request/<int:request_id>', methods=['POST'])
@login_required
def delete_request(request_id):
    if current_user.role != 'admin':
        return redirect(url_for('main.home'))
    
    req = CourseRequest.query.get_or_404(request_id)
    title = req.title
    requester_id = req.requested_by
    
    # Delete all votes for this request
    CourseRequestVote.query.filter_by(request_id=request_id).delete()
    
    # Delete the request
    db.session.delete(req)
    db.session.commit()
    
    # Notify the student who requested the course
    notification = Notification(
        user_id=requester_id,
        title='Course Request Deleted',
        message=f'Your course request "{title}" has been deleted by the administrator.',
        notification_type='course_deleted'
    )
    db.session.add(notification)
    db.session.commit()
    
    flash(f'Course request "{title}" and all its votes have been deleted.', 'info')
    return redirect(url_for('admin.dashboard'))
