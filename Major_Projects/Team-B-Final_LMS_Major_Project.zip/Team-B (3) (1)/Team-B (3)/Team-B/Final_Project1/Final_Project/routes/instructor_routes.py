from flask import Blueprint, render_template, redirect, url_for, flash, request, current_app
from flask_login import login_required, current_user
from extensions import db
from models import Course, Content, Quiz, Question, CourseCategory, CourseCategoryMapping, Assignment, Enrollment, AttendanceSession, AttendanceRecord, Result, User, CourseReview
from datetime import datetime, timedelta
from sqlalchemy import func
import os

instructor_bp = Blueprint('instructor', __name__)

@instructor_bp.route('/dashboard')
@login_required
def dashboard():
    instructor_id = current_user.id
    # Only show approved courses to keep dashboard clean
    courses = Course.query.filter_by(instructor_id=instructor_id, status='Approved').order_by(Course.created_at.desc()).all()
    
    # Get performance data for approved courses only
    performance_data = db.session.query(
        Course.title,
        func.avg(Result.percentage).label('avg_percentage')
    ).join(Quiz, Quiz.course_id == Course.id) \
     .outerjoin(Result, Result.quiz_id == Quiz.id) \
     .filter(Course.instructor_id == instructor_id, Course.status == 'Approved') \
     .group_by(Course.id, Course.title).all()

    performance_labels = [p[0] for p in performance_data]
    performance_values = [round(p[1], 1) if p[1] else 0 for p in performance_data]
    
    return render_template('dashboard/instructor_dashboard.html', 
                         user=current_user, 
                         courses=courses,
                         performance_labels=performance_labels,
                         performance_values=performance_values)

@instructor_bp.route('/create_course', methods=['GET', 'POST'])
@login_required
def create_course():
    if current_user.role != 'instructor':
        flash('Access Denied', 'danger')
        return redirect(url_for('main.home'))

    categories = CourseCategory.query.order_by(CourseCategory.name.asc()).all()

    if request.method == 'POST':
        title = request.form.get('title')
        description = request.form.get('description')
        selected_categories = request.form.getlist('categories')
        
        course = Course(title=title, description=description, instructor_id=current_user.id)
        db.session.add(course)
        db.session.commit()

        for category_id in selected_categories:
            db.session.add(CourseCategoryMapping(course_id=course.id, category_id=category_id))
        db.session.commit()

        flash('Course created! Waiting for Admin approval.', 'success')
        return redirect(url_for('instructor.instructor_course_details', course_id=course.id))

    return render_template('create_course.html', categories=categories)

@instructor_bp.route('/course/<int:course_id>/add-content', methods=['GET', 'POST'])
@login_required
def add_content(course_id):
    course = Course.query.get_or_404(course_id)
    if course.instructor_id != current_user.id:
        flash('Unauthorized', 'danger')
        return redirect(url_for('instructor.dashboard'))
        
    if request.method == 'POST':
        title = request.form.get('title')
        content_type = request.form.get('type')
        content_url = request.form.get('content', '').strip()
        file = request.files.get('file')

        if not content_url and not file:
            flash('Please provide either a Material URL or upload a file!', 'warning')
            return render_template('courses/add_content.html', course=course)

        # Handle file upload for any content type
        if file and file.filename:
            # Save the file to the uploads directory
            upload_folder = os.path.join(current_app.root_path, 'static/uploads')
            os.makedirs(upload_folder, exist_ok=True)
            file_path = os.path.join(upload_folder, file.filename)
            file.save(file_path)
            content_url = f'uploads/{file.filename}'

        # Validate URL format only if content_url is provided and not a file
        if content_url and not content_url.startswith(('http://', 'https://', 'uploads/')):
            flash('Please provide a valid URL starting with http:// or https://', 'warning')
            return render_template('courses/add_content.html', course=course)

        content = Content(course_id=course.id, title=title, type=content_type, content=content_url)
        db.session.add(content)
        db.session.commit()
        flash('Content added successfully! Students can now access this material.', 'success')
        return redirect(url_for('instructor.instructor_course_details', course_id=course.id))
        
    return render_template('courses/add_content.html', course=course)

@instructor_bp.route('/course/<int:course_id>/create-quiz', methods=['GET', 'POST'])
@login_required
def create_quiz(course_id):
    course = Course.query.get_or_404(course_id)
    if course.instructor_id != current_user.id:
        flash('Unauthorized', 'danger')
        return redirect(url_for('instructor.dashboard'))

    if request.method == 'POST':
        title = request.form.get('title')
        description = request.form.get('description')
        total_marks = request.form.get('total_marks')
        quiz = Quiz(course_id=course.id, title=title, description=description, total_marks=total_marks)
        db.session.add(quiz)
        db.session.commit()
        flash('Assessment created! Now add questions.', 'success')
        return redirect(url_for('instructor.add_questions', assessment_id=quiz.id))

    return render_template('create_assessment.html', course=course)

@instructor_bp.route('/course/<int:course_id>')
@login_required
def instructor_course_details(course_id):
    course = Course.query.filter_by(id=course_id, instructor_id=current_user.id).first_or_404()
    materials = Content.query.filter_by(course_id=course_id).order_by(Content.created_at.desc()).all()
    assessments = Quiz.query.filter_by(course_id=course_id).order_by(Quiz.created_at.desc()).all()
    assignments = Assignment.query.filter_by(course_id=course_id).order_by(Assignment.created_at.desc()).all()

    students = db.session.query(Enrollment, User).join(User, Enrollment.user_id == User.id) \
        .filter(Enrollment.course_id == course_id).order_by(Enrollment.enrolled_date.desc()).all()

    attendance_sessions = AttendanceSession.query.filter_by(course_id=course_id).order_by(AttendanceSession.session_date.desc()).all()

    attendance_records = AttendanceRecord.query.join(AttendanceSession, AttendanceRecord.session_id == AttendanceSession.id) \
        .filter(AttendanceSession.course_id == course_id).all()

    attendance_map = {}
    for record in attendance_records:
        attendance_map.setdefault(record.session_id, {})[record.student_id] = record.status

    return render_template('instructor_course_details.html',
                           course=course,
                           materials=materials,
                           assessments=assessments,
                           assignments=assignments,
                           students=students,
                           attendance_sessions=attendance_sessions,
                           attendance_map=attendance_map)

@instructor_bp.route('/course/<int:course_id>/attendance/session/add', methods=['POST'])
@login_required
def add_attendance_session(course_id):
    session_date_str = request.form.get('session_date')
    topic = request.form.get('topic', '')
    
    if not session_date_str:
        flash('Session date is required.', 'warning')
        return redirect(url_for('instructor.instructor_course_details', course_id=course_id))
    
    try:
        session_date = datetime.strptime(session_date_str, '%Y-%m-%d').date()
        db.session.add(AttendanceSession(course_id=course_id, session_date=session_date, topic=topic))
        db.session.commit()
        flash('Attendance session created.', 'success')
    except ValueError as e:
        db.session.rollback()
        flash(f'Invalid date format. Please use YYYY-MM-DD format.', 'danger')
    except Exception as e:
        db.session.rollback()
        flash(f'Error creating session: {str(e)}', 'danger')
    
    return redirect(url_for('instructor.instructor_course_details', course_id=course_id))

@instructor_bp.route('/course/<int:course_id>/attendance/session/generate', methods=['POST'])
@login_required
def generate_attendance_sessions(course_id):
    topic_prefix = request.form.get('topic_prefix', 'Class').strip() or 'Class'
    start_date = request.form.get('start_date')
    end_date = request.form.get('end_date')
    frequency = request.form.get('frequency', 'weekly')

    if not start_date or not end_date:
        flash('Start date and end date are required.', 'warning')
        return redirect(url_for('instructor.instructor_course_details', course_id=course_id))

    try:
        start = datetime.strptime(start_date, '%Y-%m-%d').date()
        end = datetime.strptime(end_date, '%Y-%m-%d').date()
        if start > end:
            raise ValueError('Start date must be before end date.')

        delta_days = 7 if frequency == 'weekly' else 1
        current = start
        count = 0

        while current <= end:
            db.session.add(AttendanceSession(course_id=course_id, session_date=current, topic=f"{topic_prefix} - {current.strftime('%b %d')}"))
            count += 1
            current = current + timedelta(days=delta_days)

        db.session.commit()
        flash(f'{count} attendance sessions generated successfully.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error generating attendance sessions: {str(e)}', 'danger')

    return redirect(url_for('instructor.instructor_course_details', course_id=course_id))

@instructor_bp.route('/course/<int:course_id>/attendance/session/<int:session_id>/mark', methods=['POST'])
@login_required
def mark_attendance(course_id, session_id):
    students = Enrollment.query.filter_by(course_id=course_id).all()

    for enrollment in students:
        status = request.form.get(f'status_{enrollment.user_id}', 'absent')
        record = AttendanceRecord.query.filter_by(session_id=session_id, student_id=enrollment.user_id).first()
        if record:
            record.status = status
            record.marked_at = datetime.utcnow()
        else:
            db.session.add(AttendanceRecord(session_id=session_id, student_id=enrollment.user_id, status=status))

    db.session.commit()
    flash('Attendance updated.', 'success')
    return redirect(url_for('instructor.instructor_course_details', course_id=course_id))

@instructor_bp.route('/create_assessment/<int:course_id>', methods=['GET', 'POST'])
@login_required
def create_assessment(course_id):
    course = Course.query.get_or_404(course_id)
    if course.instructor_id != current_user.id:
        flash('Unauthorized', 'danger')
        return redirect(url_for('instructor.dashboard'))

    if request.method == 'POST':
        title = request.form.get('title')
        description = request.form.get('description')
        total_marks = request.form.get('total_marks')
        assessment = Quiz(course_id=course.id, title=title, description=description, total_marks=total_marks)
        db.session.add(assessment)
        db.session.commit()
        flash('Assessment created! Now add questions.', 'success')
        return redirect(url_for('instructor.add_questions', assessment_id=assessment.id))

    return render_template('create_assessment.html', course=course)

@instructor_bp.route('/add_questions/<int:assessment_id>', methods=['GET', 'POST'])
@login_required
def add_questions(assessment_id):
    assessment = Quiz.query.get_or_404(assessment_id)
    if assessment.course.instructor_id != current_user.id:
        flash('Unauthorized', 'danger')
        return redirect(url_for('instructor.dashboard'))

    if request.method == 'POST':
        question_text = request.form.get('question_text')
        option_a = request.form.get('option_a')
        option_b = request.form.get('option_b')
        option_c = request.form.get('option_c')
        option_d = request.form.get('option_d')
        correct_answer = request.form.get('correct_answer')
        marks = request.form.get('marks', 1)

        q = Question(
            quiz_id=assessment.id,
            question_text=question_text,
            option_a=option_a,
            option_b=option_b,
            option_c=option_c,
            option_d=option_d,
            correct_option=correct_answer,
            marks=marks
        )
        db.session.add(q)
        db.session.commit()

        flash('Question added successfully!', 'success')
        if 'add_another' in request.form:
            return redirect(url_for('instructor.add_questions', assessment_id=assessment.id))
        return redirect(url_for('instructor.dashboard'))

    questions = Question.query.filter_by(quiz_id=assessment.id).all()
    return render_template('add_questions.html', assessment=assessment, questions=questions)

@instructor_bp.route('/student_performance/<int:course_id>')
@login_required
def student_performance(course_id):
    course = Course.query.get_or_404(course_id)
    if course.instructor_id != current_user.id:
        flash('Unauthorized', 'danger')
        return redirect(url_for('instructor.dashboard'))

    performance = db.session.query(
        User.id,
        User.full_name,
        User.email,
        func.avg(Result.percentage).label('avg_percentage'),
        func.count(func.distinct(Result.quiz_id)).label('assessments_taken')
    ).join(Enrollment, Enrollment.user_id == User.id) \
     .outerjoin(Result, Result.user_id == User.id) \
     .filter(Enrollment.course_id == course_id, User.role == 'student') \
     .group_by(User.id).order_by(func.avg(Result.percentage).desc()).all()

    # Calculate statistics
    percentages = [p.avg_percentage or 0 for p in performance]
    assessments = [p.assessments_taken or 0 for p in performance]
    
    avg_class_percentage = sum(percentages) / len(percentages) if percentages else 0
    total_assessments_taken = sum(assessments)
    highest_percentage = max(percentages) if percentages else 0

    return render_template('student_performance.html', 
                           performance=performance, 
                           course=course,
                           avg_class_percentage=avg_class_percentage,
                           total_assessments_taken=total_assessments_taken,
                           highest_percentage=highest_percentage)

@instructor_bp.route('/course/<int:course_id>/delete-content/<int:content_id>', methods=['POST'])
@login_required
def delete_content(course_id, content_id):
    content = Content.query.get_or_404(content_id)
    if content.course.instructor_id != current_user.id:
        flash('Unauthorized', 'danger')
        return redirect(url_for('instructor.course_details', course_id=course_id))

    # Delete file if it exists
    if content.type == 'File Upload' and content.content:
        file_path = os.path.join(current_app.root_path, content.content)
        if os.path.exists(file_path):
            os.remove(file_path)

    db.session.delete(content)
    db.session.commit()
    flash('Content deleted successfully!', 'success')
    return redirect(url_for('instructor.course_details', course_id=course_id))

@instructor_bp.route('/course/<int:course_id>/edit-content/<int:content_id>', methods=['GET', 'POST'])
@login_required
def edit_content(course_id, content_id):
    content = Content.query.get_or_404(content_id)
    if content.course.instructor_id != current_user.id:
        flash('Unauthorized', 'danger')
        return redirect(url_for('instructor.course_details', course_id=course_id))

    if request.method == 'POST':
        content.title = request.form.get('title')
        content.type = request.form.get('type')
        content_url = request.form.get('content')
        file = request.files.get('file')

        if content.type == 'File Upload' and file:
            # Save the new file
            upload_folder = os.path.join(current_app.root_path, 'static/uploads')
            os.makedirs(upload_folder, exist_ok=True)
            file_path = os.path.join(upload_folder, file.filename)
            file.save(file_path)
            content.content = f'static/uploads/{file.filename}'
        else:
            content.content = content_url

        db.session.commit()
        flash('Content updated successfully!', 'success')
        return redirect(url_for('instructor.course_details', course_id=course_id))

    return render_template('edit_content.html', content=content)

@instructor_bp.route('/course/<int:course_id>/delete', methods=['POST'])
@login_required
def delete_course(course_id):
    course = Course.query.filter_by(id=course_id, instructor_id=current_user.id).first_or_404()
    
    try:
        # Delete all related data
        # Delete results for quizzes in this course
        quizzes = Quiz.query.filter_by(course_id=course_id).all()
        for quiz in quizzes:
            Result.query.filter_by(quiz_id=quiz.id).delete()
            Question.query.filter_by(quiz_id=quiz.id).delete()
        
        # Delete quizzes
        Quiz.query.filter_by(course_id=course_id).delete()
        
        # Delete assignments
        Assignment.query.filter_by(course_id=course_id).delete()
        
        # Delete content
        Content.query.filter_by(course_id=course_id).delete()
        
        # Delete attendance records and sessions
        attendance_sessions = AttendanceSession.query.filter_by(course_id=course_id).all()
        for session in attendance_sessions:
            AttendanceRecord.query.filter_by(session_id=session.id).delete()
        AttendanceSession.query.filter_by(course_id=course_id).delete()
        
        # Delete enrollments
        Enrollment.query.filter_by(course_id=course_id).delete()
        
        # Delete course category mappings
        CourseCategoryMapping.query.filter_by(course_id=course_id).delete()
        
        # Delete course reviews
        CourseReview.query.filter_by(course_id=course_id).delete()
        
        # Delete the course itself
        db.session.delete(course)
        db.session.commit()
        
        flash('Course deleted successfully.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error deleting course: {str(e)}', 'danger')
    
    return redirect(url_for('instructor.dashboard'))

@instructor_bp.route('/profile/delete', methods=['POST'])
@login_required
def delete_instructor():
    if current_user.role != 'instructor':
        flash('Unauthorized', 'danger')
        return redirect(url_for('main.home'))
    
    instructor_id = current_user.id
    
    try:
        # Delete all courses taught by this instructor (which cascades to all related data)
        courses = Course.query.filter_by(instructor_id=instructor_id).all()
        for course in courses:
            # Delete all related data for each course
            quizzes = Quiz.query.filter_by(course_id=course.id).all()
            for quiz in quizzes:
                Result.query.filter_by(quiz_id=quiz.id).delete()
                Question.query.filter_by(quiz_id=quiz.id).delete()
            
            Quiz.query.filter_by(course_id=course.id).delete()
            Assignment.query.filter_by(course_id=course.id).delete()
            Content.query.filter_by(course_id=course.id).delete()
            
            attendance_sessions = AttendanceSession.query.filter_by(course_id=course.id).all()
            for session in attendance_sessions:
                AttendanceRecord.query.filter_by(session_id=session.id).delete()
            AttendanceSession.query.filter_by(course_id=course.id).delete()
            
            Enrollment.query.filter_by(course_id=course.id).delete()
            CourseCategoryMapping.query.filter_by(course_id=course.id).delete()
            CourseReview.query.filter_by(course_id=course.id).delete()
            
            db.session.delete(course)
        
        # Delete the instructor user
        db.session.delete(current_user)
        db.session.commit()
        
        flash('Your instructor account and all associated courses have been deleted.', 'success')
        return redirect(url_for('main.home'))
    except Exception as e:
        db.session.rollback()
        flash(f'Error deleting account: {str(e)}', 'danger')
        return redirect(url_for('instructor.dashboard'))

@instructor_bp.route('/course-reviews')
@login_required
def course_reviews():
    if current_user.role != 'instructor':
        return redirect(url_for('main.home'))
    
    # Get all courses taught by this instructor with their reviews
    courses = Course.query.filter_by(instructor_id=current_user.id).all()
    
    courses_with_reviews = []
    for course in courses:
        reviews = CourseReview.query.filter_by(course_id=course.id).order_by(CourseReview.created_at.desc()).all()
        
        if reviews:
            avg_rating = db.session.query(func.avg(CourseReview.rating)).filter(CourseReview.course_id == course.id).scalar() or 0
            total_reviews = len(reviews)
            
            # Get student info for each review
            reviews_with_students = []
            for review in reviews:
                student = User.query.get(review.student_id)
                review.student = student
                reviews_with_students.append(review)
            
            courses_with_reviews.append((course, reviews_with_students, avg_rating, total_reviews))
    
    return render_template('instructor_course_reviews.html',
                           user=current_user,
                           courses_with_reviews=courses_with_reviews)
