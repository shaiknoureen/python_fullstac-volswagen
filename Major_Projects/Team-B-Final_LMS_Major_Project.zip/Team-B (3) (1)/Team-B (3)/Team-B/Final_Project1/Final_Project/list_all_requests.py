#!/usr/bin/env python
"""
List all course requests and their votes
"""
from app import create_app, db
from models import CourseRequest, CourseRequestVote, User

app = create_app()

with app.app_context():
    print("All Course Requests and Their Votes:\n")
    requests = CourseRequest.query.all()
    
    for req in requests:
        votes = CourseRequestVote.query.filter_by(request_id=req.id).all()
        print(f"Request: {req.title} (ID: {req.id}, Status: {req.status})")
        print(f"  Total Votes: {len(votes)}")
        for vote in votes:
            user = User.query.get(vote.student_id)
            user_name = user.name if user else f"DELETED (ID: {vote.student_id})"
            print(f"    - {user_name}")
        print()
