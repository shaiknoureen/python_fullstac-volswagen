#!/usr/bin/env python
"""
Clean up orphaned CourseRequestVote records where student_id doesn't exist in User table
"""
from app import create_app, db
from models import CourseRequestVote, User

app = create_app()

with app.app_context():
    # Find all orphaned votes (votes from non-existent users)
    all_votes = CourseRequestVote.query.all()
    
    orphaned_count = 0
    for vote in all_votes:
        user = User.query.get(vote.student_id)
        if not user:
            db.session.delete(vote)
            orphaned_count += 1
    
    db.session.commit()
    print(f"Deleted {orphaned_count} orphaned course request votes")
