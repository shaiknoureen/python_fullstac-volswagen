#!/usr/bin/env python
"""
List all users and the Python course votes
"""
from app import create_app, db
from models import CourseRequest, CourseRequestVote, User

app = create_app()

with app.app_context():
    # List all users
    print("All Users in System:")
    users = User.query.all()
    for user in users:
        print(f"  - ID {user.id}: {user.name} ({user.email}) - Role: {user.role}")
    
    print("\n\nPython Course Request Votes:")
    python_req = CourseRequest.query.filter_by(title='python').first()
    if python_req:
        votes = CourseRequestVote.query.filter_by(request_id=python_req.id).all()
        print(f"Request ID: {python_req.id}")
        print(f"Total Votes: {len(votes)}")
        for vote in votes:
            user = User.query.get(vote.student_id)
            print(f"  - Vote {vote.id}: student_id={vote.student_id}, user={user.name if user else 'DELETED'}")
