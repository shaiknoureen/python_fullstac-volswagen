#!/usr/bin/env python
"""
Delete ALL course requests and their votes from database
"""
from app import create_app, db
from models import CourseRequest, CourseRequestVote

app = create_app()

with app.app_context():
    # Delete all votes first
    votes = CourseRequestVote.query.all()
    print(f"Deleting {len(votes)} course request votes...")
    for vote in votes:
        db.session.delete(vote)
    
    # Delete all requests
    requests = CourseRequest.query.all()
    print(f"Deleting {len(requests)} course requests...")
    for req in requests:
        db.session.delete(req)
    
    db.session.commit()
    print("\nAll course requests and votes deleted successfully!")
    print("New users will now see an empty 'Request a Course' section.")
