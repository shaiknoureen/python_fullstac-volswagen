from app import create_app
from extensions import db, bcrypt
from models import User, Course, Content, Quiz, Question, Enrollment, Result
from datetime import datetime

app = create_app()

def seed_data():
    with app.app_context():
        print("Dropping existing tables...")
        db.drop_all()
        db.create_all()
        print("Tables recreated.")

        # --- Users ---
        print("Creating Users...")
        # Admin 
        admin_pass = bcrypt.generate_password_hash('admin123').decode('utf-8')
        admin = User(name='Aditi Sharma', email='admin@lms.com', password=admin_pass, role='admin')
        
        # Instructor
        inst_pass = bcrypt.generate_password_hash('pass123').decode('utf-8')
        instructor = User(name='Dr. Rajesh Kumar', email='instructor@lms.com', password=inst_pass, role='instructor')
        
        # Student
        std_pass = bcrypt.generate_password_hash('pass123').decode('utf-8')
        student = User(name='Rohan Das', email='student@lms.com', password=std_pass, role='student')
        
        db.session.add_all([admin, instructor, student])
        db.session.commit()

        # --- Courses ---
        print("Creating Courses...")
        c1 = Course(title='Complete Python Bootcamp', description='Master Python by building 100 projects in 100 days. Learn automation, game, app and web development, data science and machine learning.', instructor_id=instructor.id, status='Approved', thumbnail='images/course_python.png')
        c2 = Course(title='Modern Web Development', description='Become a full-stack web developer with just one course. HTML, CSS, Javascript, Node, React, MongoDB, build real projects.', instructor_id=instructor.id, status='Approved', thumbnail='images/course_webdev.png')
        c3 = Course(title='Machine Learning A-Z', description='Learn to create Machine Learning Algorithms in Python and R from two Data Science experts. Code templates included.', instructor_id=instructor.id, status='Approved', thumbnail='images/course_ml.png')
        
        db.session.add_all([c1, c2, c3])
        db.session.commit()

        # --- Enrollments & Progress ---
        print("Enrolling Student...")
        # Course 1: Completed
        e1 = Enrollment(user_id=student.id, course_id=c1.id, progress=100, completed=True)
        # Course 2: In Progress
        e2 = Enrollment(user_id=student.id, course_id=c2.id, progress=50, completed=False)
        # Course 3: Just Started
        e3 = Enrollment(user_id=student.id, course_id=c3.id, progress=0, completed=False)
        
        db.session.add_all([e1, e2, e3])
        db.session.commit()

        # --- Quizzes ---
        print("Creating Quizzes...")
        q1 = Quiz(course_id=c1.id, title='Python Basics Final Exam')
        db.session.add(q1)
        db.session.commit()
        
        ques1 = Question(quiz_id=q1.id, question_text='What is the output of print(2 ** 3)?', option_a='6', option_b='8', option_c='9', option_d='Error', correct_option='B')
        ques2 = Question(quiz_id=q1.id, question_text='Which keyword is used to define a function?', option_a='func', option_b='def', option_c='define', option_d='lambda', correct_option='B')
        db.session.add_all([ques1, ques2])
        db.session.commit()

        # --- Results ---
        print("Adding Quiz Results...")
        # Perfect Score on Python Quiz
        r1 = Result(user_id=student.id, quiz_id=q1.id, score=2) # 2/2
        db.session.add(r1)
        db.session.commit()

        print("Seed Data Injected Successfully!")
        print("------------------------------------------------")
        print("Login with:")
        print("Admin: admin@lms.com / admin123")
        print("Instructor: instructor@lms.com / pass123")
        print("Student: student@lms.com / pass123")

if __name__ == '__main__':
    seed_data()
