from flask import Blueprint, render_template, redirect, url_for, flash, request, abort
from flask_login import login_required, current_user
from extensions import db
from models import Announcement, Course, Enrollment, ForumThread, ForumReply, Notification, Message, User, UserProfile, Badge, UserBadge
from utils import create_notification

main_bp = Blueprint('main', __name__)

@main_bp.route('/')
def home():
    return render_template('landing.html')

@main_bp.route('/announcements')
@login_required
def announcements():
    courses = []
    if current_user.role == 'student':
        announcements_list = db.session.query(Announcement, User.full_name.label('created_by_name'), Course.title.label('course_title')) \
            .join(User, Announcement.created_by == User.id) \
            .outerjoin(Course, Announcement.course_id == Course.id) \
            .filter((Announcement.is_global == True) | (Announcement.course_id.in_(db.session.query(Enrollment.course_id).filter(Enrollment.user_id == current_user.id)))) \
            .order_by(Announcement.created_at.desc()).all()
    else:
        announcements_list = db.session.query(Announcement, User.full_name.label('created_by_name'), Course.title.label('course_title')) \
            .join(User, Announcement.created_by == User.id) \
            .outerjoin(Course, Announcement.course_id == Course.id) \
            .order_by(Announcement.created_at.desc()).all()
        if current_user.role == 'instructor':
            courses = Course.query.filter_by(instructor_id=current_user.id).order_by(Course.title.asc()).all()
        elif current_user.role == 'admin':
            courses = Course.query.order_by(Course.title.asc()).all()

    announcements = [
        {
            'id': announcement.id,
            'title': announcement.title,
            'content': announcement.content,
            'is_global': announcement.is_global,
            'created_at': announcement.created_at,
            'created_by_name': created_by_name,
            'course_title': course_title,
            'created_by': announcement.created_by
        }
        for announcement, created_by_name, course_title in announcements_list
    ]

    return render_template('announcements.html', announcements=announcements, courses=courses)

@main_bp.route('/announcement/create', methods=['POST'])
@login_required
def create_announcement():
    title = request.form.get('title')
    content = request.form.get('content')
    course_id = request.form.get('course_id')
    is_global = True if request.form.get('is_global') else False

    announcement = Announcement(title=title, content=content, course_id=course_id or None, is_global=is_global, created_by=current_user.id)
    db.session.add(announcement)

    if is_global:
        students = User.query.filter_by(role='student').all()
        for student in students:
            create_notification(student.id, f'New Announcement: {title}', content[:100], '/announcements')
    elif course_id:
        students = Enrollment.query.filter_by(course_id=course_id).all()
        for enrollment in students:
            create_notification(enrollment.user_id, f'Course Announcement: {title}', content[:100], '/announcements')

    db.session.commit()
    flash('Announcement created successfully!', 'success')
    return redirect(url_for('main.announcements'))

@main_bp.route('/course/<int:course_id>/forum')
@login_required
def course_forum(course_id):
    course = Course.query.get_or_404(course_id)
    threads = db.session.query(ForumThread, User.full_name.label('author_name'), db.func.count(ForumReply.id).label('reply_count')) \
        .join(User, ForumThread.created_by == User.id) \
        .outerjoin(ForumReply, ForumReply.thread_id == ForumThread.id) \
        .filter(ForumThread.course_id == course_id) \
        .group_by(ForumThread.id).order_by(ForumThread.created_at.desc()).all()

    formatted_threads = [
        {
            'id': thread.id,
            'title': thread.title,
            'content': thread.content,
            'created_at': thread.created_at,
            'author_name': author_name,
            'reply_count': reply_count
        }
        for thread, author_name, reply_count in threads
    ]

    return render_template('course_forum.html', course=course, threads=formatted_threads)

@main_bp.route('/course/<int:course_id>/forum/thread/create', methods=['POST'])
@login_required
def create_forum_thread(course_id):
    title = request.form.get('title')
    content = request.form.get('content')
    thread = ForumThread(course_id=course_id, title=title, content=content, created_by=current_user.id)
    db.session.add(thread)
    db.session.commit()
    flash('Discussion thread created!', 'success')
    return redirect(url_for('main.course_forum', course_id=course_id))

@main_bp.route('/forum/thread/<int:thread_id>')
@login_required
def forum_thread(thread_id):
    thread = db.session.query(ForumThread, User.full_name.label('author_name'), Course.id.label('course_id'), Course.title.label('course_title')) \
        .join(User, ForumThread.created_by == User.id) \
        .join(Course, ForumThread.course_id == Course.id) \
        .filter(ForumThread.id == thread_id).first()

    if not thread:
        abort(404)

    replies = db.session.query(ForumReply, User.full_name.label('author_name')) \
        .join(User, ForumReply.created_by == User.id) \
        .filter(ForumReply.thread_id == thread_id).order_by(ForumReply.created_at.asc()).all()

    reply_list = [
        {
            'content': reply.content,
            'author_name': author_name,
            'created_at': reply.created_at
        }
        for reply, author_name in replies
    ]

    thread_data = {
        'id': thread[0].id,
        'title': thread[0].title,
        'content': thread[0].content,
        'author_name': thread[1],
        'course_id': thread[2],
        'course_title': thread[3]
    }

    return render_template('forum_thread.html', thread=thread_data, replies=reply_list)

@main_bp.route('/forum/thread/<int:thread_id>/reply', methods=['POST'])
@login_required
def reply_forum_thread(thread_id):
    content = request.form.get('content')
    reply = ForumReply(thread_id=thread_id, content=content, created_by=current_user.id)
    db.session.add(reply)
    db.session.commit()
    flash('Reply posted!', 'success')
    return redirect(url_for('main.forum_thread', thread_id=thread_id))

@main_bp.route('/notifications')
@login_required
def notifications():
    notifications_list = Notification.query.filter_by(user_id=current_user.id).order_by(Notification.created_at.desc()).limit(50).all()
    Notification.query.filter_by(user_id=current_user.id, is_read=False).update({'is_read': True})
    db.session.commit()
    return render_template('notifications.html', notifications=notifications_list)

@main_bp.route('/messages')
@login_required
def messages():
    inbox = db.session.query(Message, User.full_name.label('sender_name')) \
        .join(User, Message.sender_id == User.id) \
        .filter(Message.receiver_id == current_user.id).order_by(Message.sent_at.desc()).all()

    sent = db.session.query(Message, User.full_name.label('receiver_name')) \
        .join(User, Message.receiver_id == User.id) \
        .filter(Message.sender_id == current_user.id).order_by(Message.sent_at.desc()).all()

    users = User.query.filter(User.id != current_user.id).order_by(User.full_name.asc()).all()

    return render_template('messages.html', inbox=inbox, sent=sent, users=users)

@main_bp.route('/messages/send', methods=['POST'])
@login_required
def send_message():
    receiver_id = request.form.get('receiver_id')
    subject = request.form.get('subject')
    message_text = request.form.get('message')

    message = Message(sender_id=current_user.id, receiver_id=receiver_id, subject=subject, message=message_text)
    db.session.add(message)
    create_notification(int(receiver_id), f'New Message: {subject}', message_text[:100], '/messages')
    db.session.commit()
    flash('Message sent successfully!', 'success')
    return redirect(url_for('main.messages'))

@main_bp.route('/messages/read/<int:message_id>')
@login_required
def read_message(message_id):
    message = Message.query.filter_by(id=message_id, receiver_id=current_user.id).first_or_404()
    message.is_read = True
    db.session.commit()
    return redirect(url_for('main.messages'))

@main_bp.route('/profile')
@login_required
def profile():
    profile_data = UserProfile.query.filter_by(user_id=current_user.id).first()
    badges = db.session.query(Badge).join(UserBadge, UserBadge.badge_id == Badge.id) \
        .filter(UserBadge.user_id == current_user.id).order_by(UserBadge.earned_at.desc()).all()
    return render_template('profile.html', user=current_user, profile=profile_data, badges=badges)

@main_bp.route('/profile/update', methods=['POST'])
@login_required
def update_profile():
    bio = request.form.get('bio', '')
    phone = request.form.get('phone', '')
    address = request.form.get('address', '')

    profile_data = UserProfile.query.filter_by(user_id=current_user.id).first()
    if profile_data:
        db.session.refresh(profile_data)  # Ensure the latest data is fetched from the database
    else:
        profile_data = UserProfile(user_id=current_user.id)  # Create a new profile if not exists
        db.session.add(profile_data)
        db.session.commit()

    profile_data.bio = bio
    profile_data.phone = phone
    profile_data.address = address

    db.session.commit()
    flash('Profile updated successfully!', 'success')
    return redirect(url_for('main.profile'))

@main_bp.route('/announcement/delete/<int:announcement_id>', methods=['POST'])
@login_required
def delete_announcement(announcement_id):
    announcement = Announcement.query.get_or_404(announcement_id)
    if announcement.created_by != current_user.id:
        abort(403)  # Forbidden if the user is not the creator

    db.session.delete(announcement)
    db.session.commit()
    flash('Announcement deleted successfully.', 'success')
    return redirect(url_for('main.announcements'))
