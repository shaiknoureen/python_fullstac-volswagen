from extensions import db
from models import Notification, Enrollment, Badge, UserBadge

def create_notification(user_id, title, message, link=None):
    notification = Notification(user_id=user_id, title=title, message=message, link=link)
    db.session.add(notification)
    db.session.commit()

def check_and_award_badges(user_id):
    # Badge: First enrollment
    enroll_count = Enrollment.query.filter_by(user_id=user_id).count()
    if enroll_count == 1:
        badge = Badge.query.filter_by(criteria='enroll_first_course').first()
        if badge and not UserBadge.query.filter_by(user_id=user_id, badge_id=badge.id).first():
            db.session.add(UserBadge(user_id=user_id, badge_id=badge.id))
            db.session.commit()
