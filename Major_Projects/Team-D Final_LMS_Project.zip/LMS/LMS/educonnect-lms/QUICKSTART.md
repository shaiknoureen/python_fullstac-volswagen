# Quick Start Guide - EduConnect LMS

## Getting Started in 5 Minutes

### Option 1: Quick Demo (No Backend Required)

1. Open `index.html` in your browser
2. Click "Login"
3. Use these credentials:
   - **Email**: student@example.com
   - **Password**: password123
   - **Role**: Student

The app will work in demo mode showing sample data.

### Option 2: Full Stack Setup (With Backend)

#### Step 1: Install Python Dependencies
```bash
cd backend
pip install Flask Flask-CORS Flask-Session Werkzeug python-dotenv
```

#### Step 2: Run Backend Server
```bash
cd backend
python app.py
```

Expected output:
```
* Running on http://0.0.0.0:5000
```

#### Step 3: Serve Frontend
Open terminal in project root:
```bash
python -m http.server 8000
```

#### Step 4: Open in Browser
- Navigate to `http://localhost:8000`
- Login with any of these credentials:
  - Student: student@example.com / password123
  - Instructor: instructor@example.com / password123
  - Admin: admin@example.com / password123

## Features by Role

### Student Dashboard
- View enrolled courses
- Submit assignments
- View grades
- Send messages to instructors
- Access course resources
- Track progress

### Instructor Dashboard
- Create and manage courses
- View enrolled students
- Create and grade assignments
- Communicate with students
- View student submissions
- Generate reports

### Admin Dashboard
- User management
- Course oversight
- System statistics
- Generate reports
- System settings
- Data export

## Responsive Design Testing

### Test on Different Screen Sizes

1. **Mobile (320px)**
   - Sidebar hidden by default
   - Full-width buttons
   - Single-column layout
   - Touch-friendly interface

2. **Tablet (768px)**
   - Two-column layout
   - Sidebar togglable
   - Optimized spacing

3. **Desktop (1200px)**
   - Fixed sidebar
   - Three-column layout
   - Full navigation

### Using DevTools
Press `F12` in browser → Toggle device toolbar → Select device preset

## Key Improvements Made

### ✅ Fully Responsive CSS
- Mobile-first design
- Enhanced media queries
- Touch-friendly buttons (44px minimum)
- Flexible layouts
- Responsive images

### ✅ Complete JavaScript Functionality
- All buttons are now functional
- API integration ready
- Form validation
- Error handling
- Loading states
- Notifications system

### ✅ Full-Stack Backend
- Flask REST API
- SQLite database
- Role-based access control
- Session management
- User authentication
- CRUD operations for all entities

### ✅ Enhanced User Experience
- Real-time validation
- Loading spinners
- Success/error notifications
- Debounced searches
- Smooth scrolling
- Auto-refresh data

## File Structure Navigation

```
📁 LMS/
  📁 educonnect-lms/
    📄 index.html              ← Start here (landing page)
    📄 login.html              ← Login page
    📄 register.html           ← Registration
    
    📁 admin/                  ← Admin pages
      📄 admin-dashboard.html
      📄 admin-users.html
      📄 admin-courses.html
      ...
    
    📁 student/                ← Student pages
      📄 student-dashboard.html
      📄 student-courses.html
      ...
    
    📁 instructor/             ← Instructor pages
      📄 instructor-dashboard.html
      📄 instructor-courses.html
      ...
    
    📁 css/                    ← Styles
      📄 style.css             (Global styles)
      📄 responsive.css        ✨ ENHANCED
      📄 admin.css             (Admin styles)
      📄 student.css           (Student styles)
      📄 instructor.css        (Instructor styles)
      ...
    
    📁 js/                     ← JavaScript
      📄 api-service.js        ✨ NEW (API utilities)
      📄 script.js             ✨ ENHANCED
      📄 auth.js               ✨ ENHANCED
      📄 admin.js              ✨ ENHANCED
      📄 student.js            ✨ ENHANCED
      📄 instructor.js         ✨ ENHANCED
      📄 calendar.js
      ...
    
    📁 backend/                ← Server
      📄 app.py                ✨ NEW (Flask app)
      📄 server.py             (HTTP server)
      📄 requirements.txt       ✨ UPDATED
      ...
```

## Common Tasks

### Create a New Course
**Student:** Enroll button on courses page
**Instructor:** Admin dashboard → Create Course
**Admin:** Admin Courses → Create Course

### Submit Assignment
1. Go to Assignments
2. Click "Submit Work"
3. Enter submission details
4. Click Submit
5. See success notification

### Grade Submission
**Instructor Only:**
1. Go to Assignments
2. Click "View Submissions"
3. Select student
4. Click "Edit"
5. Enter score and feedback
6. Save

### Manage Users
**Admin Only:**
1. Go to User Management
2. Search for user
3. Edit role or status
4. Delete if needed
5. Changes apply immediately

## Testing Checklist

### Frontend Testing
- [ ] Login with different roles
- [ ] Access role-specific pages
- [ ] Click all buttons
- [ ] Fill out all forms
- [ ] Test on mobile (DevTools)
- [ ] Test on tablet
- [ ] Test on desktop
- [ ] Verify notifications appear

### Backend Testing (With Flask Running)
- [ ] Create user via API
- [ ] Login via API
- [ ] Create course
- [ ] Enroll in course
- [ ] Submit assignment
- [ ] Send message
- [ ] Check database changes

### Responsive Testing
- [ ] Sidebar toggles on mobile
- [ ] Buttons are touch-sized
- [ ] Tables scroll on mobile
- [ ] Images scale properly
- [ ] Text is readable at all sizes
- [ ] No horizontal scrolling issues

## Troubleshooting

### "Cannot reach API" Error
```
✓ Make sure Flask is running on port 5000
✓ Check Network tab in DevTools
✓ Verify CORS is enabled
```

### Button Doesn't Work
```
✓ Check browser console (F12)
✓ Verify API endpoint exists
✓ Check authentication status
✓ Ensure data is valid
```

### Page Not Loading
```
✓ Clear browser cache (Ctrl+Shift+Delete)
✓ Check all JavaScript files are loaded (F12 → Network)
✓ Verify all CSS files are loaded
✓ Check console for errors
```

### Responsive Layout Issues
```
✓ Verify viewport meta tag in HTML
✓ Check mobile viewport in DevTools
✓ Clear CSS cache
✓ Reload page in responsive mode
```

## Performance Tips

1. **Clear Cache**: `Ctrl+Shift+Delete` → Clear cached images/files
2. **Check Network**: F12 → Network → Watch request times
3. **Monitor Console**: F12 → Console → Check for errors
4. **Disable Extensions**: Some browser extensions cause issues
5. **Update Browser**: Ensure you're on latest version

## Next Steps

1. **Customize Branding**: Edit colors in CSS
2. **Add Your Logo**: Replace favicon and images
3. **Configure Database**: Modify SQLite location in app.py
4. **Set up Email**: Add email provider for password recovery
5. **Deploy**: Use Heroku, AWS, or your hosting provider

## Getting Help

### Debug Mode
- Check browser console: `F12`
- Check Network requests: `F12 → Network`
- Check Flask output in terminal
- Look for red error messages

### Common Error Messages
- "401 Unauthorized" → Login again
- "403 Forbidden" → Wrong user role
- "404 Not Found" → API endpoint doesn't exist
- "500 Server Error" → Check Flask terminal

## Documentation Files

- `IMPLEMENTATION_GUIDE.md` - Detailed technical guide
- This file - Quick start guide
- `README.md` - Project overview
- Code comments - In HTML/CSS/JS files

---

**Ready to Go! 🚀**

Open `index.html` in your browser and start exploring EduConnect LMS!
