# EduConnect LMS - Quick Start Guide

## Overview
EduConnect is a full-stack Learning Management System built with Flask (backend) and Bootstrap (frontend) with complete CRUD operations for courses, assignments, grades, and messaging.

## System Requirements
- Python 3.13+
- Modern web browser (Chrome, Firefox, Safari, Edge)
- 2GB RAM minimum
- SQLite3 (included with Python)

## Quick Start (5 minutes)

### Step 1: Terminal 1 - Start Flask Backend
```bash
cd c:\Users\HP\Downloads\LMS\LMS\educonnect-lms\backend
python app.py
```
✓ Backend runs at: `http://localhost:5000`

### Step 2: Terminal 2 - Start HTTP Frontend Server
```bash
cd c:\Users\HP\Downloads\LMS\LMS\educonnect-lms
python -m http.server 8000
```
✓ Frontend runs at: `http://localhost:8000`

### Step 3: Open Browser
Navigate to: **http://localhost:8000**

### Step 4: Login with Demo Account
```
Email:    admin@educonnect.com
Password: admin123
```

---

## Available Demo Accounts

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@educonnect.com | admin123 |
| Instructor | instructor@educonnect.com | instructor123 |
| Student | student@educonnect.com | student123 |

---

## Features by Role

### Admin Dashboard
- **Users**: Create, edit, delete users
- **Courses**: Manage all courses
- **Assignments**: Oversee assignments
- **Messages**: View system messages
- **Settings**: Configure system settings
- **Profile**: Manage admin profile
- **Reports**: View system statistics

### Instructor Dashboard
- **Courses**: Create and manage courses
- **Assignments**: Create assignments and grade submissions
- **Students**: View enrolled students
- **Grades**: Manage student grades
- **Messages**: Communicate with students
- **Profile**: Manage profile information

### Student Dashboard
- **Courses**: Browse and enroll in courses
- **Assignments**: Submit assignments
- **Grades**: View grades and feedback
- **Messages**: Message instructors
- **Resources**: Access course materials
- **Profile**: Update profile information

---

## Creating Sample Data

### Add a New Course (as Instructor)
1. Login as instructor@educonnect.com
2. Go to **Instructor Courses**
3. Click **+ Add Course**
4. Fill in course details
5. Click **Save**

### Create an Assignment
1. In Instructor Courses, select a course
2. Click **+ Add Assignment**
3. Enter assignment details and due date
4. Click **Save**

### Enroll in a Course (as Student)
1. Login as student@educonnect.com
2. Go to **Student Courses**
3. Find available courses
4. Click **Enroll**

### Submit an Assignment
1. Go to **Student Assignments**
2. Find assignment
3. Click **Submit**
4. Enter submission text or upload file
5. Click **Submit**

### Grade a Submission (as Instructor)
1. Go to **Instructor Assignments**
2. Find assignment with submissions
3. Click **Grade**
4. Enter score and feedback
5. Click **Save**

---

## API Endpoints (Quick Reference)

### Authentication
- `POST /api/auth/login` - User login
- `POST /api/auth/logout` - User logout
- `POST /api/auth/register` - Register user
- `GET /api/auth/user` - Get current user

### Courses (5 endpoints)
- `GET /api/courses` - List all courses
- `GET /api/courses/<id>` - Get course details
- `POST /api/courses` - Create course
- `PUT /api/courses/<id>` - Update course
- `DELETE /api/courses/<id>` - Delete course

### Assignments (5 endpoints)
- `GET /api/assignments` - List assignments
- `GET /api/assignments/<id>` - Get assignment
- `POST /api/assignments` - Create assignment
- `PUT /api/assignments/<id>` - Update assignment
- `DELETE /api/assignments/<id>` - Delete assignment

### Submissions (2 endpoints)
- `GET /api/submissions` - List submissions
- `POST /api/submissions` - Create submission

### Grades (2 endpoints)
- `GET /api/grades` - Get grades
- `PUT /api/grades/<id>` - Grade submission

### Messages (2 endpoints)
- `GET /api/messages` - Get messages
- `POST /api/messages` - Send message

### Users (4 endpoints)
- `GET /api/users` - List users (admin)
- `GET /api/auth/user` - Get current user
- `PUT /api/users/<id>` - Update user
- `DELETE /api/users/<id>` - Delete user

---

## Troubleshooting

### Port Already in Use
```bash
# Kill process on port 5000 (Flask)
lsof -ti:5000 | xargs kill -9

# Kill process on port 8000 (HTTP)
lsof -ti:8000 | xargs kill -9
```

### Database Reset
```bash
# Delete the database
rm backend/lms.db

# Restart Flask (will recreate with demo data)
python app.py
```

### Session Issues
- Clear browser cookies: `Ctrl+Shift+Delete`
- Logout and login again
- Try in incognito/private window

### "Failed to Fetch" Errors
1. Ensure both servers are running
2. Check browser console for error messages
3. Verify CORS is enabled (backend logs should show requests)
4. Try clearing browser cache

### Login Fails
1. Verify correct credentials (check Demo Accounts above)
2. Ensure database has demo data (check `backend/lms.db`)
3. Check if user account is active (admin panel)

---

## File Locations

| Component | Location |
|-----------|----------|
| Backend | `backend/app.py` (main server) |
| Frontend | `index.html` (entry point) |
| Database | `backend/lms.db` |
| CSS Styles | `css/style.css` |
| JavaScript | `js/api-service.js` (main API client) |
| Admin Pages | `admin/*.html` |
| Instructor Pages | `instructor/*.html` |
| Student Pages | `student/*.html` |

---

## Development Tips

### Adding a New API Endpoint
1. Create route in `backend/app.py`
2. Add method to `APIService` class in `js/api-service.js`
3. Call method from appropriate page script
4. Test with curl or Postman

### Testing API Manually
```bash
# Login
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@educonnect.com","password":"admin123"}'

# Get courses
curl http://localhost:5000/api/courses
```

### Database Queries
```bash
# Access SQLite database
sqlite3 backend/lms.db

# View all users
sqlite> SELECT id, full_name, email, role FROM users;

# View courses
sqlite> SELECT id, title, instructor_id FROM courses;

# Exit
sqlite> .quit
```

---

## Performance Monitoring

### View Server Logs
```bash
# Terminal 1 (Flask)
# Shows all API requests and errors

# Terminal 2 (HTTP Server)
# Shows file serving requests
```

### Monitor Database Size
```bash
# Check database file size
du -h backend/lms.db
```

### Browser DevTools
- **Network Tab**: Monitor API calls
- **Console**: Check for JavaScript errors
- **Storage**: View session cookies

---

## Deployment Notes

### For Production Deployment
1. Change `SECRET_KEY` in `backend/app.py`
2. Set `app.debug = False`
3. Use production WSGI server (Gunicorn, uWSGI)
4. Configure proper CORS origins
5. Use HTTPS/SSL certificates
6. Implement proper database backups
7. Enable logging and monitoring
8. Configure email notifications
9. Set up regular security updates

### Recommended Stack
- **Server**: Nginx or Apache
- **Application**: Gunicorn + Flask
- **Database**: PostgreSQL (instead of SQLite)
- **Cache**: Redis
- **File Storage**: AWS S3
- **Email**: SendGrid or AWS SES

---

## Support & Documentation

### Key Files
- `IMPLEMENTATION_REPORT.md` - Full technical documentation
- `backend/README.md` - Backend setup guide
- `requirements.txt` - Python dependencies

### Testing
```bash
# Run smoke tests
cd backend
python -c "
import urllib.request, json, time
# Test API endpoints...
"
```

---

## Quick Command Reference

```bash
# Start Backend
cd backend && python app.py

# Start Frontend
python -m http.server 8000

# Create new user (database)
sqlite3 backend/lms.db
> INSERT INTO users (full_name, email, password, role) 
  VALUES ('Name', 'email@test.com', 'hash', 'student');

# View All Users
sqlite3 backend/lms.db "SELECT * FROM users;"

# Delete Database (for reset)
rm backend/lms.db

# Test API endpoint
curl http://localhost:5000/api/courses
```

---

## Contact & Support

For issues or questions:
1. Check browser console for error messages
2. Review `IMPLEMENTATION_REPORT.md` for detailed documentation
3. Check database integrity with SQLite3
4. Verify both servers are running
5. Clear browser cache and cookies

---

**System Status**: ✓ Fully Functional  
**Last Updated**: 2024  
**Version**: 1.0
