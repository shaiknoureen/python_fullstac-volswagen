/**
 * Global Application Scripts
 * Handles authentication, navigation, and UI interactions across the application
 */

document.addEventListener('DOMContentLoaded', function () {
  // ============= AUTHENTICATION & AUTHORIZATION =============
  
  function checkAuthentication() {
    const user = StorageManager.getUser();
    const currentPath = window.location.pathname;

    // Define protected routes by role
    const protectedRoutes = {
      student: [
        'student-dashboard.html',
        'student-courses.html',
        'student-assignments.html',
        'student-grades.html',
        'student-messages.html',
        'student-resources.html',
        'student-profile.html'
      ],
      instructor: [
        'instructor-dashboard.html',
        'instructor-courses.html',
        'instructor-students.html',
        'instructor-assignments.html',
        'instructor-grades.html',
        'instructor-messages.html',
        'instructor-profile.html'
      ],
      admin: [
        'admin-dashboard.html',
        'admin-users.html',
        'admin-courses.html',
        'admin-reports.html',
        'admin-settings.html',
        'admin-profile.html'
      ]
    };

    // Check if current page is protected
    let requiredRole = null;
    for (const [roleKey, pages] of Object.entries(protectedRoutes)) {
      if (pages.some(page => currentPath.includes(page))) {
        requiredRole = roleKey;
        break;
      }
    }

    if (requiredRole) {
      if (!user || user.role !== requiredRole) {
        // Redirect to login if not authenticated or wrong role
        window.location.href = '../login.html';
        return false;
      }
    }

    return true;
  }

  // ============= DISPLAY USER INFORMATION =============
  
  function displayUserInfo() {
    const user = StorageManager.getUser();

    if (user) {
      const userName = user.full_name || user.email.split('@')[0];
      const userRole = user.role.charAt(0).toUpperCase() + user.role.slice(1);

      // Update all user name elements
      document.querySelectorAll('.user-name').forEach(el => {
        el.textContent = userName;
      });

      // Update all user role elements
      document.querySelectorAll('.user-role').forEach(el => {
        el.textContent = userRole;
      });

      // Update all user email elements
      document.querySelectorAll('.user-email').forEach(el => {
        el.textContent = user.email;
      });

      // Update user avatars
      if (user.avatar_url) {
        document.querySelectorAll('.user-avatar').forEach(el => {
          el.src = user.avatar_url;
        });
      }
    }
  }

  // ============= MOBILE NAVIGATION =============
  
  const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
  const sidebar = document.querySelector('.sidebar');

  if (mobileMenuBtn && sidebar) {
    mobileMenuBtn.addEventListener('click', function (e) {
      e.preventDefault();
      sidebar.classList.toggle('active');
    });

    // Close sidebar when a navigation link is clicked
    const sidebarLinks = sidebar.querySelectorAll('a');
    sidebarLinks.forEach(link => {
      link.addEventListener('click', function () {
        if (window.innerWidth <= 768) {
          sidebar.classList.remove('active');
        }
      });
    });
  }

  // Close sidebar when clicking outside on mobile
  document.addEventListener('click', function (e) {
    if (window.innerWidth <= 768 && sidebar && !sidebar.contains(e.target) && !mobileMenuBtn.contains(e.target)) {
      sidebar.classList.remove('active');
    }
  });

  // ============= LOGOUT FUNCTIONALITY =============
  
  const logoutBtns = document.querySelectorAll('[data-action="logout"], .logout-btn');
  logoutBtns.forEach(btn => {
    btn.addEventListener('click', async function (e) {
      e.preventDefault();

      if (confirm('Are you sure you want to logout?')) {
        try {
          await APIService.logout();
        } catch (error) {
          console.error('Logout error:', error);
        }

        StorageManager.clearUser();
        Notification.success('Logged out successfully!');

        setTimeout(() => {
          window.location.href = '../login.html';
        }, 500);
      }
    });
  });

  // ============= FORM HANDLING =============
  
  const forms = document.querySelectorAll('form');
  forms.forEach(form => {
    form.addEventListener('submit', function (e) {
      // Don't prevent default for actual form submission
      // This allows normal form processing
      const submitBtn = form.querySelector('button[type="submit"]');
      if (submitBtn) {
        submitBtn.disabled = true;
        const originalHTML = submitBtn.innerHTML;
        submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Processing...';

        // Re-enable after a timeout (for demo purposes)
        setTimeout(() => {
          submitBtn.disabled = false;
          submitBtn.innerHTML = originalHTML;
        }, 2000);
      }
    });
  });

  // ============= SMOOTH SCROLLING =============
  
  const anchorLinks = document.querySelectorAll('a[href^="#"]');
  anchorLinks.forEach(link => {
    link.addEventListener('click', function (e) {
      const href = this.getAttribute('href');
      if (href === '#') return;

      const target = document.querySelector(href);
      if (target) {
        e.preventDefault();
        target.scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
      }
    });
  });

  // ============= PROGRESS CIRCLE ANIMATION =============
  
  const progressCircles = document.querySelectorAll('.progress-circle');
  progressCircles.forEach(circle => {
    const value = circle.getAttribute('data-value');
    const fill = circle.querySelector('.progress-circle-fill');
    if (fill) {
      fill.style.strokeDasharray = `${value}, 100`;
    }
  });

  // ============= DROPDOWN MENU HANDLING =============
  
  const dropdownToggles = document.querySelectorAll('[data-bs-toggle="dropdown"]');
  dropdownToggles.forEach(toggle => {
    toggle.addEventListener('click', function (e) {
      // Bootstrap handles this automatically, but we can add custom logic
    });
  });

  // ============= TOOLTIP & POPOVER INITIALIZATION =============
  
  // Initialize Bootstrap tooltips
  const tooltipElements = document.querySelectorAll('[data-bs-toggle="tooltip"]');
  tooltipElements.forEach(el => {
    if (typeof bootstrap !== 'undefined') {
      new bootstrap.Tooltip(el);
    }
  });

  // ============= DYNAMIC TABLE ROW ACTIONS =============
  
  const tables = document.querySelectorAll('table');
  tables.forEach(table => {
    const rows = table.querySelectorAll('tbody tr');
    rows.forEach(row => {
      row.addEventListener('hover', function () {
        this.classList.add('table-active');
      });
    });
  });

  // ============= RESPONSIVE IMAGE LAZY LOADING =============
  
  if ('IntersectionObserver' in window) {
    const imageElements = document.querySelectorAll('img[data-src]');
    const imageObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const img = entry.target;
          img.src = img.getAttribute('data-src');
          img.removeAttribute('data-src');
          imageObserver.unobserve(img);
        }
      });
    });

    imageElements.forEach(img => imageObserver.observe(img));
  }

  // ============= WINDOW RESIZE HANDLER =============
  
  let resizeTimeout;
  window.addEventListener('resize', function () {
    clearTimeout(resizeTimeout);
    resizeTimeout = setTimeout(function () {
      // Handle any resize-specific logic
      if (window.innerWidth > 768 && sidebar) {
        sidebar.classList.remove('active');
      }
    }, 250);
  });

  // ============= KEYBOARD SHORTCUTS =============
  
  document.addEventListener('keydown', function (e) {
    // Escape key to close modals
    if (e.key === 'Escape') {
      const modals = document.querySelectorAll('.modal.show');
      modals.forEach(modal => {
        const bootstrapModal = bootstrap.Modal.getInstance(modal);
        if (bootstrapModal) {
          bootstrapModal.hide();
        }
      });
    }
  });

  // ============= INITIALIZATION =============
  
  // Run authentication check
  checkAuthentication();
  
  // Display user info
  displayUserInfo();

  // Log initialization
  console.log('Application initialized');
});