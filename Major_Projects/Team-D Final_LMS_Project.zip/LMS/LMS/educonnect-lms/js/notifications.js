// Notifications Scripts
document.addEventListener('DOMContentLoaded', function () {
  // Handle notification list actions
  const notificationList = document.querySelector('.notification-list');
  if (notificationList) {
    notificationList.addEventListener('click', function (e) {
      if (e.target.classList.contains('notification-item')) {
        e.target.classList.toggle('read');
        alert('Notification marked as read!');
      }
    });
  }

  // Handle clear notifications button
  const clearNotificationsBtn = document.getElementById('clearNotificationsBtn');
  if (clearNotificationsBtn) {
    clearNotificationsBtn.addEventListener('click', function () {
      if (confirm('Are you sure you want to clear all notifications?')) {
        notificationList.innerHTML = '<p>No notifications found.</p>';
        alert('Notifications cleared successfully!');
      }
    });
  }
});