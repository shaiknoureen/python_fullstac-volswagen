// Calendar Scripts
document.addEventListener('DOMContentLoaded', function () {
  // Initialize calendar
  const calendarEl = document.getElementById('calendar');
  if (calendarEl) {
    const calendar = new FullCalendar.Calendar(calendarEl, {
      initialView: 'dayGridMonth',
      events: [
        {
          title: 'Assignment Due',
          start: '2023-10-15',
          end: '2023-10-16',
          color: '#e74c3c',
        },
        {
          title: 'Lab Session',
          start: '2023-10-20',
          color: '#3498db',
        },
      ],
      eventClick: function (info) {
        alert('Event: ' + info.event.title);
      },
    });
    calendar.render();
  }

  // Handle calendar navigation
  const prevMonthBtn = document.getElementById('prevMonthBtn');
  const nextMonthBtn = document.getElementById('nextMonthBtn');

  if (prevMonthBtn && nextMonthBtn) {
    prevMonthBtn.addEventListener('click', function () {
      calendar.prev();
    });

    nextMonthBtn.addEventListener('click', function () {
      calendar.next();
    });
  }
});