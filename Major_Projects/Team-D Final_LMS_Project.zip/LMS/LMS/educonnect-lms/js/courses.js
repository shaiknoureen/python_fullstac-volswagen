// Courses Page Scripts
document.addEventListener('DOMContentLoaded', function () {
  const coursesGrid = document.getElementById('coursesGrid');
  const searchInput = document.getElementById('searchInput');
  const categoryFilter = document.getElementById('categoryFilter');
  const loadMoreBtn = document.getElementById('loadMoreBtn');

  // Sample courses data
  const courses = [
    {
      id: 1,
      title: 'Full Stack Web Development',
      category: 'technology',
      instructor: 'Dr. Sarah Johnson',
      instructorAvatar: 'https://picsum.photos/32/32?random=20',
      students: 245,
      rating: 4.8,
      duration: '12 weeks',
      level: 'Beginner',
      image: 'https://picsum.photos/400/250?random=2',
      description: 'Master HTML, CSS, JavaScript and popular frameworks to build modern web applications.',
      price: 99,
      originalPrice: 199
    },
    {
      id: 2,
      title: 'Data Science Fundamentals',
      category: 'data',
      instructor: 'Prof. Michael Chen',
      instructorAvatar: 'https://picsum.photos/32/32?random=21',
      students: 189,
      rating: 4.7,
      duration: '10 weeks',
      level: 'Intermediate',
      image: 'https://picsum.photos/400/250?random=3',
      description: 'Learn Python, statistics, machine learning and data visualization techniques.',
      price: 129,
      originalPrice: 249
    },
    {
      id: 3,
      title: 'Digital Marketing Mastery',
      category: 'business',
      instructor: 'Ms. Priya Patel',
      instructorAvatar: 'https://picsum.photos/32/32?random=22',
      students: 312,
      rating: 4.9,
      duration: '8 weeks',
      level: 'All Levels',
      image: 'https://picsum.photos/400/250?random=4',
      description: 'Comprehensive guide to SEO, social media marketing, email campaigns and analytics.',
      price: 89,
      originalPrice: 179
    },
    {
      id: 4,
      title: 'UI/UX Design Principles',
      category: 'design',
      instructor: 'Alex Rivera',
      instructorAvatar: 'https://picsum.photos/32/32?random=23',
      students: 156,
      rating: 4.6,
      duration: '6 weeks',
      level: 'Beginner',
      image: 'https://picsum.photos/400/250?random=12',
      description: 'Learn the fundamentals of user interface and user experience design.',
      price: 79,
      originalPrice: 149
    },
    {
      id: 5,
      title: 'Machine Learning with Python',
      category: 'data',
      instructor: 'Dr. James Wilson',
      instructorAvatar: 'https://picsum.photos/32/32?random=24',
      students: 278,
      rating: 4.8,
      duration: '14 weeks',
      level: 'Advanced',
      image: 'https://picsum.photos/400/250?random=13',
      description: 'Dive deep into machine learning algorithms and their implementation in Python.',
      price: 149,
      originalPrice: 299
    },
    {
      id: 6,
      title: 'Business Analytics',
      category: 'business',
      instructor: 'Dr. Lisa Thompson',
      instructorAvatar: 'https://picsum.photos/32/32?random=25',
      students: 203,
      rating: 4.7,
      duration: '9 weeks',
      level: 'Intermediate',
      image: 'https://picsum.photos/400/250?random=14',
      description: 'Learn to analyze business data and make data-driven decisions.',
      price: 109,
      originalPrice: 219
    },
    {
      id: 7,
      title: 'Mobile App Development',
      category: 'technology',
      instructor: 'Mark Johnson',
      instructorAvatar: 'https://picsum.photos/32/32?random=26',
      students: 198,
      rating: 4.5,
      duration: '11 weeks',
      level: 'Intermediate',
      image: 'https://picsum.photos/400/250?random=15',
      description: 'Build native mobile applications for iOS and Android platforms.',
      price: 119,
      originalPrice: 239
    },
    {
      id: 8,
      title: 'Cloud Computing Fundamentals',
      category: 'technology',
      instructor: 'Dr. Emily Davis',
      instructorAvatar: 'https://picsum.photos/32/32?random=27',
      students: 167,
      rating: 4.6,
      duration: '7 weeks',
      level: 'Beginner',
      image: 'https://picsum.photos/400/250?random=16',
      description: 'Learn cloud computing concepts, AWS, Azure, and deployment strategies.',
      price: 95,
      originalPrice: 189
    },
    {
      id: 9,
      title: 'Project Management Professional',
      category: 'business',
      instructor: 'Robert Martinez',
      instructorAvatar: 'https://picsum.photos/32/32?random=28',
      students: 234,
      rating: 4.7,
      duration: '10 weeks',
      level: 'Intermediate',
      image: 'https://picsum.photos/400/250?random=17',
      description: 'Master project management methodologies and earn your PMP certification.',
      price: 139,
      originalPrice: 279
    }
  ];

  let displayedCourses = 6;
  let filteredCourses = [...courses];

  // Function to render courses
  function renderCourses(coursesToRender) {
    coursesGrid.innerHTML = '';
    coursesToRender.slice(0, displayedCourses).forEach(course => {
      const categoryColors = {
        technology: 'bg-primary',
        data: 'bg-success',
        business: 'bg-warning',
        design: 'bg-info'
      };

      const courseCard = `
        <div class="col-lg-4 col-md-6">
          <div class="course-card-modern">
            <div class="course-image-wrapper">
              <img src="${course.image}" alt="${course.title}" class="course-image">
              <div class="course-overlay">
                <span class="course-category-badge ${categoryColors[course.category] || 'bg-primary'}">${course.category.charAt(0).toUpperCase() + course.category.slice(1)}</span>
                <div class="course-rating">
                  <i class="fas fa-star"></i>
                  <span>${course.rating}</span>
                </div>
              </div>
            </div>
            <div class="course-content">
              <div class="course-instructor">
                <img src="${course.instructorAvatar}" alt="Instructor" class="instructor-avatar">
                <span>${course.instructor}</span>
              </div>
              <h4 class="course-title">${course.title}</h4>
              <p class="course-description">${course.description}</p>
              <div class="course-stats">
                <div class="stat-item">
                  <i class="fas fa-users"></i>
                  <span>${course.students} students</span>
                </div>
                <div class="stat-item">
                  <i class="fas fa-clock"></i>
                  <span>${course.duration}</span>
                </div>
                <div class="stat-item">
                  <i class="fas fa-signal"></i>
                  <span>${course.level}</span>
                </div>
              </div>
              <div class="course-footer">
                <div class="course-price">
                  <span class="current-price">$${course.price}</span>
                  <span class="original-price">$${course.originalPrice}</span>
                </div>
                <a href="#" class="btn btn-primary btn-sm">Enroll Now</a>
              </div>
            </div>
          </div>
        </div>
      `;
      coursesGrid.insertAdjacentHTML('beforeend', courseCard);
    });
  }

  // Initial render
  renderCourses(filteredCourses);

  // Search functionality
  searchInput.addEventListener('input', function () {
    const searchTerm = this.value.toLowerCase();
    filteredCourses = courses.filter(course =>
      course.title.toLowerCase().includes(searchTerm) ||
      course.instructor.toLowerCase().includes(searchTerm) ||
      course.description.toLowerCase().includes(searchTerm)
    );
    displayedCourses = 6;
    renderCourses(filteredCourses);
  });

  // Category filter
  categoryFilter.addEventListener('change', function () {
    const category = this.value;
    if (category === '') {
      filteredCourses = [...courses];
    } else {
      filteredCourses = courses.filter(course => course.category === category);
    }
    displayedCourses = 6;
    renderCourses(filteredCourses);
  });

  // Load more functionality
  loadMoreBtn.addEventListener('click', function () {
    displayedCourses += 6;
    renderCourses(filteredCourses);
    if (displayedCourses >= filteredCourses.length) {
      this.style.display = 'none';
    }
  });
});