/**
 * API Service Utility
 * Handles all API calls with error handling and response management
 */

const API_BASE_URL = 'http://localhost:5000/api';

class APIService {
  /**
   * Make API request
   */
  static async request(endpoint, options = {}) {
    const url = `${API_BASE_URL}${endpoint}`;
    const defaultOptions = {
      headers: {
        'Content-Type': 'application/json',
      },
      credentials: 'include',
    };

    const config = {
      ...defaultOptions,
      ...options,
      headers: {
        ...defaultOptions.headers,
        ...options.headers,
      },
    };

    try {
      const response = await fetch(url, config);
      const data = await response.json();

      if (!response.ok) {
        throw new APIError(data.error || 'Request failed', response.status);
      }

      return data;
    } catch (error) {
      if (error instanceof APIError) {
        throw error;
      }
      throw new APIError(error.message || 'Network error', 0);
    }
  }

  /**
   * GET request
   */
  static get(endpoint, params = {}) {
    const queryString = new URLSearchParams(params).toString();
    const url = queryString ? `${endpoint}?${queryString}` : endpoint;
    return this.request(url, { method: 'GET' });
  }

  /**
   * POST request
   */
  static post(endpoint, data = {}) {
    return this.request(endpoint, {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  /**
   * PUT request
   */
  static put(endpoint, data = {}) {
    return this.request(endpoint, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  }

  /**
   * DELETE request
   */
  static delete(endpoint) {
    return this.request(endpoint, { method: 'DELETE' });
  }

  // ===== AUTHENTICATION =====
  static register(fullName, email, password, role) {
    return this.post('/auth/register', {
      full_name: fullName,
      email,
      password,
      role,
    });
  }

  static login(email, password) {
    return this.post('/auth/login', { email, password });
  }

  static logout() {
    return this.post('/auth/logout');
  }

  static getCurrentUser() {
    return this.get('/auth/user');
  }

  // ===== COURSES =====
  static getCourses(params = {}) {
    return this.get('/courses', params);
  }

  static getCourse(courseId) {
    return this.get(`/courses/${courseId}`);
  }

  static createCourse(data) {
    return this.post('/courses', data);
  }

  static updateCourse(courseId, data) {
    return this.put(`/courses/${courseId}`, data);
  }

  static deleteCourse(courseId) {
    return this.delete(`/courses/${courseId}`);
  }

  // ===== ENROLLMENTS =====
  static getEnrollments() {
    return this.get('/enrollments');
  }

  static enrollCourse(courseId) {
    return this.post('/enrollments', { course_id: courseId });
  }

  // ===== ASSIGNMENTS =====
  static getAssignments(courseId = null) {
    const params = courseId ? { course_id: courseId } : {};
    return this.get('/assignments', params);
  }

  static getAssignment(assignmentId) {
    return this.get(`/assignments/${assignmentId}`);
  }

  static createAssignment(data) {
    return this.post('/assignments', data);
  }

  static updateAssignment(assignmentId, data) {
    return this.put(`/assignments/${assignmentId}`, data);
  }

  static deleteAssignment(assignmentId) {
    return this.delete(`/assignments/${assignmentId}`);
  }

  // ===== SUBMISSIONS =====
  static getSubmissions() {
    return this.get('/submissions');
  }

  static createSubmission(data) {
    return this.post('/submissions', data);
  }

  // ===== GRADES =====
  static getGrades() {
    return this.get('/grades');
  }

  static gradeSubmission(submissionId, data) {
    return this.put(`/grades/${submissionId}`, data);
  }

  // ===== MESSAGES =====
  static getMessages() {
    return this.get('/messages');
  }

  static sendMessage(receiverId, subject, content) {
    return this.post('/messages', { receiver_id: receiverId, subject, content });
  }

  // ===== USERS (ADMIN) =====
  static getUsers(params = {}) {
    return this.get('/users', params);
  }

  static updateUser(userId, data) {
    return this.put(`/users/${userId}`, data);
  }

  static deleteUser(userId) {
    return this.delete(`/users/${userId}`);
  }

  // ===== STATISTICS =====
  static getDashboardStats() {
    return this.get('/stats/dashboard');
  }

  static getUserStats() {
    return this.get('/stats/user');
  }
}

/**
 * Custom API Error class
 */
class APIError extends Error {
  constructor(message, statusCode) {
    super(message);
    this.statusCode = statusCode;
    this.name = 'APIError';
  }
}

/**
 * UI Notification System
 */
class Notification {
  static show(message, type = 'info', duration = 3000) {
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} alert-dismissible fade show`;
    notification.setAttribute('role', 'alert');
    notification.innerHTML = `
      ${message}
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;

    const container = document.getElementById('notificationContainer');
    if (!container) {
      const newContainer = document.createElement('div');
      newContainer.id = 'notificationContainer';
      newContainer.style.position = 'fixed';
      newContainer.style.top = '80px';
      newContainer.style.right = '20px';
      newContainer.style.zIndex = '9999';
      newContainer.style.maxWidth = '400px';
      document.body.appendChild(newContainer);
      newContainer.appendChild(notification);
    } else {
      container.appendChild(notification);
    }

    if (duration) {
      setTimeout(() => {
        notification.remove();
      }, duration);
    }
  }

  static success(message, duration) {
    this.show(message, 'success', duration);
  }

  static error(message, duration) {
    this.show(message, 'danger', duration);
  }

  static warning(message, duration) {
    this.show(message, 'warning', duration);
  }

  static info(message, duration) {
    this.show(message, 'info', duration);
  }
}

/**
 * Delete Confirmation Modal
 */
class ConfirmationModal {
  static show(title, message, itemName = '') {
    return new Promise((resolve) => {
      let modal = document.getElementById('confirmationModal');
      
      if (!modal) {
        const modalHTML = `
          <div class="modal fade" id="confirmationModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
            <div class="modal-dialog modal-dialog-centered">
              <div class="modal-content">
                <div class="modal-header border-bottom-0">
                  <h5 class="modal-title" id="confirmationTitle">Confirm Action</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                  <p id="confirmationMessage"></p>
                  <p id="confirmationItemName" style="font-weight: 600; color: #dc3545;"></p>
                </div>
                <div class="modal-footer border-top-0">
                  <button type="button" class="btn btn-secondary" id="confirmCancel" data-bs-dismiss="modal">No, Cancel</button>
                  <button type="button" class="btn btn-danger" id="confirmYes">Yes, Delete</button>
                </div>
              </div>
            </div>
          </div>
        `;
        document.body.insertAdjacentHTML('beforeend', modalHTML);
        modal = document.getElementById('confirmationModal');
      }
      
      document.getElementById('confirmationTitle').textContent = title;
      document.getElementById('confirmationMessage').textContent = message;
      document.getElementById('confirmationItemName').textContent = itemName ? `"${itemName}"` : '';
      
      const bootstrapModal = new bootstrap.Modal(modal);
      bootstrapModal.show();
      
      const confirmYesBtn = document.getElementById('confirmYes');
      const cancelBtn = document.getElementById('confirmCancel');
      
      const handleYes = () => {
        bootstrapModal.hide();
        confirmYesBtn.removeEventListener('click', handleYes);
        cancelBtn.removeEventListener('click', handleCancel);
        resolve(true);
      };
      
      const handleCancel = () => {
        confirmYesBtn.removeEventListener('click', handleYes);
        cancelBtn.removeEventListener('click', handleCancel);
        resolve(false);
      };
      
      confirmYesBtn.addEventListener('click', handleYes);
      cancelBtn.addEventListener('click', handleCancel);
    });
  }
}

/**
 * Form Validation Utility
 */
class FormValidator {
  static email(email) {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
  }

  static password(password) {
    return password && password.length >= 8;
  }

  static required(value) {
    return value && value.trim().length > 0;
  }

  static url(url) {
    try {
      new URL(url);
      return true;
    } catch {
      return false;
    }
  }

  static phone(phone) {
    const regex = /^[\d\s\-\+\(\)]+$/;
    return regex.test(phone) && phone.replace(/\D/g, '').length >= 10;
  }

  static minLength(value, length) {
    return value && value.length >= length;
  }

  static maxLength(value, length) {
    return value && value.length <= length;
  }

  static match(value1, value2) {
    return value1 === value2;
  }
}

/**
 * Local Storage Manager
 */
class StorageManager {
  static set(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
      console.error('Storage error:', error);
    }
  }

  static get(key, defaultValue = null) {
    try {
      const value = localStorage.getItem(key);
      return value ? JSON.parse(value) : defaultValue;
    } catch (error) {
      console.error('Storage error:', error);
      return defaultValue;
    }
  }

  static remove(key) {
    try {
      localStorage.removeItem(key);
    } catch (error) {
      console.error('Storage error:', error);
    }
  }

  static clear() {
    try {
      localStorage.clear();
    } catch (error) {
      console.error('Storage error:', error);
    }
  }

  static setUser(user) {
    this.set('user', user);
    this.set('userId', user.id);
    this.set('userRole', user.role);
    this.set('userEmail', user.email);
  }

  static getUser() {
    return this.get('user');
  }

  static clearUser() {
    this.remove('user');
    this.remove('userId');
    this.remove('userRole');
    this.remove('userEmail');
  }
}

/**
 * Utility Functions
 */
const Utils = {
  /**
   * Format date
   */
  formatDate(date, format = 'short') {
    const d = new Date(date);
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

    if (format === 'short') {
      return `${months[d.getMonth()]} ${d.getDate()}, ${d.getFullYear()}`;
    } else if (format === 'long') {
      return `${months[d.getMonth()]} ${d.getDate()}, ${d.getFullYear()} ${d.getHours()}:${String(d.getMinutes()).padStart(2, '0')}`;
    }

    return d.toLocaleDateString();
  },

  /**
   * Format currency
   */
  formatCurrency(amount, currency = 'USD') {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency,
    }).format(amount);
  },

  /**
   * Debounce function
   */
  debounce(func, delay) {
    let timeoutId;
    return function debounced(...args) {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => func.apply(this, args), delay);
    };
  },

  /**
   * Throttle function
   */
  throttle(func, delay) {
    let timeoutId;
    let lastRun = 0;
    return function throttled(...args) {
      const now = Date.now();
      if (now - lastRun >= delay) {
        func.apply(this, args);
        lastRun = now;
      } else {
        clearTimeout(timeoutId);
        timeoutId = setTimeout(() => {
          func.apply(this, args);
          lastRun = Date.now();
        }, delay - (now - lastRun));
      }
    };
  },

  /**
   * Capitalize string
   */
  capitalize(str) {
    return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
  },

  /**
   * Get time ago
   */
  timeAgo(date) {
    const seconds = Math.floor((new Date() - new Date(date)) / 1000);

    if (seconds < 60) return 'just now';
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    if (days < 7) return `${days}d ago`;
    const weeks = Math.floor(days / 7);
    if (weeks < 4) return `${weeks}w ago`;

    return this.formatDate(date, 'short');
  },
};

// Export for use in modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { APIService, Notification, FormValidator, StorageManager, Utils };
}
