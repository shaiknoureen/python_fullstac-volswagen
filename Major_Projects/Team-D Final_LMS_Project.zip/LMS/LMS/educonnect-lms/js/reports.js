/**
 * Admin Reports & Export
 * Handles PDF, Excel, and JSON export for detailed analysis reports
 */

document.addEventListener('DOMContentLoaded', async function () {
  const currentUser = StorageManager.getUser();
  
  if (!currentUser || currentUser.role !== 'admin') {
    Notification.error('Unauthorized access');
    return;
  }

  // Report data storage
  let reportData = {
    courses: [],
    students: [],
    instructors: [],
    enrollments: [],
    submissions: [],
    timestamp: new Date().toLocaleDateString()
  };

  // ============= LOAD REPORT DATA =============
  
  async function loadReportData() {
    try {
      Notification.info('Loading report data...');
      
      // Load all required data
      const stats = await APIService.getDashboardStats();
      const coursesRes = await APIService.getCourses({ limit: 1000 });
      const usersRes = await APIService.getUsers({ limit: 1000 });
      
      reportData.courses = coursesRes.courses || [];
      reportData.students = usersRes.users ? usersRes.users.filter(u => u.role === 'student') : [];
      reportData.instructors = usersRes.users ? usersRes.users.filter(u => u.role === 'instructor') : [];
      reportData.totalStats = stats;
      
      await populateReportTables();
      Notification.success('Report data loaded successfully');
    } catch (error) {
      console.error('Error loading report data:', error);
      Notification.error('Failed to load report data');
    }
  }

  // ============= POPULATE REPORT TABLES =============
  
  async function populateReportTables() {
    // Update summary cards
    document.getElementById('totalEnrolled').textContent = reportData.totalStats?.total_enrollments || 0;
    document.getElementById('coursesCompleted').textContent = '0'; // Calculate from submissions
    document.getElementById('activeInstructors').textContent = reportData.totalStats?.active_instructors || 0;
    
    // Calculate total revenue
    let totalRevenue = 0;
    reportData.courses.forEach(course => {
      totalRevenue += ((course.price || 0) * (course.student_count || 0));
    });
    document.getElementById('totalRevenue').textContent = `$${totalRevenue.toFixed(2)}`;

    // Populate course revenue table
    const revenueTable = document.querySelector('#revenueTable tbody');
    if (revenueTable) {
      revenueTable.innerHTML = '';
      reportData.courses.forEach(course => {
        const revenue = ((course.price || 0) * (course.student_count || 0));
        const row = document.createElement('tr');
        row.innerHTML = `
          <td>${course.id}</td>
          <td><strong>${course.title}</strong></td>
          <td>${course.student_count || 0}</td>
          <td>0</td>
          <td>$${(course.price || 0).toFixed(2)}</td>
          <td>$${revenue.toFixed(2)}</td>
          <td>${course.instructor?.full_name || 'N/A'}</td>
        `;
        revenueTable.appendChild(row);
      });
    }

    // Populate instructor table
    const instructorTable = document.querySelector('#instructorTable tbody');
    if (instructorTable) {
      instructorTable.innerHTML = '';
      reportData.instructors.forEach(instructor => {
        const courseCount = reportData.courses.filter(c => c.instructor_id === instructor.id).length;
        const studentCount = reportData.courses
          .filter(c => c.instructor_id === instructor.id)
          .reduce((sum, c) => sum + (c.student_count || 0), 0);
        
        const row = document.createElement('tr');
        row.innerHTML = `
          <td><strong>${instructor.full_name}</strong></td>
          <td>${courseCount}</td>
          <td>${studentCount}</td>
          <td>
            <span class="badge bg-success">4.5 / 5</span>
          </td>
          <td>
            <span class="badge bg-${instructor.is_active ? 'success' : 'danger'}">
              ${instructor.is_active ? 'Active' : 'Inactive'}
            </span>
          </td>
        `;
        instructorTable.appendChild(row);
      });
    }
  }

  // ============= EXPORT FUNCTIONS =============
  
  function generatePDFReport() {
    const element = document.querySelector('.content');
    const opt = {
      margin: 10,
      filename: `LMS-Report-${new Date().toISOString().split('T')[0]}.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { orientation: 'landscape', unit: 'mm', format: 'a4' }
    };

    const reportContent = `
      <html>
        <head>
          <meta charset="UTF-8">
          <title>LMS Comprehensive Report</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            h1 { color: #0056b3; border-bottom: 3px solid #0056b3; padding-bottom: 10px; }
            h2 { color: #0056b3; margin-top: 30px; }
            table { width: 100%; border-collapse: collapse; margin: 20px 0; }
            th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
            th { background-color: #0056b3; color: white; }
            tr:nth-child(even) { background-color: #f9f9f9; }
            .summary { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin: 20px 0; }
            .summary-box { border: 1px solid #ddd; padding: 15px; border-radius: 5px; }
            .summary-box h3 { margin: 0; color: #0056b3; }
            .summary-box .value { font-size: 28px; font-weight: bold; color: #28a745; }
            .footer { margin-top: 40px; border-top: 1px solid #ddd; padding-top: 10px; font-size: 12px; color: #666; }
          </style>
        </head>
        <body>
          <h1>EduConnect LMS - Comprehensive Analysis Report</h1>
          <p>Generated on: ${new Date().toLocaleString()}</p>
          
          <h2>Executive Summary</h2>
          <div class="summary">
            <div class="summary-box">
              <h3>Total Students Enrolled</h3>
              <div class="value">${reportData.totalStats?.total_enrollments || 0}</div>
            </div>
            <div class="summary-box">
              <h3>Active Courses</h3>
              <div class="value">${reportData.courses.length}</div>
            </div>
            <div class="summary-box">
              <h3>Active Instructors</h3>
              <div class="value">${reportData.totalStats?.active_instructors || 0}</div>
            </div>
            <div class="summary-box">
              <h3>Total Revenue</h3>
              <div class="value">$${calculateTotalRevenue().toFixed(2)}</div>
            </div>
          </div>

          <h2>Course Performance Analysis</h2>
          <table>
            <thead>
              <tr>
                <th>Course ID</th>
                <th>Course Name</th>
                <th>Instructor</th>
                <th>Students Enrolled</th>
                <th>Price</th>
                <th>Revenue Generated</th>
              </tr>
            </thead>
            <tbody>
              ${reportData.courses.map(course => `
                <tr>
                  <td>${course.id}</td>
                  <td>${course.title}</td>
                  <td>${course.instructor?.full_name || 'N/A'}</td>
                  <td>${course.student_count || 0}</td>
                  <td>$${(course.price || 0).toFixed(2)}</td>
                  <td>$${((course.price || 0) * (course.student_count || 0)).toFixed(2)}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>

          <h2>Instructor Performance Metrics</h2>
          <table>
            <thead>
              <tr>
                <th>Instructor Name</th>
                <th>Courses Created</th>
                <th>Total Students</th>
                <th>Average Rating</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              ${reportData.instructors.map(instructor => {
                const courseCount = reportData.courses.filter(c => c.instructor_id === instructor.id).length;
                const studentCount = reportData.courses
                  .filter(c => c.instructor_id === instructor.id)
                  .reduce((sum, c) => sum + (c.student_count || 0), 0);
                return `
                  <tr>
                    <td>${instructor.full_name}</td>
                    <td>${courseCount}</td>
                    <td>${studentCount}</td>
                    <td>4.5 / 5</td>
                    <td>${instructor.is_active ? 'Active' : 'Inactive'}</td>
                  </tr>
                `;
              }).join('')}
            </tbody>
          </table>

          <h2>User Statistics</h2>
          <table>
            <thead>
              <tr>
                <th>User Type</th>
                <th>Total Count</th>
                <th>Active</th>
                <th>Inactive</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Students</td>
                <td>${reportData.students.length}</td>
                <td>${reportData.students.filter(s => s.is_active).length}</td>
                <td>${reportData.students.filter(s => !s.is_active).length}</td>
              </tr>
              <tr>
                <td>Instructors</td>
                <td>${reportData.instructors.length}</td>
                <td>${reportData.instructors.filter(i => i.is_active).length}</td>
                <td>${reportData.instructors.filter(i => !i.is_active).length}</td>
              </tr>
            </tbody>
          </table>

          <div class="footer">
            <p>This is an automatically generated report from EduConnect LMS. For more information, please contact support@educonnect.com</p>
          </div>
        </body>
      </html>
    `;

    html2pdf().set(opt).from(reportContent).save();
    Notification.success('PDF report downloaded successfully');
  }

  function calculateTotalRevenue() {
    return reportData.courses.reduce((sum, course) => {
      return sum + ((course.price || 0) * (course.student_count || 0));
    }, 0);
  }

  function generateExcelReport() {
    const workbook = XLSX.utils.book_new();

    // Courses Sheet
    const courseData = reportData.courses.map(course => ({
      'Course ID': course.id,
      'Course Name': course.title,
      'Instructor': course.instructor?.full_name || 'N/A',
      'Students Enrolled': course.student_count || 0,
      'Category': course.category || 'General',
      'Price': course.price || 0,
      'Revenue': (course.price || 0) * (course.student_count || 0)
    }));
    const courseSheet = XLSX.utils.json_to_sheet(courseData);
    XLSX.utils.book_append_sheet(workbook, courseSheet, 'Courses');

    // Instructors Sheet
    const instructorData = reportData.instructors.map(instructor => ({
      'Instructor Name': instructor.full_name,
      'Email': instructor.email,
      'Courses Created': reportData.courses.filter(c => c.instructor_id === instructor.id).length,
      'Total Students': reportData.courses
        .filter(c => c.instructor_id === instructor.id)
        .reduce((sum, c) => sum + (c.student_count || 0), 0),
      'Status': instructor.is_active ? 'Active' : 'Inactive'
    }));
    const instructorSheet = XLSX.utils.json_to_sheet(instructorData);
    XLSX.utils.book_append_sheet(workbook, instructorSheet, 'Instructors');

    // Summary Sheet
    const summaryData = [{
      'Metric': 'Total Students Enrolled',
      'Value': reportData.totalStats?.total_enrollments || 0
    }, {
      'Metric': 'Active Courses',
      'Value': reportData.courses.length
    }, {
      'Metric': 'Active Instructors',
      'Value': reportData.totalStats?.active_instructors || 0
    }, {
      'Metric': 'Total Revenue',
      'Value': `$${calculateTotalRevenue().toFixed(2)}`
    }];
    const summarySheet = XLSX.utils.json_to_sheet(summaryData);
    XLSX.utils.book_append_sheet(workbook, summarySheet, 'Summary');

    XLSX.writeFile(workbook, `LMS-Report-${new Date().toISOString().split('T')[0]}.xlsx`);
    Notification.success('Excel report downloaded successfully');
  }

  function generateJSONReport() {
    const report = {
      generatedDate: new Date().toISOString(),
      summary: {
        totalStudentsEnrolled: reportData.totalStats?.total_enrollments || 0,
        activeCourses: reportData.courses.length,
        activeInstructors: reportData.totalStats?.active_instructors || 0,
        totalRevenue: calculateTotalRevenue(),
        totalUsers: reportData.students.length + reportData.instructors.length
      },
      courses: reportData.courses,
      instructors: reportData.instructors,
      userStatistics: {
        students: {
          total: reportData.students.length,
          active: reportData.students.filter(s => s.is_active).length,
          inactive: reportData.students.filter(s => !s.is_active).length
        },
        instructors: {
          total: reportData.instructors.length,
          active: reportData.instructors.filter(i => i.is_active).length,
          inactive: reportData.instructors.filter(i => !i.is_active).length
        }
      }
    };

    const dataStr = JSON.stringify(report, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `LMS-Report-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);

    Notification.success('JSON report downloaded successfully');
  }

  // ============= EVENT LISTENERS =============
  
  document.getElementById('exportPdfBtn')?.addEventListener('click', generatePDFReport);
  document.getElementById('exportExcelBtn')?.addEventListener('click', generateExcelReport);
  document.getElementById('exportJsonBtn')?.addEventListener('click', generateJSONReport);
  document.getElementById('refreshReportBtn')?.addEventListener('click', loadReportData);

  // ============= INITIALIZATION =============
  
  await loadReportData();

  // Refresh data every 5 minutes
  setInterval(loadReportData, 300000);
});
