/**
 * Enhanced Student Dashboard Scripts
 * Real-time enrollments, assignments, and course tracking
 */

document.addEventListener('DOMContentLoaded', async function () {
  const currentUser = StorageManager.getUser();
  
  if (!currentUser || currentUser.role !== 'student') {
    Notification.error('Unauthorized access');
    setTimeout(() => window.location.href = '../login.html', 1000);
    return;
  }

  const courseModalEl = document.getElementById('courseModal');
  const courseModal = courseModalEl ? new bootstrap.Modal(courseModalEl) : null;

  const assignmentModalEl = document.getElementById('assignmentModal');
  const assignmentModal = assignmentModalEl ? new bootstrap.Modal(assignmentModalEl) : null;

  const messageModalEl = document.getElementById('messageModal');
  const messageModal = messageModalEl ? new bootstrap.Modal(messageModalEl) : null;

  // ============= LOAD STUDENT COURSES =============
  async function loadStudentCourses(limit = 3) {
    try {
      const response = await APIService.getEnrollments();
      const enrollments = response.enrollments || [];
      
      const coursesContainer = document.querySelector('.student-courses-list, [data-courses-container]');
      const viewAllBtn = document.querySelector('[data-action="view-all-courses"]');

      if (coursesContainer) {
        coursesContainer.innerHTML = '';
        
        // Show first 3 or all depending on context
        const displayCourses = limit ? enrollments.slice(0, limit) : enrollments;

        if (displayCourses.length === 0) {
          coursesContainer.innerHTML = `
            <div class="col-12">
              <div class="alert alert-info">
                <i class="fas fa-info-circle me-2"></i>
                You are not enrolled in any courses yet. <a href="student-courses.html">Browse available courses</a>
              </div>
            </div>
          `;
          return;
        }

        displayCourses.forEach(enrollment => {
          const courseCard = document.createElement('div');
          courseCard.className = 'col-md-4 mb-4';
          const progress = enrollment.progress || 0;
          
          courseCard.innerHTML = `
            <div class="course-card-sm h-100">
              <div class="course-image">
                <img src="https://picsum.photos/300/120?random=${enrollment.course_id}" alt="${enrollment.title}" class="w-100">
                <div class="course-progress p-2">
                  <div class="progress" style="height: 6px;">
                    <div class="progress-bar bg-success" style="width: ${progress}%"></div>
                  </div>
                  <small>${progress}% complete</small>
                </div>
              </div>
              <div class="course-body p-3">
                <h5 class="mb-1">${enrollment.title}</h5>
                <p class="small text-muted mb-3">Instructor: ${enrollment.instructor_name || 'N/A'}</p>
                <div class="d-flex justify-content-between align-items-center">
                  <span class="badge bg-${enrollment.status === 'active' ? 'success' : 'warning'}">${enrollment.status}</span>
                  <button class="btn btn-sm btn-outline-primary continue-course" data-course-id="${enrollment.course_id}">
                    Continue
                  </button>
                </div>
              </div>
            </div>
          `;
          coursesContainer.appendChild(courseCard);
        });

        // Handle "View All" button
        if (viewAllBtn && enrollments.length > 3) {
          viewAllBtn.style.display = 'block';
          viewAllBtn.addEventListener('click', function () {
            window.location.href = 'student-courses.html';
          });
        }
      }
    } catch (error) {
      console.error('Error loading courses:', error);
      Notification.error('Failed to load courses');
    }
  }

  // ============= LOAD ASSIGNMENTS =============
  async function loadStudentAssignments() {
    try {
      const response = await APIService.getAssignments();
      const assignments = response.assignments || [];
      
      const assignmentsContainer = document.querySelector('[data-assignments-container]');
      
      if (assignmentsContainer) {
        assignmentsContainer.innerHTML = '';
        
        if (assignments.length === 0) {
          assignmentsContainer.innerHTML = `
            <div class="col-12">
              <div class="alert alert-info">
                No assignments available yet.
              </div>
            </div>
          `;
          return;
        }

        assignments.forEach(assignment => {
          const row = document.createElement('tr');
          const dueDate = new Date(assignment.due_date);
          const isOverdue = dueDate < new Date();
          
          row.innerHTML = `
            <td>${assignment.title}</td>
            <td>${assignment.course_id}</td>
            <td>${Utils.formatDate(assignment.due_date)}</td>
            <td>
              <span class="badge bg-${isOverdue ? 'danger' : 'warning'}">
                ${isOverdue ? 'Overdue' : 'Pending'}
              </span>
            </td>
            <td>
              <div class="btn-group btn-group-sm">
                <button class="btn btn-outline-primary view-assignment" data-assignment-id="${assignment.id}">
                  <i class="fas fa-eye"></i>
                </button>
                <button class="btn btn-outline-success submit-work" data-assignment-id="${assignment.id}">
                  <i class="fas fa-upload"></i> Submit
                </button>
              </div>
            </td>
          `;
          assignmentsContainer.appendChild(row);
        });
      }
    } catch (error) {
      console.error('Error loading assignments:', error);
    }
  }
  
  // ============= ASSIGNMENT ACTIONS =============
  
  document.addEventListener('click', async function (e) {
    if (e.target.classList.contains('view-assignment') || e.target.closest('.view-assignment')) {
      const btn = e.target.closest('.view-assignment');
      const assignmentId = btn.getAttribute('data-assignment-id');
      try {
        const assignment = await APIService.getAssignment(assignmentId);
        Notification.info(`Assignment: ${assignment.title}\nDue: ${Utils.formatDate(assignment.due_date)}`, 5000);
      } catch (error) {
        Notification.error('Failed to load assignment details');
      }
    }
    
    if (e.target.classList.contains('submit-work') || e.target.closest('.submit-work')) {
      const btn = e.target.closest('.submit-work');
      const assignmentId = btn.getAttribute('data-assignment-id');
      
      // Open submission modal or dialog
      const content = prompt('Enter your assignment submission (or paste text):');
      if (content) {
        try {
          await APIService.createSubmission({
            assignment_id: assignmentId,
            content: content
          });
          Notification.success('Assignment submitted successfully!');
          loadStudentAssignments();
        } catch (error) {
          Notification.error('Failed to submit assignment');
        }
      }
    }
    
    if (e.target.classList.contains('continue-course') || e.target.closest('.continue-course')) {
      const btn = e.target.closest('.continue-course');
      const courseId = btn.getAttribute('data-course-id');
      window.location.href = `student-courses.html?courseId=${courseId}`;
    }
  });

  // ============= LOAD GRADES =============
  async function loadStudentGrades() {
    try {
      const response = await APIService.getGrades();
      const gradesContainer = document.querySelector('[data-grades-container]');
      
      if (gradesContainer && response.grades) {
        gradesContainer.innerHTML = '';
        
        response.grades.forEach(grade => {
          const row = document.createElement('tr');
          const percentage = Math.round((grade.score / grade.max_score) * 100);
          
          row.innerHTML = `
            <td>${grade.title}</td>
            <td>${grade.course_title}</td>
            <td><strong>${grade.score}/${grade.max_score}</strong></td>
            <td>
              <span class="badge bg-${percentage >= 80 ? 'success' : percentage >= 70 ? 'warning' : 'danger'}">
                ${percentage}%
              </span>
            </td>
            <td><small>${grade.feedback || '—'}</small></td>
          `;
          gradesContainer.appendChild(row);
        });
      }
    } catch (error) {
      console.error('Error loading grades:', error);
    }
  }

  // ============= INITIALIZATION =============
  
  await loadStudentCourses(3);
  await loadStudentAssignments();
  await loadStudentGrades();
  
  // Refresh data every 60 seconds
  setInterval(() => {
    loadStudentCourses(3);
    loadStudentAssignments();
    loadStudentGrades();
  }, 60000);
          coursesContainer.appendChild(courseCard);
        });
      } else if (coursesContainer) {
        coursesContainer.innerHTML = '<div class="col-12"><p class="text-muted">No courses found.</p></div>';
      }
    } catch (error) {
      console.error('Error loading courses:', error);
      if (error.statusCode === 0) {
        console.log('API unavailable, using demo data');
      }
    }
  }

  // ============= LOAD ASSIGNMENTS =============
  
  async function loadAssignments() {
    try {
      const response = await APIService.getAssignments();
      const assignmentList = document.querySelector('.assignment-list');
      
      if (assignmentList && response.assignments && response.assignments.length > 0) {
        assignmentList.innerHTML = '';
        
        response.assignments.forEach(assignment => {
          const dueDate = new Date(assignment.due_date);
          const isOverdue = dueDate < new Date();
          
          const item = document.createElement('div');
          item.className = 'assignment-item';
          item.innerHTML = `
            <div class="assignment-info">
              <h4>${assignment.title}</h4>
              <p>Due: ${Utils.formatDate(assignment.due_date)}</p>
              <p>Max Score: ${assignment.max_score}</p>
              <p>Status: <span class="badge ${isOverdue ? 'bg-danger' : 'bg-warning'}">
                ${isOverdue ? 'Overdue' : 'Pending'}
              </span></p>
            </div>
            <div class="assignment-actions">
              <button class="btn btn-primary view-assignment" data-assignment-id="${assignment.id}">View Details</button>
              <button class="btn btn-success submit-assignment" data-assignment-id="${assignment.id}">Submit Work</button>
            </div>
          `;
          assignmentList.appendChild(item);
        });
      }
    } catch (error) {
      console.error('Error loading assignments:', error);
    }
  }

  // ============= ASSIGNMENT ACTIONS =============
  
  document.addEventListener('click', async function (e) {
    // View assignment details
    if (e.target.classList.contains('view-assignment')) {
      const assignmentId = e.target.getAttribute('data-assignment-id');
      Notification.info('Loading assignment details...');
      // Load and display assignment details
    }

    // Submit assignment (open modal)
    if (e.target.classList.contains('submit-assignment')) {
      const assignmentId = e.target.getAttribute('data-assignment-id');
      const form = document.getElementById('assignmentSubmitForm');
      if (form) {
        form.reset();
        form.elements['assignment_id'].value = assignmentId;
        assignmentModal?.show();
      }
    }

    // View course
    if (e.target.classList.contains('view-course')) {
      const courseId = e.target.getAttribute('data-course-id');
      window.location.href = `student-course.html?id=${courseId}`;
    }
  });

  // ============= LOAD MESSAGES =============
  
  async function loadMessages() {
    try {
      const response = await APIService.getMessages();
      const messageList = document.querySelector('.message-list');
      
      if (messageList && response.messages && response.messages.length > 0) {
        messageList.innerHTML = '';
        
        response.messages.forEach(message => {
          const item = document.createElement('div');
          item.className = 'message-item';
          item.innerHTML = `
            <div class="message-header">
              <img src="${message.sender_avatar || 'https://via.placeholder.com/32'}" alt="${message.sender_name}" class="rounded-circle me-2" width="32">
              <div>
                <h6>${message.sender_name}</h6>
                <small class="text-muted">${Utils.timeAgo(message.created_at)}</small>
              </div>
            </div>
            <div class="message-body">
              <p><strong>${message.subject}</strong></p>
              <p>${message.content}</p>
            </div>
            <div class="message-actions">
              <button class="btn btn-sm btn-primary reply-message" data-message-id="${message.id}" data-sender-id="${message.sender_id}">Reply</button>
              <button class="btn btn-sm btn-outline-danger delete-message" data-message-id="${message.id}">Delete</button>
            </div>
          `;
          messageList.appendChild(item);
        });
      }
    } catch (error) {
      console.error('Error loading messages:', error);
    }
  }

  // ============= MESSAGE ACTIONS =============
  
  document.addEventListener('click', async function (e) {
    // Reply to message (open compose modal with receiver)
    if (e.target.classList.contains('reply-message')) {
      const senderId = e.target.getAttribute('data-sender-id');
      const form = document.getElementById('messageForm');
      if (form) {
        form.reset();
        form.elements['receiver_id'].value = senderId;
        messageModal?.show();
      }
    }

    // Compose new message (open modal)
    if (e.target.classList.contains('compose-message')) {
      const form = document.getElementById('messageForm');
      if (form) {
        form.reset();
        messageModal?.show();
      }
    }
  });

  // ============= PROFILE FORM =============
  
  const profileForm = document.getElementById('profileForm');
  if (profileForm) {
    profileForm.addEventListener('submit', async function (e) {
      e.preventDefault();

      const formData = new FormData(profileForm);
      const profileData = Object.fromEntries(formData);

      try {
        const user = StorageManager.getUser() || {};
        // Build full name if first/last provided
        if (profileData.firstName || profileData.lastName) {
          profileData.name = `${profileData.firstName || ''} ${profileData.lastName || ''}`.trim();
        }

        // Attempt to update via API if endpoint exists
        try {
          await APIService.updateUser(user.id, profileData);
        } catch (err) {
          // ignore API errors if endpoint not available
          console.debug('Profile API update failed', err);
        }

        user.full_name = profileData.name || user.full_name;
        StorageManager.setUser(user);

        Notification.success('Profile updated successfully!');
      } catch (error) {
        Notification.error('Failed to update profile');
      }
    });
  }

  // ============= COURSE ENROLLMENT =============
  
  const enrollButtons = document.querySelectorAll('[data-action="enroll"]');
  enrollButtons.forEach(btn => {
    btn.addEventListener('click', async function () {
      const courseId = this.getAttribute('data-course-id');

      try {
        const response = await APIService.enrollCourse(courseId);
        Notification.success('Enrolled in course successfully!');
        loadStudentCourses();
      } catch (error) {
        if (error.statusCode === 409) {
          Notification.warning('Already enrolled in this course');
        } else {
          Notification.error('Enrollment failed');
        }
      }
    });
  });

  // ============= LOAD GRADES =============
  
  async function loadGrades() {
    try {
      const response = await APIService.getGrades();
      const gradeTable = document.querySelector('.grade-table');
      
      if (gradeTable && response.grades && response.grades.length > 0) {
        const tbody = gradeTable.querySelector('tbody') || gradeTable;
        tbody.innerHTML = '';
        
        response.grades.forEach(grade => {
          const row = document.createElement('tr');
          row.innerHTML = `
            <td>${grade.course_title || 'Course'}</td>
            <td>${grade.title || 'Assignment'}</td>
            <td>${grade.score}/${grade.max_score}</td>
            <td>${grade.feedback || '—'}</td>
          `;
          tbody.appendChild(row);
        });
      }
    } catch (error) {
      console.error('Error loading grades:', error);
    }
  }

  // ============= LOAD STATISTICS =============
  
  async function loadUserStats() {
    try {
      const stats = await APIService.getUserStats();
      
      document.getElementById('enrolledCourses').textContent = stats.enrolled_courses || 0;
      document.getElementById('completedAssignments').textContent = stats.completed_assignments || 0;
    } catch (error) {
      console.error('Error loading stats:', error);
    }
  }

  // ============= SEARCH COURSES =============
  
  const searchCourseInput = document.querySelector('[data-action="search-courses"]');
  if (searchCourseInput) {
    const debouncedSearch = Utils.debounce(async function (e) {
      const query = e.target.value;
      
      try {
        const response = await APIService.getCourses({ search: query });
        // Update course list with search results
        console.log('Search results:', response);
      } catch (error) {
        console.error('Search error:', error);
      }
    }, 300);

    searchCourseInput.addEventListener('keyup', debouncedSearch);
  }

  // ============= INITIALIZATION =============
  
  // Wire submission form handler if present
  const assignmentSubmitForm = document.getElementById('assignmentSubmitForm');
  if (assignmentSubmitForm) {
    assignmentSubmitForm.addEventListener('submit', async function (e) {
      e.preventDefault();
      const fd = new FormData(assignmentSubmitForm);
      const payload = Object.fromEntries(fd);
      const assignmentId = payload.assignment_id;

      try {
        // If API supports file uploads, implement with fetch + FormData. For now use APIService.createSubmission if exists.
        if (APIService.createSubmission) {
          await APIService.createSubmission({ assignment_id: assignmentId, content: payload.content });
        }
        Notification.success('Assignment submitted successfully!');
        assignmentModal?.hide();
        loadAssignments();
      } catch (err) {
        Notification.error('Failed to submit assignment');
      }
    });
  }

  const messageForm = document.getElementById('messageForm');
  if (messageForm) {
    messageForm.addEventListener('submit', async function (e) {
      e.preventDefault();
      const fd = new FormData(messageForm);
      const payload = Object.fromEntries(fd);
      try {
        await APIService.sendMessage(payload.receiver_id || null, payload.subject, payload.content);
        Notification.success('Message sent successfully!');
        messageModal?.hide();
        loadMessages();
      } catch (err) {
        Notification.error('Failed to send message');
      }
    });
  }

  loadStudentCourses();
  loadAssignments();
  loadMessages();
  loadGrades();
  loadUserStats();

  // Refresh data every 60 seconds
  setInterval(() => {
    loadAssignments();
    loadMessages();
    loadGrades();
  }, 60000);
});