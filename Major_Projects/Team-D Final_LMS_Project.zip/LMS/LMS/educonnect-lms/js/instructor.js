/**
 * Enhanced Instructor Scripts
 * Real-time dashboard, course management, assignments, and student tracking
 */

document.addEventListener('DOMContentLoaded', async function () {
  const currentUser = StorageManager.getUser();
  
  if (!currentUser || currentUser.role !== 'instructor') {
    Notification.error('Unauthorized access');
    setTimeout(() => window.location.href = '../login.html', 1000);
    return;
  }

  // Initialize Bootstrap modals if present
  const courseModalEl = document.getElementById('courseModal');
  const courseModal = courseModalEl ? new bootstrap.Modal(courseModalEl) : null;

  const assignmentModalEl = document.getElementById('assignmentModal');
  const assignmentModal = assignmentModalEl ? new bootstrap.Modal(assignmentModalEl) : null;

  const messageModalEl = document.getElementById('messageModal');
  const messageModal = messageModalEl ? new bootstrap.Modal(messageModalEl) : null;
  
  // ============= REAL-TIME STATS =============
  
  async function loadInstructorStats() {
    try {
      const stats = await APIService.getUserStats();
      if (document.getElementById('totalCourses')) {
        document.getElementById('totalCourses').textContent = stats.total_courses || 0;
      }
      if (document.getElementById('totalStudents')) {
        document.getElementById('totalStudents').textContent = stats.total_students || 0;
      }
    } catch (error) {
      console.error('Error loading stats:', error);
    }
  }
  
  // Load stats on page load
  await loadInstructorStats();

  // ===== Courses =====
  async function loadInstructorCourses() {
    const container = document.querySelector('[data-courses-container]');
    if (!container) return;

    try {
      const res = await APIService.getCourses({ limit: 100 });
      const courses = res.courses || [];
      container.innerHTML = '';

      if (courses.length === 0) {
        container.innerHTML = `
          <div class="col-12">
            <div class="alert alert-info">
              <i class="fas fa-info-circle me-2"></i>
              No courses created yet. <button class="btn btn-sm btn-primary create-course">Create your first course</button>
            </div>
          </div>
        `;
        return;
      }

      courses.forEach(course => {
        const col = document.createElement('div');
        col.className = 'col-md-6 mb-4';
        col.innerHTML = `
          <div class="card course-card h-100">
            <img src="https://picsum.photos/400/200?random=${course.id}" class="card-img-top" alt="${course.title}" style="height: 200px; object-fit: cover;">
            <div class="card-body">
              <div class="d-flex justify-content-between align-items-start mb-3">
                <div>
                  <h5 class="card-title">${course.title}</h5>
                  <p class="card-text text-muted"><strong>${course.student_count || 0}</strong> Students Enrolled</p>
                </div>
                <span class="badge bg-success">Active</span>
              </div>
              <p class="card-text">${(course.description || '').substring(0, 100)}...</p>
              <small class="text-muted d-block mb-3">
                Category: <span class="badge bg-info">${course.category || 'General'}</span>
              </small>
              <div class="btn-group w-100 btn-group-sm" role="group">
                <button class="btn btn-outline-primary edit-course" data-course-id="${course.id}" title="Edit Course">
                  <i class="fas fa-edit"></i> Edit
                </button>
                <button class="btn btn-outline-info manage-course" data-course-id="${course.id}" title="Manage Course">
                  <i class="fas fa-cog"></i> Manage
                </button>
                <button class="btn btn-outline-danger delete-course" data-course-id="${course.id}" data-course-name="${course.title}" title="Delete Course">
                  <i class="fas fa-trash"></i> Delete
                </button>
              </div>
            </div>
          </div>
        `;
        container.appendChild(col);
      });
    } catch (err) {
      console.error('loadInstructorCourses error', err);
      Notification.error('Failed to load courses');
    }
  }

  // Course create/edit/delete handlers
  const courseForm = document.getElementById('courseForm');
  let editingCourseId = null;
  
  if (courseForm) {
    courseForm.addEventListener('submit', async function (e) {
      e.preventDefault();
      const fd = new FormData(courseForm);
      const payload = Object.fromEntries(fd);
      const id = payload.id || null;

      try {
        if (id) {
          await APIService.updateCourse(id, payload);
          Notification.success('Course updated successfully');
        } else {
          await APIService.createCourse(payload);
          Notification.success('Course created successfully');
        }
        courseModal?.hide();
        courseForm.reset();
        editingCourseId = null;
        loadInstructorCourses();
      } catch (error) {
        Notification.error(error.message || 'Failed to save course');
      }
    });
  }
  
  // Course actions
  document.addEventListener('click', async function (e) {
    const btn = e.target.closest('button');
    if (!btn) return;
    
    if (btn.classList.contains('create-course')) {
      editingCourseId = null;
      if (courseForm) {
        courseForm.reset();
        const titleInput = courseForm.querySelector('[name="title"]');
        if (titleInput) titleInput.focus();
      }
      courseModal?.show();
    }
    
    if (btn.classList.contains('edit-course')) {
      const courseId = btn.getAttribute('data-course-id');
      try {
        const course = await APIService.getCourse(courseId);
        editingCourseId = courseId;
        
        if (courseForm) {
          courseForm.querySelector('[name="id"]').value = course.id;
          courseForm.querySelector('[name="title"]').value = course.title;
          courseForm.querySelector('[name="description"]').value = course.description || '';
          courseForm.querySelector('[name="category"]').value = course.category || 'General';
        }
        courseModal?.show();
      } catch (error) {
        Notification.error('Failed to load course');
      }
    }
    
    if (btn.classList.contains('delete-course')) {
      const courseId = btn.getAttribute('data-course-id');
      const courseName = btn.getAttribute('data-course-name');
      
      const confirmed = await ConfirmationModal.show(
        'Delete Course',
        'Are you sure you want to delete this course? This action cannot be undone.',
        courseName
      );
      
      if (confirmed) {
        try {
          await APIService.deleteCourse(courseId);
          Notification.success('Course deleted successfully');
          loadInstructorCourses();
        } catch (error) {
          Notification.error('Failed to delete course');
        }
      }
    }
    
    if (btn.classList.contains('manage-course')) {
      const courseId = btn.getAttribute('data-course-id');
      window.location.href = `instructor-courses.html?courseId=${courseId}&tab=manage`;
    }
  });

  // ===== Assignments =====
  async function loadAssignments() {
    const list = document.querySelector('.assignment-list, [data-assignments-container]');
    const assignmentsTable = document.querySelector('table tbody');
    if (!list && !assignmentsTable) return;

    try {
      const res = await APIService.getAssignments();
      const assignments = res.assignments || [];
      
      if (!assignments.length) {
        if (list) {
          list.innerHTML = `
            <div class="alert alert-info">
              <i class="fas fa-info-circle me-2"></i>
              No assignments created yet.
              <button class="btn btn-sm btn-primary create-assignment ms-2">Create Assignment</button>
            </div>
          `;
        }
        return;
      }

      if (list) {
        list.innerHTML = '';
        assignments.forEach(a => {
          const item = document.createElement('div');
          item.className = 'assignment-item mb-3 p-3 border rounded';
          const dueDate = a.due_date ? Utils.formatDate(a.due_date) : '—';
          
          item.innerHTML = `
            <div class="d-flex justify-content-between align-items-start">
              <div>
                <h5 class="mb-1">${a.title}</h5>
                <small class="text-muted">Due: ${dueDate}</small>
              </div>
              <div class="btn-group btn-group-sm">
                <button class="btn btn-outline-primary view-submissions" data-assignment-id="${a.id}">
                  <i class="fas fa-eye"></i> View
                </button>
                <button class="btn btn-outline-warning edit-assignment" data-assignment-id="${a.id}">
                  <i class="fas fa-edit"></i> Edit
                </button>
                <button class="btn btn-outline-danger delete-assignment" data-assignment-id="${a.id}" data-assignment-name="${a.title}">
                  <i class="fas fa-trash"></i> Delete
                </button>
              </div>
            </div>
          `;
          list.appendChild(item);
        });
      }
      
      if (assignmentsTable) {
        assignmentsTable.innerHTML = '';
        assignments.forEach(a => {
          const row = document.createElement('tr');
          row.innerHTML = `
            <td>${a.title}</td>
            <td>${a.max_score || 100}</td>
            <td>${a.due_date ? Utils.formatDate(a.due_date) : '—'}</td>
            <td>
              <div class="btn-group btn-group-sm">
                <button class="btn btn-outline-info view-submissions" data-assignment-id="${a.id}">
                  <i class="fas fa-eye"></i>
                </button>
                <button class="btn btn-outline-warning edit-assignment" data-assignment-id="${a.id}">
                  <i class="fas fa-edit"></i>
                </button>
                <button class="btn btn-outline-danger delete-assignment" data-assignment-id="${a.id}" data-assignment-name="${a.title}">
                  <i class="fas fa-trash"></i>
                </button>
              </div>
            </td>
          `;
          assignmentsTable.appendChild(row);
        });
      }
    } catch (err) {
      console.error('loadAssignments error', err);
      Notification.error('Failed to load assignments');
    }
  }

  const assignmentForm = document.getElementById('assignmentForm');
  let editingAssignmentId = null;
  
  if (assignmentForm) {
    assignmentForm.addEventListener('submit', async function (e) {
      e.preventDefault();
      const fd = new FormData(assignmentForm);
      const payload = Object.fromEntries(fd);
      const id = payload.id || null;

      try {
        if (id) {
          await APIService.updateAssignment(id, payload);
          Notification.success('Assignment updated successfully');
        } else {
          await APIService.createAssignment(payload);
          Notification.success('Assignment created successfully');
        }
        assignmentModal?.hide();
        assignmentForm.reset();
        editingAssignmentId = null;
        loadAssignments();
      } catch (err) {
        Notification.error(err.message || 'Failed to save assignment');
      }
    });
  }
  
  // Assignment actions
  document.addEventListener('click', async function (e) {
    const btn = e.target.closest('button');
    if (!btn) return;
    
    if (btn.classList.contains('create-assignment')) {
      editingAssignmentId = null;
      if (assignmentForm) {
        assignmentForm.reset();
      }
      assignmentModal?.show();
    }
    
    if (btn.classList.contains('edit-assignment')) {
      const assignmentId = btn.getAttribute('data-assignment-id');
      try {
        const assignment = await APIService.getAssignment(assignmentId);
        editingAssignmentId = assignmentId;
        
        if (assignmentForm) {
          assignmentForm.querySelector('[name="id"]').value = assignment.id;
          assignmentForm.querySelector('[name="title"]').value = assignment.title;
          assignmentForm.querySelector('[name="description"]').value = assignment.description || '';
          assignmentForm.querySelector('[name="due_date"]').value = assignment.due_date || '';
          assignmentForm.querySelector('[name="max_score"]').value = assignment.max_score || 100;
        }
        assignmentModal?.show();
      } catch (error) {
        Notification.error('Failed to load assignment');
      }
    }
    
    if (btn.classList.contains('delete-assignment')) {
      const assignmentId = btn.getAttribute('data-assignment-id');
      const assignmentName = btn.getAttribute('data-assignment-name');
      
      const confirmed = await ConfirmationModal.show(
        'Delete Assignment',
        'Are you sure you want to delete this assignment?',
        assignmentName
      );
      
      if (confirmed) {
        try {
          await APIService.deleteAssignment(assignmentId);
          Notification.success('Assignment deleted successfully');
          loadAssignments();
        } catch (error) {
          Notification.error('Failed to delete assignment');
        }
      }
    }
    
    if (btn.classList.contains('view-submissions')) {
      const assignmentId = btn.getAttribute('data-assignment-id');
      window.location.href = `instructor-grades.html?assignmentId=${assignmentId}`;
    }
  });

  // ===== Students =====
  async function loadStudents() {
    const table = document.querySelector('[data-students-table]');
    if (!table) return;

    try {
      const res = await APIService.getEnrollments();
      const rows = res.enrollments || [];
      const tbody = table.querySelector('tbody');
      tbody.innerHTML = '';

      rows.forEach(r => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td>${r.student_id || ''}</td>
          <td>${r.student_name || r.student_email || ''}</td>
          <td>${r.student_email || ''}</td>
          <td>${r.course_title || ''}</td>
          <td>
            <button class="btn btn-sm btn-primary view-student" data-student-id="${r.student_id}">View</button>
            <button class="btn btn-sm btn-info ms-1 message-student" data-student-id="${r.student_id}">Message</button>
          </td>
        `;
        tbody.appendChild(tr);
      });
    } catch (err) {
      console.error('loadStudents error', err);
    }
  }

  // ===== Messages =====
  async function loadMessages() {
    const list = document.querySelector('.message-list');
    if (!list) return;

    try {
      const res = await APIService.getMessages();
      const messages = res.messages || [];
      list.innerHTML = '';

      messages.forEach(m => {
        const item = document.createElement('div');
        item.className = 'message-item p-3 border rounded mb-2';
        item.innerHTML = `
          <div class="d-flex justify-content-between">
            <div>
              <strong>${m.sender_name || 'Unknown'}</strong>
              <div><small class="text-muted">${m.subject || ''}</small></div>
              <div>${m.content || ''}</div>
            </div>
            <div>
              <button class="btn btn-sm btn-primary reply-message" data-sender-id="${m.sender_id}">Reply</button>
            </div>
          </div>
        `;
        list.appendChild(item);
      });
    } catch (err) {
      console.error('loadMessages error', err);
    }
  }

  const messageForm = document.getElementById('messageForm');
  if (messageForm) {
    messageForm.addEventListener('submit', async function (e) {
      e.preventDefault();
      const fd = new FormData(messageForm);
      const payload = Object.fromEntries(fd);

      try {
        await APIService.sendMessage(payload.receiver_id, payload.subject, payload.content);
        Notification.success('Message sent');
        messageModal?.hide();
        loadMessages();
      } catch (err) {
        Notification.error('Failed to send message');
      }
    });
  }

  // ===== Grades (UI only) =====
  async function loadGrades() {
    const table = document.querySelector('.grade-table');
    if (!table) return;

    // If backend supports fetching grades, use it. For now, keep existing static rows.
  }

  // ===== Profile =====
  const profileForm = document.getElementById('profileForm');
  if (profileForm) {
    profileForm.addEventListener('submit', async function (e) {
      e.preventDefault();
      const fd = new FormData(profileForm);
      const payload = Object.fromEntries(fd);
      try {
        const user = StorageManager.getUser() || {};
        await APIService.updateUser(user.id, payload);
        StorageManager.setUser(Object.assign(user, payload));
        Notification.success('Profile updated');
      } catch (err) {
        Notification.error('Failed to update profile');
      }
    });
  }

  // ===== Delegated click handlers =====
  document.addEventListener('click', async function (e) {
    // Open create course modal
    if (e.target.classList.contains('create-course')) {
      if (courseForm) courseForm.reset();
      courseModal?.show();
    }

    // Edit course
    if (e.target.classList.contains('edit-course')) {
      const id = e.target.getAttribute('data-course-id');
      try {
        const res = await APIService.getCourse(id);
        const c = res.course || res;
        if (courseForm) {
          courseForm.elements['id'].value = c.id || '';
          courseForm.elements['title'].value = c.title || '';
          courseForm.elements['description'].value = c.description || '';
          courseForm.elements['category'].value = c.category || '';
        }
        courseModal?.show();
      } catch (err) {
        Notification.error('Failed to load course');
      }
    }

    // Delete course
    if (e.target.classList.contains('delete-course')) {
      const id = e.target.getAttribute('data-course-id');
      if (!confirm('Delete this course?')) return;
      try {
        await APIService.deleteCourse(id);
        Notification.success('Course deleted');
        loadInstructorCourses();
      } catch (err) {
        Notification.error('Delete failed');
      }
    }

    // Create assignment
    if (e.target.classList.contains('create-assignment')) {
      if (assignmentForm) assignmentForm.reset();
      assignmentModal?.show();
    }

    // Reply / compose message
    if (e.target.classList.contains('compose-message') || e.target.classList.contains('reply-message') || e.target.classList.contains('message-student')) {
      if (messageForm) messageForm.reset();
      const receiver = e.target.getAttribute('data-sender-id') || e.target.getAttribute('data-student-id') || '';
      if (messageForm && receiver) messageForm.elements['receiver_id'].value = receiver;
      messageModal?.show();
    }
  });

  // ============= GRADES MANAGEMENT =============
  
  async function loadGrades() {
    try {
      const response = await APIService.getGrades();
      const gradesTable = document.querySelector('[data-grades-table] tbody, table tbody');
      
      if (gradesTable && response.grades) {
        gradesTable.innerHTML = '';
        
        response.grades.forEach(grade => {
          const row = document.createElement('tr');
          const percentage = Math.round((grade.score / grade.max_score) * 100);
          
          row.innerHTML = `
            <td>${grade.student_name || 'N/A'}</td>
            <td>${grade.title}</td>
            <td><strong>${grade.score}/${grade.max_score}</strong></td>
            <td><small>${grade.feedback || '—'}</small></td>
            <td>
              <button class="btn btn-sm btn-outline-primary edit-grade" data-submission-id="${grade.id}">
                <i class="fas fa-edit"></i> Edit
              </button>
            </td>
          `;
          gradesTable.appendChild(row);
        });
      }
    } catch (error) {
      console.error('Error loading grades:', error);
    }
  }
  
  const gradeForm = document.getElementById('gradeForm');
  const gradeModal = document.getElementById('gradeModal') ? new bootstrap.Modal(document.getElementById('gradeModal')) : null;
  
  if (gradeForm && gradeModal) {
    gradeForm.addEventListener('submit', async function (e) {
      e.preventDefault();
      const fd = new FormData(gradeForm);
      const submissionId = fd.get('submission_id');
      
      try {
        await APIService.gradeSubmission(submissionId, {
          score: fd.get('score'),
          feedback: fd.get('feedback')
        });
        Notification.success('Grade saved successfully');
        gradeModal.hide();
        gradeForm.reset();
        loadGrades();
      } catch (error) {
        Notification.error(error.message || 'Failed to save grade');
      }
    });
  }
  
  // Grade actions
  document.addEventListener('click', function (e) {
    const btn = e.target.closest('button');
    if (!btn) return;
    
    if (btn.classList.contains('create-grade')) {
      if (gradeForm) {
        gradeForm.reset();
      }
      gradeModal?.show();
    }
    
    if (btn.classList.contains('edit-grade')) {
      const submissionId = btn.getAttribute('data-submission-id');
      if (gradeForm) {
        gradeForm.querySelector('[name="submission_id"]').value = submissionId;
      }
      gradeModal?.show();
    }
  });

  // ===== Initialization =====
  loadInstructorCourses();
  loadAssignments();
  loadGrades();
  loadStudents();
  loadMessages();
  
  // Refresh periodically
  setInterval(() => {
    loadAssignments();
    loadMessages();
    loadGrades();
  }, 60000);
});