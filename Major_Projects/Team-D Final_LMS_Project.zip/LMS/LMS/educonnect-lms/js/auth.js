/**
 * Authentication Module
 * Handles login, registration, and password reset with full validation
 */

document.addEventListener('DOMContentLoaded', function () {
  // ============= TOGGLE PASSWORD VISIBILITY =============
  const toggleButtons = document.querySelectorAll('.toggle-password');
  toggleButtons.forEach(button => {
    button.addEventListener('click', function (e) {
      e.preventDefault();
      const input = this.previousElementSibling;
      const icon = this.querySelector('i');

      if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
      } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
      }
    });
  });

  // ============= LOGIN FORM HANDLER =============
  const loginForm = document.getElementById('loginForm');
  if (loginForm) {
    loginForm.addEventListener('submit', async function (e) {
      e.preventDefault();

      const email = document.getElementById('email').value.trim();
      const password = document.getElementById('password').value;
      const role = document.getElementById('role').value;

      // Validation
      if (!email || !password || !role) {
        Notification.error('Please fill in all fields');
        return;
      }

      if (!FormValidator.email(email)) {
        Notification.error('Invalid email address');
        return;
      }

      // Show loading state
      const submitBtn = loginForm.querySelector('button[type="submit"]');
      const originalText = submitBtn.innerHTML;
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Logging in...';

      try {
        // Try API first
        const response = await APIService.login(email, password);

        // Verify role matches
        if (response.user.role !== role) {
          Notification.error('Invalid role selected. Please login as the correct role.');
          submitBtn.disabled = false;
          submitBtn.innerHTML = originalText;
          return;
        }

        // Store user data
        StorageManager.setUser(response.user);

        Notification.success('Login successful! Redirecting...');

        // Redirect based on role
        setTimeout(() => {
          switch (role) {
            case 'student':
              window.location.href = 'student/student-dashboard.html';
              break;
            case 'instructor':
              window.location.href = 'instructor/instructor-dashboard.html';
              break;
            case 'admin':
              window.location.href = 'admin/admin-dashboard.html';
              break;
            default:
              Notification.error('Invalid role');
          }
        }, 1000);
      } catch (error) {
        if (error.statusCode === 401) {
          Notification.error('Invalid email or password');
        } else if (error.statusCode === 0) {
          // Fallback to demo mode if API unavailable
          handleDemoLogin(email, password, role, submitBtn, originalText);
        } else {
          Notification.error(error.message || 'Login failed');
        }
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalText;
      }
    });
  }

  // ============= REGISTRATION FORM HANDLER =============
  const registerForm = document.getElementById('registerForm');
  if (registerForm) {
    registerForm.addEventListener('submit', async function (e) {
      e.preventDefault();

      const fullName = document.getElementById('fullName').value.trim();
      const email = document.getElementById('email').value.trim();
      const password = document.getElementById('password').value;
      const confirmPassword = document.getElementById('confirmPassword').value;
      const role = document.getElementById('role').value;
      const terms = document.getElementById('terms').checked;

      // Validation
      const errors = [];

      if (!fullName) errors.push('Full name is required');
      if (!email) errors.push('Email is required');
      if (!FormValidator.email(email)) errors.push('Invalid email format');
      if (!password) errors.push('Password is required');
      if (!FormValidator.password(password)) errors.push('Password must be at least 8 characters');
      if (password !== confirmPassword) errors.push('Passwords do not match');
      if (!role) errors.push('Please select a role');
      if (!terms) errors.push('You must agree to terms and conditions');

      if (errors.length > 0) {
        errors.forEach(err => Notification.error(err));
        return;
      }

      // Show loading state
      const submitBtn = registerForm.querySelector('button[type="submit"]');
      const originalText = submitBtn.innerHTML;
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Registering...';

      try {
        const response = await APIService.register(fullName, email, password, role);

        Notification.success('Registration successful! Redirecting to login...');

        setTimeout(() => {
          window.location.href = 'login.html';
        }, 2000);
      } catch (error) {
        if (error.statusCode === 409) {
          Notification.error('Email already registered');
        } else if (error.statusCode === 0) {
          // Demo mode
          Notification.success('Registration successful! Redirecting to login...');
          setTimeout(() => {
            window.location.href = 'login.html';
          }, 2000);
        } else {
          Notification.error(error.message || 'Registration failed');
        }
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalText;
      }
    });
  }

  // ============= FORGOT PASSWORD FORM HANDLER =============
  const forgotPasswordForm = document.getElementById('forgotPasswordForm');
  if (forgotPasswordForm) {
    forgotPasswordForm.addEventListener('submit', async function (e) {
      e.preventDefault();

      const email = document.getElementById('forgotEmail').value.trim();

      if (!email || !FormValidator.email(email)) {
        Notification.error('Please enter a valid email address');
        return;
      }

      const submitBtn = forgotPasswordForm.querySelector('button[type="submit"]');
      const originalText = submitBtn.innerHTML;
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Sending...';

      try {
        // In a real app, you would call an API endpoint here
        // For now, just show a demo message
        Notification.success('Password reset link sent to your email!');

        setTimeout(() => {
          window.location.href = 'login.html';
        }, 2000);
      } catch (error) {
        Notification.error('Failed to process request');
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalText;
      }
    });
  }

  // ============= DEMO MODE FALLBACK =============
  function handleDemoLogin(email, password, role, submitBtn, originalText) {
    // Demo credentials
    const demoCredentials = {
      student: { email: 'student@example.com', password: 'password123' },
      instructor: { email: 'instructor@example.com', password: 'password123' },
      admin: { email: 'admin@example.com', password: 'password123' }
    };

    const validCredentials = demoCredentials[role];

    if (validCredentials && email === validCredentials.email && password === validCredentials.password) {
      const user = {
        id: Math.floor(Math.random() * 1000),
        full_name: email.split('@')[0],
        email: email,
        role: role,
        avatar_url: `https://picsum.photos/32/32?random=${Math.floor(Math.random() * 100)}`
      };

      StorageManager.setUser(user);
      Notification.success('Demo login successful! Redirecting...');

      setTimeout(() => {
        switch (role) {
          case 'student':
            window.location.href = 'student/student-dashboard.html';
            break;
          case 'instructor':
            window.location.href = 'instructor/instructor-dashboard.html';
            break;
          case 'admin':
            window.location.href = 'admin/admin-dashboard.html';
            break;
        }
      }, 1000);
    } else {
      Notification.error('Demo mode: Use ' + validCredentials.email + ' / password123');
      submitBtn.disabled = false;
      submitBtn.innerHTML = originalText;
    }
  }

  // ============= REAL-TIME VALIDATION =============
  const emailInputs = document.querySelectorAll('input[type="email"]');
  emailInputs.forEach(input => {
    input.addEventListener('blur', function () {
      if (this.value && !FormValidator.email(this.value)) {
        this.classList.add('is-invalid');
        const feedback = this.nextElementSibling;
        if (feedback && feedback.classList.contains('invalid-feedback')) {
          feedback.textContent = 'Invalid email address';
        }
      } else {
        this.classList.remove('is-invalid');
      }
    });

    input.addEventListener('focus', function () {
      this.classList.remove('is-invalid');
    });
  });

  const passwordInputs = document.querySelectorAll('input[type="password"]');
  passwordInputs.forEach(input => {
    input.addEventListener('blur', function () {
      if (this.value && !FormValidator.password(this.value)) {
        this.classList.add('is-invalid');
      } else {
        this.classList.remove('is-invalid');
      }
    });
  });

  // ============= REMEMBER ME FUNCTIONALITY =============
  const rememberCheckbox = document.getElementById('rememberMe');
  if (rememberCheckbox) {
    // Load saved credentials
    window.addEventListener('load', function () {
      const savedEmail = StorageManager.get('rememberedEmail');
      if (savedEmail) {
        const emailInput = document.getElementById('email');
        if (emailInput) emailInput.value = savedEmail;
        rememberCheckbox.checked = true;
      }
    });

    // Save credentials on login
    rememberCheckbox.addEventListener('change', function () {
      const emailInput = document.getElementById('email');
      if (this.checked && emailInput) {
        StorageManager.set('rememberedEmail', emailInput.value);
      } else {
        StorageManager.remove('rememberedEmail');
      }
    });
  }

  // ============= FORM SUBMISSION ANIMATIONS =============
  const forms = document.querySelectorAll('form');
  forms.forEach(form => {
    form.addEventListener('submit', function () {
      // Add any pre-submission logic here
    });
  });
});