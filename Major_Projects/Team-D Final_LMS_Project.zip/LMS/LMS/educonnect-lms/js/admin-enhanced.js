/**
 * Enhanced Admin Dashboard Scripts
 * Handles user management, course management, with sorting, delete confirmation, and real-time sync
 */

document.addEventListener('DOMContentLoaded', async function () {
  
  // ============= LOAD DASHBOARD DATA =============
  
  async function loadDashboardStats() {
    try {
      const stats = await APIService.getDashboardStats();
      
      // Update stat cards
      if (document.getElementById('totalUsers')) {
        document.getElementById('totalUsers').textContent = stats.total_users || 0;
      }
      if (document.getElementById('totalCourses')) {
        document.getElementById('totalCourses').textContent = stats.total_courses || 0;
      }
      if (document.getElementById('totalEnrollments')) {
        document.getElementById('totalEnrollments').textContent = stats.total_enrollments || 0;
      }
      if (document.getElementById('activeInstructors')) {
        document.getElementById('activeInstructors').textContent = stats.active_instructors || 0;
      }
    } catch (error) {
      console.error('Error loading stats:', error);
    }
  }

  // ============= HELPER FUNCTIONS =============
  
  function getRandomImage(seed = '') {
    const seeds = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15];
    const randomSeed = seeds[Math.floor(Math.random() * seeds.length)];
    return `https://picsum.photos/40/40?random=${randomSeed}`;
  }

  function sortUsers(users) {
    return users.sort((a, b) => a.id - b.id);
  }

  function sortCourses(courses) {
    return courses.sort((a, b) => a.id - b.id);
  }

  // ============= USER MANAGEMENT =============
  
  const userTable = document.querySelector('.user-table, table.table');
  const userModal = userTable ? new bootstrap.Modal(document.getElementById('userModal') || document.createElement('div')) : null;
  const userForm = document.getElementById('userForm');
  
  let editingUserId = null;
  let allUsers = [];
  
  if (userTable) {
    // Load users with sorting
    async function loadUsers() {
      try {
        const response = await APIService.getUsers({ limit: 100 });
        allUsers = sortUsers(response.users || []);
        
        const tbody = userTable.querySelector('tbody');
        
        if (tbody) {
          tbody.innerHTML = '';
          
          allUsers.forEach(user => {
            const row = document.createElement('tr');
            const statusBadge = user.is_active ? '<span class="badge bg-success">Active</span>' : '<span class="badge bg-danger">Inactive</span>';
            
            row.innerHTML = `
              <td>${user.id}</td>
              <td>
                <div class="d-flex align-items-center">
                  <img src="${user.avatar_url || getRandomImage(user.id)}" alt="${user.full_name}" class="rounded-circle me-2" width="32" onerror="this.src='${getRandomImage(user.id)}'">
                  <span>${user.full_name}</span>
                </div>
              </td>
              <td>${user.email}</td>
              <td><span class="badge bg-info">${user.role}</span></td>
              <td>${statusBadge}</td>
              <td>
                <div class="btn-group btn-group-sm">
                  <button class="btn btn-outline-primary edit-user" data-user-id="${user.id}" title="Edit"><i class="fas fa-edit"></i></button>
                  <button class="btn btn-outline-info toggle-status" data-user-id="${user.id}" data-status="${user.is_active ? 'deactivate' : 'activate'}" title="Toggle Status"><i class="fas fa-${user.is_active ? 'ban' : 'check'}"></i></button>
                  <button class="btn btn-outline-danger delete-user" data-user-id="${user.id}" data-user-name="${user.full_name}" title="Delete"><i class="fas fa-trash"></i></button>
                </div>
              </td>
            `;
            tbody.appendChild(row);
          });
        }
      } catch (error) {
        Notification.error('Failed to load users');
        console.error(error);
      }
    }

    // User table actions
    userTable.addEventListener('click', async function (e) {
      const btn = e.target.closest('button');
      if (!btn) return;

      // Edit user
      if (btn.classList.contains('edit-user')) {
        editingUserId = btn.getAttribute('data-user-id');
        const row = btn.closest('tr');
        const fullName = row.querySelector('td:nth-child(2)').textContent.trim();
        const email = row.querySelector('td:nth-child(3)').textContent.trim();
        const role = row.querySelector('td:nth-child(4)').textContent.trim();
        
        document.getElementById('userModalTitle').textContent = 'Edit User';
        document.getElementById('userFullName').value = fullName;
        document.getElementById('userEmail').value = email;
        document.getElementById('userRole').value = role;
        document.getElementById('userPassword').removeAttribute('required');
        document.getElementById('userPassword').placeholder = 'Leave empty to keep current';
        document.getElementById('userPassword').value = '';
        document.getElementById('userId').value = editingUserId;
        
        userModal.show();
      }

      // Toggle user status
      if (btn.classList.contains('toggle-status')) {
        const userId = btn.getAttribute('data-user-id');
        const currentStatus = btn.getAttribute('data-status');
        const newStatus = currentStatus === 'activate' ? 1 : 0;
        
        try {
          await APIService.updateUser(userId, { is_active: newStatus });
          Notification.success(`User ${newStatus ? 'activated' : 'deactivated'} successfully`);
          loadUsers();
        } catch (error) {
          Notification.error('Failed to update user status');
        }
      }

      // Delete user with confirmation modal
      if (btn.classList.contains('delete-user')) {
        const userId = btn.getAttribute('data-user-id');
        const userName = btn.getAttribute('data-user-name');
        
        const confirmed = await ConfirmationModal.show(
          'Delete User',
          'Are you sure you want to delete this user? This action cannot be undone.',
          userName
        );
        
        if (confirmed) {
          try {
            await APIService.deleteUser(userId);
            Notification.success('User deleted successfully');
            loadUsers();
          } catch (error) {
            Notification.error(error.message || 'Failed to delete user');
          }
        }
      }
    });

    // User form submit
    if (userForm) {
      userForm.addEventListener('submit', async function (e) {
        e.preventDefault();
        const formData = new FormData(userForm);
        const data = Object.fromEntries(formData);

        try {
          if (editingUserId) {
            const updateData = {
              full_name: data.full_name,
              email: data.email,
              role: data.role,
              is_active: 1
            };
            if (data.password) {
              updateData.password = data.password;
            }
            await APIService.updateUser(editingUserId, updateData);
            Notification.success('User updated successfully');
          } else {
            await APIService.register(data.full_name, data.email, data.password, data.role);
            Notification.success('User created successfully');
          }
          
          userModal.hide();
          userForm.reset();
          editingUserId = null;
          loadUsers();
        } catch (error) {
          Notification.error(error.message || 'Failed to save user');
        }
      });
    }

    // Add New User button
    document.addEventListener('click', function (e) {
      const btn = e.target.closest('[data-action="add-user"]');
      if (btn && userTable) {
        editingUserId = null;
        document.getElementById('userModalTitle').textContent = 'Add New User';
        document.getElementById('userFullName').value = '';
        document.getElementById('userEmail').value = '';
        document.getElementById('userPassword').value = '';
        document.getElementById('userPassword').setAttribute('required', 'required');
        document.getElementById('userPassword').placeholder = 'Enter password';
        document.getElementById('userRole').value = 'student';
        document.getElementById('userId').value = '';
        userModal.show();
      }
    });

    loadUsers();
  }

  // ============= COURSE MANAGEMENT =============
  
  const courseTable = document.querySelector('.course-table, table.table');
  const courseModal = courseTable ? new bootstrap.Modal(document.getElementById('courseModal') || document.createElement('div')) : null;
  const courseForm = document.getElementById('courseForm');
  
  let editingCourseId = null;
  let allCourses = [];
  
  if (courseTable) {
    // Load courses with sorting
    async function loadCourses() {
      try {
        const response = await APIService.getCourses({ limit: 100 });
        allCourses = sortCourses(response.courses || []);
        
        const tbody = courseTable.querySelector('tbody');
        
        if (tbody) {
          tbody.innerHTML = '';
          
          allCourses.forEach(course => {
            const row = document.createElement('tr');
            const instructorName = course.instructor?.full_name || course.instructor_name || 'N/A';
            
            row.innerHTML = `
              <td>${course.id}</td>
              <td>
                <div class="d-flex align-items-center">
                  <img src="${course.image_url || getRandomImage(course.id)}" class="rounded me-2" width="40" height="40" alt="Course" onerror="this.src='${getRandomImage(course.id)}'">
                  <div>
                    <div class="fw-bold">${course.title}</div>
                    <small class="text-muted">${(course.description || 'No description').substring(0, 40)}...</small>
                  </div>
                </div>
              </td>
              <td>${instructorName}</td>
              <td><span class="badge bg-primary">${course.category || 'General'}</span></td>
              <td>
                <strong>${course.student_count || 0}</strong>
                <span class="text-muted"> students</span>
              </td>
              <td><span class="badge bg-success">Active</span></td>
              <td>
                <div class="btn-group btn-group-sm">
                  <button class="btn btn-outline-primary edit-course" data-course-id="${course.id}" title="Edit"><i class="fas fa-edit"></i></button>
                  <button class="btn btn-outline-info view-course" data-course-id="${course.id}" title="View"><i class="fas fa-eye"></i></button>
                  <button class="btn btn-outline-danger delete-course" data-course-id="${course.id}" data-course-name="${course.title}" title="Delete"><i class="fas fa-trash"></i></button>
                </div>
              </td>
            `;
            tbody.appendChild(row);
          });
        }
      } catch (error) {
        Notification.error('Failed to load courses');
        console.error(error);
      }
    }
    
    // Course table actions
    courseTable.addEventListener('click', async function (e) {
      const btn = e.target.closest('button');
      if (!btn) return;

      const courseId = btn.getAttribute('data-course-id');

      try {
        if (btn.classList.contains('edit-course')) {
          editingCourseId = courseId;
          const course = await APIService.getCourse(courseId);
          
          document.getElementById('courseModalTitle').textContent = 'Edit Course';
          document.getElementById('courseTitle').value = course.title;
          document.getElementById('courseDescription').value = course.description || '';
          document.getElementById('courseCategory').value = course.category || 'General';
          document.getElementById('coursePrice').value = course.price || 0;
          document.getElementById('courseId').value = courseId;
          
          courseModal.show();
        }

        if (btn.classList.contains('delete-course')) {
          const courseName = btn.getAttribute('data-course-name');
          
          const confirmed = await ConfirmationModal.show(
            'Delete Course',
            'Are you sure you want to delete this course? This action cannot be undone.',
            courseName
          );
          
          if (confirmed) {
            await APIService.deleteCourse(courseId);
            Notification.success('Course deleted successfully');
            loadCourses();
          }
        }

        if (btn.classList.contains('view-course')) {
          const course = await APIService.getCourse(courseId);
          Notification.info(`Course: ${course.title}\nStudents Enrolled: ${course.student_count || 0}`, 5000);
        }
      } catch (error) {
        Notification.error(error.message || 'Course action failed');
      }
    });

    // Course form submit
    if (courseForm) {
      courseForm.addEventListener('submit', async function (e) {
        e.preventDefault();
        const formData = new FormData(courseForm);
        const data = Object.fromEntries(formData);

        try {
          if (editingCourseId) {
            await APIService.updateCourse(editingCourseId, {
              title: data.title,
              description: data.description,
              category: data.category,
              price: parseFloat(data.price) || 0
            });
            Notification.success('Course updated successfully');
          } else {
            await APIService.createCourse({
              title: data.title,
              description: data.description,
              category: data.category,
              price: parseFloat(data.price) || 0
            });
            Notification.success('Course created successfully');
          }
          
          courseModal.hide();
          courseForm.reset();
          editingCourseId = null;
          loadCourses();
        } catch (error) {
          Notification.error(error.message || 'Failed to save course');
        }
      });
    }

    // Add New Course button
    document.addEventListener('click', function (e) {
      const btn = e.target.closest('[data-action="create-course"], [data-action="add-course"]');
      if (btn && courseTable) {
        editingCourseId = null;
        document.getElementById('courseModalTitle').textContent = 'Add New Course';
        document.getElementById('courseTitle').value = '';
        document.getElementById('courseDescription').value = '';
        document.getElementById('courseCategory').value = 'General';
        document.getElementById('coursePrice').value = '0';
        document.getElementById('courseId').value = '';
        courseModal.show();
      }
    });

    loadCourses();
  }

  // ============= SETTINGS FORM =============
  
  const settingsForm = document.getElementById('settingsForm');
  if (settingsForm) {
    settingsForm.addEventListener('submit', function (e) {
      e.preventDefault();
      const formData = new FormData(settingsForm);
      const settings = Object.fromEntries(formData);
      StorageManager.set('systemSettings', settings);
      Notification.success('Settings saved successfully!');
    });
  }

  // ============= PROFILE FORM HANDLER =============
  const profileForm = document.getElementById('profileForm');
  if (profileForm) {
    const user = StorageManager.getUser();
    if (user) {
      const nameInput = document.getElementById('profileFullName');
      const emailInput = document.getElementById('profileEmail');
      const avatarInput = document.getElementById('profileAvatar');
      const bioInput = document.getElementById('profileBio');
      if (nameInput) nameInput.value = user.full_name || '';
      if (emailInput) emailInput.value = user.email || '';
      if (avatarInput) avatarInput.value = user.avatar_url || '';
      if (bioInput) bioInput.value = user.bio || '';
    }

    profileForm.addEventListener('submit', async function (e) {
      e.preventDefault();
      const formData = new FormData(profileForm);
      const data = Object.fromEntries(formData);

      const user = StorageManager.getUser();
      if (!user) {
        Notification.error('No user session found');
        return;
      }

      try {
        await APIService.updateUser(user.id, {
          full_name: data.full_name,
          avatar_url: data.avatar_url,
          bio: data.bio,
          is_active: 1
        });
        Notification.success('Profile updated successfully');
        user.full_name = data.full_name || user.full_name;
        user.avatar_url = data.avatar_url || user.avatar_url;
        user.bio = data.bio || user.bio;
        StorageManager.setUser(user);
      } catch (err) {
        Notification.error(err.message || 'Failed to update profile');
      }
    });
  }

  // ============= QUICK ACTIONS HANDLER =============
  document.addEventListener('click', function (e) {
    const btn = e.target.closest('[data-action]');
    if (!btn) return;

    const action = btn.getAttribute('data-action');
    switch (action) {
      case 'add-user':
        if (userTable && userModal) {
          editingUserId = null;
          document.getElementById('userModalTitle').textContent = 'Add New User';
          document.getElementById('userFullName').value = '';
          document.getElementById('userEmail').value = '';
          document.getElementById('userPassword').value = '';
          document.getElementById('userPassword').setAttribute('required', 'required');
          document.getElementById('userPassword').placeholder = 'Enter password';
          document.getElementById('userRole').value = 'student';
          document.getElementById('userId').value = '';
          userModal.show();
        } else {
          window.location.href = 'admin-users.html';
        }
        break;
      case 'approve-courses':
        window.location.href = 'admin-courses.html';
        break;
      case 'generate-report':
        window.location.href = 'admin-reports.html';
        break;
      case 'open-settings':
        window.location.href = 'admin-settings.html';
        break;
      default:
        break;
    }
  });

  // ============= INITIALIZATION =============
  
  loadDashboardStats();

  // Refresh stats every 30 seconds
  setInterval(loadDashboardStats, 30000);
});
