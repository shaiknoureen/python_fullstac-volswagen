# EduConnect LMS - Configuration & Setup

## Environment Setup

### Development Environment

#### Required Software
- Python 3.7+ (for backend)
- Modern web browser (Chrome, Firefox, Safari, Edge)
- Text editor or IDE (VS Code recommended)
- Git (optional, for version control)

#### Installation Steps

1. **Clone or Download Repository**
```bash
# If using git
git clone <repository-url>
cd LMS/educonnect-lms

# Or extract ZIP file
unzip educonnect-lms.zip
cd educonnect-lms
```

2. **Install Backend Dependencies**
```bash
cd backend
pip install -r requirements.txt
```

3. **Initialize Database**
```bash
python app.py
# This will create lms.db on first run
```

4. **Start Backend Server**
```bash
python app.py
# Server runs on http://localhost:5000
```

5. **Start Frontend Server** (in new terminal)
```bash
cd ..  # Go to educonnect-lms directory
python -m http.server 8000
# Frontend accessible at http://localhost:8000
```

## Configuration Files

### Backend Configuration (app.py)

#### Secret Key
```python
app.config['SECRET_KEY'] = 'your-secret-key-change-this'
```
Change this in production!

#### Database Path
```python
DATABASE = os.path.join(os.path.dirname(__file__), 'lms.db')
```
Modify to use different database location.

#### Flask Settings
```python
app.config['JSON_SORT_KEYS'] = False
```

#### CORS Settings
```python
CORS(app)  # Enables cross-origin requests
```

### Frontend Configuration

#### API Base URL (js/api-service.js)
```javascript
const API_BASE_URL = 'http://localhost:5000/api';
```
Change when deploying to production.

#### Demo Credentials (js/auth.js)
```javascript
const demoCredentials = {
  student: { email: 'student@example.com', password: 'password123' },
  instructor: { email: 'instructor@example.com', password: 'password123' },
  admin: { email: 'admin@example.com', password: 'password123' }
};
```

## Database Configuration

### SQLite Database
Default location: `backend/lms.db`

#### Tables
1. **users** - User accounts with roles
2. **courses** - Course information
3. **enrollments** - Student-course relationships
4. **assignments** - Assignment details
5. **submissions** - Assignment submissions
6. **messages** - User messages

#### Database Reset
```bash
# Remove old database
rm backend/lms.db

# Restart app.py to recreate
python app.py
```

## API Configuration

### API Base URL
- Development: `http://localhost:5000/api`
- Production: Update in `js/api-service.js`

### API Response Format
All responses return JSON:
```json
{
  "message": "Success message",
  "data": { /* response data */ }
}
```

Error responses:
```json
{
  "error": "Error message"
}
```

### API Status Codes
- `200` - Success
- `201` - Created
- `400` - Bad Request
- `401` - Unauthorized
- `403` - Forbidden
- `404` - Not Found
- `409` - Conflict
- `500` - Server Error

## Security Configuration

### Secret Key (Production)
Generate a secure secret key:
```python
import secrets
secrets.token_hex(16)
```

Update in `app.py`:
```python
app.config['SECRET_KEY'] = 'generated-secure-key'
```

### Password Hashing
Uses Werkzeug's `generate_password_hash`:
```python
from werkzeug.security import generate_password_hash, check_password_hash
```

### CORS Configuration
For production, specify allowed origins:
```python
CORS(app, origins=["https://yourdomain.com"])
```

### HTTPS
Use HTTPS in production:
- Update API_BASE_URL to use `https://`
- Configure SSL certificates
- Set secure cookie flags

## Frontend Configuration

### LocalStorage Settings
User data stored in browser:
- `user` - Full user object
- `userId` - User ID
- `userRole` - User role
- `userEmail` - User email
- `rememberedEmail` - Remembered email

Clear all:
```javascript
StorageManager.clear();
```

### Notification Settings
Configure in `api-service.js`:
```javascript
Notification.show(message, type, duration);
// type: 'success', 'danger', 'warning', 'info'
// duration: milliseconds (default 3000)
```

### Form Validation Rules
Configured in `FormValidator`:
- Email: Standard email regex
- Password: Minimum 8 characters
- Phone: 10+ digits
- URL: Valid URL format

## Deployment Configuration

### Production Checklist
- [ ] Change SECRET_KEY
- [ ] Set DEBUG = False
- [ ] Update API_BASE_URL
- [ ] Configure CORS origins
- [ ] Set up HTTPS
- [ ] Use production database
- [ ] Set up logging
- [ ] Configure error tracking
- [ ] Set up backups
- [ ] Test all features

### Deployment Platforms

#### Heroku
```bash
# Install Heroku CLI
# Login to Heroku
heroku login

# Create app
heroku create your-app-name

# Deploy
git push heroku main

# View logs
heroku logs --tail
```

#### AWS
1. EC2 instance
2. RDS database (optional)
3. S3 for static files
4. CloudFront for CDN

#### DigitalOcean
1. Droplet with Python
2. Nginx reverse proxy
3. Supervisor process manager
4. Let's Encrypt SSL

#### Docker
Create `Dockerfile`:
```dockerfile
FROM python:3.9
WORKDIR /app
COPY . .
RUN pip install -r backend/requirements.txt
CMD ["python", "backend/app.py"]
```

## Environment Variables

Create `.env` file:
```
FLASK_ENV=development
FLASK_DEBUG=True
SECRET_KEY=your-secret-key
DATABASE_URL=sqlite:///lms.db
API_URL=http://localhost:5000
```

Load in Python:
```python
from dotenv import load_dotenv
import os

load_dotenv()
secret_key = os.getenv('SECRET_KEY')
```

## Logging Configuration

Enable logging in `app.py`:
```python
import logging

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/app.log'),
        logging.StreamHandler()
    ]
)
```

## Performance Configuration

### Cache Configuration
Add caching headers:
```python
@app.after_request
def add_cache_headers(response):
    response.headers['Cache-Control'] = 'public, max-age=300'
    return response
```

### Compression
```bash
pip install flask-compress
```

```python
from flask_compress import Compress
Compress(app)
```

### Database Connection Pooling
```python
# For production databases
```

## Testing Configuration

### Unit Tests
```bash
pip install pytest
pytest tests/
```

### Integration Tests
```bash
pip install pytest-flask
pytest tests/ --cov=backend
```

### API Tests
Use Postman or curl:
```bash
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"password123"}'
```

## Monitoring & Analytics

### Server Monitoring
- CPU usage
- Memory usage
- Disk space
- Request latency
- Error rates

### Application Monitoring
- User logins
- API response times
- Database queries
- Error logs

### Tools
- Sentry (error tracking)
- New Relic (APM)
- DataDog (monitoring)

## Backup & Recovery

### Database Backup
```bash
# Backup SQLite
cp backend/lms.db backup/lms.db.backup

# Automated daily backup
# Add to cron: 0 2 * * * cp /path/to/lms.db /backup/lms_$(date +\%Y\%m\%d).db
```

### Recovery
```bash
# Restore from backup
cp backup/lms.db.backup backend/lms.db
```

## Troubleshooting Configuration

### Port Already in Use
```bash
# Find process using port 5000
lsof -i :5000

# Kill process
kill -9 <PID>

# Or use different port
python app.py --port 5001
```

### CORS Errors
- Check API_BASE_URL in frontend
- Verify CORS is enabled in Flask
- Check browser console for actual error

### Database Locked
- Ensure only one app instance running
- Check for stale connections
- Restart server

### Module Not Found
```bash
# Reinstall requirements
pip install --force-reinstall -r requirements.txt
```

## Performance Tuning

### Frontend Optimization
- Minify CSS and JavaScript
- Lazy load images
- Compress assets
- Use CDN for static files
- Implement service workers

### Backend Optimization
- Use database indexes
- Implement caching
- Connection pooling
- Query optimization
- Load balancing

### Database Optimization
- Index frequently queried columns
- Archive old data
- Regular maintenance
- Query analysis

## Security Hardening

### SQL Injection Prevention
All queries use parameterized statements ✓

### CSRF Protection
```python
from flask_wtf.csrf import CSRFProtect
csrf = CSRFProtect(app)
```

### Input Sanitization
```python
from markupsafe import escape
escaped = escape(user_input)
```

### Rate Limiting
```bash
pip install flask-limiter
```

```python
from flask_limiter import Limiter
limiter = Limiter(app, key_func=lambda: get_remote_address())
```

## Maintenance Tasks

### Weekly
- Check logs for errors
- Monitor server resources
- Verify backups

### Monthly
- Update dependencies
- Security patches
- Performance review
- User feedback analysis

### Quarterly
- Database optimization
- Load testing
- Security audit
- Documentation updates

---

**Configuration Guide Complete!**

For more information, see:
- IMPLEMENTATION_GUIDE.md - Technical details
- QUICKSTART.md - Quick setup
- Flask Documentation: flask.palletsprojects.com
