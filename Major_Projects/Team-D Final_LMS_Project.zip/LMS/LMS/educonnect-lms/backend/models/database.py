"""
EduConnect LMS Database Schema
SQLite database setup for the Learning Management System
"""

import sqlite3
import os
import hashlib
from datetime import datetime

class Database:
    def __init__(self, db_path='educonnect.db'):
        self.db_path = os.path.join(os.path.dirname(__file__), db_path)
        self.init_database()

    def get_connection(self):
        return sqlite3.connect(self.db_path)

    @staticmethod
    def hash_password(password):
        """Hash password using SHA-256"""
        return hashlib.sha256(password.encode()).hexdigest()

    def init_database(self):
        """Initialize the database with all required tables"""
        with self.get_connection() as conn:
            cursor = conn.cursor()

            # Users table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    full_name TEXT NOT NULL,
                    email TEXT UNIQUE NOT NULL,
                    password TEXT NOT NULL,
                    role TEXT NOT NULL CHECK (role IN ('admin', 'instructor', 'student')),
                    avatar_url TEXT,
                    bio TEXT,
                    department TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    is_active BOOLEAN DEFAULT 1
                )
            ''')

            # Courses table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS courses (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    description TEXT,
                    category TEXT NOT NULL,
                    instructor_id INTEGER,
                    image_url TEXT,
                    price REAL DEFAULT 0,
                    original_price REAL DEFAULT 0,
                    duration TEXT,
                    level TEXT CHECK (level IN ('Beginner', 'Intermediate', 'Advanced', 'All Levels')),
                    max_students INTEGER DEFAULT 0,
                    enrolled_count INTEGER DEFAULT 0,
                    rating REAL DEFAULT 0,
                    status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'draft')),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (instructor_id) REFERENCES users (id)
                )
            ''')

            # Course enrollments
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS enrollments (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    student_id INTEGER,
                    course_id INTEGER,
                    enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    progress_percentage REAL DEFAULT 0,
                    status TEXT DEFAULT 'active' CHECK (status IN ('active', 'completed', 'dropped')),
                    completed_at TIMESTAMP,
                    FOREIGN KEY (student_id) REFERENCES users (id),
                    FOREIGN KEY (course_id) REFERENCES courses (id),
                    UNIQUE(student_id, course_id)
                )
            ''')

            # Assignments table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS assignments (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    course_id INTEGER,
                    title TEXT NOT NULL,
                    description TEXT,
                    due_date TIMESTAMP,
                    total_points INTEGER DEFAULT 100,
                    created_by INTEGER,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (course_id) REFERENCES courses (id),
                    FOREIGN KEY (created_by) REFERENCES users (id)
                )
            ''')

            # Assignment submissions
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS submissions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    assignment_id INTEGER,
                    student_id INTEGER,
                    submission_text TEXT,
                    submission_file TEXT,
                    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    grade REAL,
                    feedback TEXT,
                    graded_by INTEGER,
                    graded_at TIMESTAMP,
                    FOREIGN KEY (assignment_id) REFERENCES assignments (id),
                    FOREIGN KEY (student_id) REFERENCES users (id),
                    FOREIGN KEY (graded_by) REFERENCES users (id)
                )
            ''')

            # Messages table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    sender_id INTEGER,
                    receiver_id INTEGER,
                    subject TEXT,
                    content TEXT,
                    is_read BOOLEAN DEFAULT 0,
                    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (sender_id) REFERENCES users (id),
                    FOREIGN KEY (receiver_id) REFERENCES users (id)
                )
            ''')

            # Grades table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS grades (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    student_id INTEGER,
                    course_id INTEGER,
                    assignment_id INTEGER,
                    grade REAL,
                    max_points INTEGER,
                    feedback TEXT,
                    graded_by INTEGER,
                    graded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (student_id) REFERENCES users (id),
                    FOREIGN KEY (course_id) REFERENCES courses (id),
                    FOREIGN KEY (assignment_id) REFERENCES assignments (id),
                    FOREIGN KEY (graded_by) REFERENCES users (id)
                )
            ''')

            # Insert default admin user
            cursor.execute('''
                INSERT OR IGNORE INTO users (full_name, email, password, role, bio)
                VALUES (?, ?, ?, ?, ?)
            ''', ('Admin User', 'admin@educonnect.com', Database.hash_password('admin123'), 'admin', 'System Administrator'))

            # Insert sample instructor
            cursor.execute('''
                INSERT OR IGNORE INTO users (full_name, email, password, role, bio, department)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', ('Dr. Sarah Johnson', 'sarah.johnson@educonnect.com', Database.hash_password('instructor123'), 'instructor',
                  'Computer Science Professor with 10 years of teaching experience', 'Computer Science'))

            # Insert sample student
            cursor.execute('''
                INSERT OR IGNORE INTO users (full_name, email, password, role, bio)
                VALUES (?, ?, ?, ?, ?)
            ''', ('John Smith', 'john.smith@educonnect.com', Database.hash_password('student123'), 'student',
                  'Computer Science student passionate about web development'))

            # Insert sample courses
            sample_courses = [
                ('Full Stack Web Development', 'Master HTML, CSS, JavaScript and popular frameworks to build modern web applications.',
                 'technology', 2, 'https://picsum.photos/400/250?random=2', 99.0, 199.0, '12 weeks', 'Beginner', 50),
                ('Data Science Fundamentals', 'Learn Python, statistics, machine learning and data visualization techniques.',
                 'data', 2, 'https://picsum.photos/400/250?random=3', 129.0, 249.0, '10 weeks', 'Intermediate', 40),
                ('Digital Marketing Mastery', 'Comprehensive guide to SEO, social media marketing, email campaigns and analytics.',
                 'business', 2, 'https://picsum.photos/400/250?random=4', 89.0, 179.0, '8 weeks', 'All Levels', 60),
                ('UI/UX Design Principles', 'Learn the fundamentals of user interface and user experience design.',
                 'design', 2, 'https://picsum.photos/400/250?random=12', 79.0, 149.0, '6 weeks', 'Beginner', 35),
                ('Machine Learning with Python', 'Dive deep into machine learning algorithms and their implementation in Python.',
                 'data', 2, 'https://picsum.photos/400/250?random=13', 149.0, 299.0, '14 weeks', 'Advanced', 30),
                ('Business Analytics', 'Learn to analyze business data and make data-driven decisions.',
                 'business', 2, 'https://picsum.photos/400/250?random=14', 109.0, 219.0, '9 weeks', 'Intermediate', 45)
            ]

            for course in sample_courses:
                cursor.execute('''
                    INSERT OR IGNORE INTO courses (title, description, category, instructor_id, image_url,
                                                price, original_price, duration, level, max_students)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', course)

            conn.commit()

    def reset_database(self):
        """Reset the database by dropping all tables and recreating them"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            tables = ['grades', 'submissions', 'assignments', 'messages', 'enrollments', 'courses', 'users']
            for table in tables:
                cursor.execute(f'DROP TABLE IF EXISTS {table}')
            conn.commit()
        self.init_database()

# Initialize database when module is imported
db = Database()