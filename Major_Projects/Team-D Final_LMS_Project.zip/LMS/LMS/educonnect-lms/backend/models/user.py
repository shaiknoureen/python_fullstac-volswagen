"""
User Model for EduConnect LMS
Handles user authentication, registration, and profile management
"""

import sqlite3
import hashlib
import os
from datetime import datetime
from .database import db

class User:
    def __init__(self, user_id=None, full_name=None, email=None, password=None, role=None,
                 avatar_url=None, bio=None, department=None):
        self.id = user_id
        self.full_name = full_name
        self.email = email
        self.password = password
        self.role = role
        self.avatar_url = avatar_url
        self.bio = bio
        self.department = department

    def to_dict(self):
        """Convert user to dictionary (excluding password)"""
        return {
            'id': self.id,
            'full_name': self.full_name,
            'email': self.email,
            'role': self.role,
            'avatar_url': self.avatar_url,
            'bio': self.bio,
            'department': self.department
        }

    @staticmethod
    def hash_password(password):
        """Hash password using SHA-256"""
        return hashlib.sha256(password.encode()).hexdigest()

    @staticmethod
    def verify_password(password, hashed_password):
        """Verify password against hash"""
        return User.hash_password(password) == hashed_password

    @classmethod
    def authenticate(cls, email, password):
        """Authenticate user with email and password"""
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT id, full_name, email, password, role, avatar_url, bio, department
                FROM users
                WHERE email = ? AND is_active = 1
            ''', (email,))

            user_data = cursor.fetchone()
            if user_data and cls.verify_password(password, user_data[3]):
                return cls(*user_data)
            return None

    @classmethod
    def get_by_id(cls, user_id):
        """Get user by ID"""
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT id, full_name, email, password, role, avatar_url, bio, department
                FROM users
                WHERE id = ? AND is_active = 1
            ''', (user_id,))

            user_data = cursor.fetchone()
            if user_data:
                return cls(*user_data)
            return None

    @classmethod
    def get_by_email(cls, email):
        """Get user by email"""
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT id, full_name, email, password, role, avatar_url, bio, department
                FROM users
                WHERE email = ? AND is_active = 1
            ''', (email,))

            user_data = cursor.fetchone()
            if user_data:
                return cls(*user_data)
            return None

    @classmethod
    def register(cls, full_name, email, password, role='student', bio='', department=''):
        """Register a new user"""
        try:
            hashed_password = cls.hash_password(password)
            with db.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT INTO users (full_name, email, password, role, bio, department)
                    VALUES (?, ?, ?, ?, ?, ?)
                ''', (full_name, email, hashed_password, role, bio, department))

                user_id = cursor.lastrowid
                conn.commit()
                return cls.get_by_id(user_id)
        except sqlite3.IntegrityError:
            return None  # Email already exists

    def update_profile(self, full_name=None, bio=None, department=None, avatar_url=None):
        """Update user profile"""
        with db.get_connection() as conn:
            cursor = conn.cursor()
            updates = []
            params = []

            if full_name:
                updates.append("full_name = ?")
                params.append(full_name)
            if bio is not None:
                updates.append("bio = ?")
                params.append(bio)
            if department is not None:
                updates.append("department = ?")
                params.append(department)
            if avatar_url is not None:
                updates.append("avatar_url = ?")
                params.append(avatar_url)

            if updates:
                params.append(self.id)
                cursor.execute(f'''
                    UPDATE users
                    SET {", ".join(updates)}, updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                ''', params)
                conn.commit()

                # Refresh user data
                updated_user = self.get_by_id(self.id)
                if updated_user:
                    self.__dict__.update(updated_user.__dict__)

    def change_password(self, new_password):
        """Change user password"""
        hashed_password = self.hash_password(new_password)
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE users
                SET password = ?, updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ''', (hashed_password, self.id))
            conn.commit()

    @classmethod
    def get_all_users(cls, role=None, limit=50, offset=0):
        """Get all users, optionally filtered by role"""
        with db.get_connection() as conn:
            cursor = conn.cursor()
            if role:
                cursor.execute('''
                    SELECT id, full_name, email, role, avatar_url, bio, department, created_at
                    FROM users
                    WHERE role = ? AND is_active = 1
                    ORDER BY created_at DESC
                    LIMIT ? OFFSET ?
                ''', (role, limit, offset))
            else:
                cursor.execute('''
                    SELECT id, full_name, email, role, avatar_url, bio, department, created_at
                    FROM users
                    WHERE is_active = 1
                    ORDER BY created_at DESC
                    LIMIT ? OFFSET ?
                ''', (limit, offset))

            rows = cursor.fetchall()

            # Convert to dictionaries
            users = []
            for row in rows:
                user_dict = {
                    'id': row[0],
                    'full_name': row[1],
                    'email': row[2],
                    'role': row[3],
                    'avatar_url': row[4],
                    'bio': row[5],
                    'department': row[6],
                    'created_at': row[7]
                }
                users.append(user_dict)

            return users

    @classmethod
    def get_user_count(cls, role=None):
        """Get total count of users, optionally filtered by role"""
        with db.get_connection() as conn:
            cursor = conn.cursor()
            if role:
                cursor.execute('SELECT COUNT(*) FROM users WHERE role = ? AND is_active = 1', (role,))
            else:
                cursor.execute('SELECT COUNT(*) FROM users WHERE is_active = 1')

            return cursor.fetchone()[0]

    def to_dict(self):
        """Convert user object to dictionary"""
        return {
            'id': self.id,
            'full_name': self.full_name,
            'email': self.email,
            'role': self.role,
            'avatar_url': self.avatar_url,
            'bio': self.bio,
            'department': self.department
        }