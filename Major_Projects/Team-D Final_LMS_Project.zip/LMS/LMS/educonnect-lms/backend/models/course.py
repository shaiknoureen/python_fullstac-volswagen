"""
Course Model for EduConnect LMS
Handles course creation, management, and enrollment
"""

import sqlite3
from .database import db

class Course:
    def __init__(self, course_id=None, title=None, description=None, category=None,
                 instructor_id=None, image_url=None, price=0, original_price=0,
                 duration=None, level=None, max_students=0, enrolled_count=0,
                 rating=0, status='active'):
        self.id = course_id
        self.title = title
        self.description = description
        self.category = category
        self.instructor_id = instructor_id
        self.image_url = image_url
        self.price = price
        self.original_price = original_price
        self.duration = duration
        self.level = level
        self.max_students = max_students
        self.enrolled_count = enrolled_count
    def to_dict(self):
        """Convert course to dictionary"""
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'category': self.category,
            'instructor_id': self.instructor_id,
            'image_url': self.image_url,
            'price': self.price,
            'original_price': self.original_price,
            'duration': self.duration,
            'level': self.level,
            'max_students': self.max_students,
            'enrolled_count': self.enrolled_count,
            'rating': self.rating,
            'status': self.status
        }

    @classmethod
    def get_by_id(cls, course_id):
        """Get course by ID"""
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT id, title, description, category, instructor_id, image_url,
                       price, original_price, duration, level, max_students,
                       enrolled_count, rating, status
                FROM courses
                WHERE id = ? AND status = 'active'
            ''', (course_id,))

            course_data = cursor.fetchone()
            if course_data:
                return cls(*course_data)
            return None

    @classmethod
    def get_all_courses(cls, category=None, instructor_id=None, limit=50, offset=0):
        """Get all courses with optional filtering"""
        with db.get_connection() as conn:
            cursor = conn.cursor()
            query = '''
                SELECT c.id, c.title, c.description, c.category, c.instructor_id, c.image_url,
                       c.price, c.original_price, c.duration, c.level, c.max_students,
                       c.enrolled_count, c.rating, c.status, u.full_name as instructor_name
                FROM courses c
                LEFT JOIN users u ON c.instructor_id = u.id
                WHERE c.status = 'active'
            '''
            params = []

            if category:
                query += " AND c.category = ?"
                params.append(category)

            if instructor_id:
                query += " AND c.instructor_id = ?"
                params.append(instructor_id)

            query += " ORDER BY c.created_at DESC LIMIT ? OFFSET ?"
            params.extend([limit, offset])

            cursor.execute(query, params)
            rows = cursor.fetchall()

            # Convert to dictionaries
            courses = []
            for row in rows:
                course_dict = {
                    'id': row[0],
                    'title': row[1],
                    'description': row[2],
                    'category': row[3],
                    'instructor_id': row[4],
                    'image_url': row[5],
                    'price': row[6],
                    'original_price': row[7],
                    'duration': row[8],
                    'level': row[9],
                    'max_students': row[10],
                    'enrolled_count': row[11],
                    'rating': row[12],
                    'status': row[13],
                    'instructor_name': row[14]
                }
                courses.append(course_dict)

            return courses

    @classmethod
    def get_course_count(cls, category=None, instructor_id=None):
        """Get total count of courses with optional filtering"""
        with db.get_connection() as conn:
            cursor = conn.cursor()
            query = "SELECT COUNT(*) FROM courses WHERE status = 'active'"
            params = []

            if category:
                query += " AND category = ?"
                params.append(category)

            if instructor_id:
                query += " AND instructor_id = ?"
                params.append(instructor_id)

            cursor.execute(query, params)
            return cursor.fetchone()[0]

    @classmethod
    def search_courses(cls, search_term, category=None, limit=50, offset=0):
        """Search courses by title, description, or instructor"""
        with db.get_connection() as conn:
            cursor = conn.cursor()
            query = '''
                SELECT c.id, c.title, c.description, c.category, c.instructor_id, c.image_url,
                       c.price, c.original_price, c.duration, c.level, c.max_students,
                       c.enrolled_count, c.rating, c.status, u.full_name as instructor_name
                FROM courses c
                LEFT JOIN users u ON c.instructor_id = u.id
                WHERE c.status = 'active' AND (
                    c.title LIKE ? OR
                    c.description LIKE ? OR
                    u.full_name LIKE ?
                )
            '''
            search_pattern = f'%{search_term}%'
            params = [search_pattern, search_pattern, search_pattern]

            if category:
                query += " AND c.category = ?"
                params.append(category)

            query += " ORDER BY c.created_at DESC LIMIT ? OFFSET ?"
            params.extend([limit, offset])

            cursor.execute(query, params)
            rows = cursor.fetchall()

            # Convert to dictionaries
            courses = []
            for row in rows:
                course_dict = {
                    'id': row[0],
                    'title': row[1],
                    'description': row[2],
                    'category': row[3],
                    'instructor_id': row[4],
                    'image_url': row[5],
                    'price': row[6],
                    'original_price': row[7],
                    'duration': row[8],
                    'level': row[9],
                    'max_students': row[10],
                    'enrolled_count': row[11],
                    'rating': row[12],
                    'status': row[13],
                    'instructor_name': row[14]
                }
                courses.append(course_dict)

            return courses

    @classmethod
    def create_course(cls, title, description, category, instructor_id, image_url=None,
                     price=0, original_price=0, duration=None, level='Beginner', max_students=0):
        """Create a new course"""
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO courses (title, description, category, instructor_id, image_url,
                                   price, original_price, duration, level, max_students)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (title, description, category, instructor_id, image_url, price,
                  original_price, duration, level, max_students))

            course_id = cursor.lastrowid
            conn.commit()
            return cls.get_by_id(course_id)

    def update_course(self, title=None, description=None, category=None, image_url=None,
                     price=None, original_price=None, duration=None, level=None,
                     max_students=None, status=None):
        """Update course information"""
        with db.get_connection() as conn:
            cursor = conn.cursor()
            updates = []
            params = []

            fields = {
                'title': title,
                'description': description,
                'category': category,
                'image_url': image_url,
                'price': price,
                'original_price': original_price,
                'duration': duration,
                'level': level,
                'max_students': max_students,
                'status': status
            }

            for field, value in fields.items():
                if value is not None:
                    updates.append(f"{field} = ?")
                    params.append(value)

            if updates:
                params.append(self.id)
                cursor.execute(f'''
                    UPDATE courses
                    SET {", ".join(updates)}, updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                ''', params)
                conn.commit()

                # Refresh course data
                updated_course = self.get_by_id(self.id)
                if updated_course:
                    self.__dict__.update(updated_course.__dict__)

    def delete_course(self):
        """Soft delete course by setting status to inactive"""
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE courses
                SET status = 'inactive', updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ''', (self.id,))
            conn.commit()

    @classmethod
    def get_enrolled_courses(cls, student_id):
        """Get courses enrolled by a student"""
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT c.id, c.title, c.description, c.category, c.instructor_id, c.image_url,
                       c.price, c.original_price, c.duration, c.level, c.max_students,
                       c.enrolled_count, c.rating, c.status, u.full_name as instructor_name,
                       e.progress_percentage, e.status as enrollment_status
                FROM courses c
                JOIN enrollments e ON c.id = e.course_id
                LEFT JOIN users u ON c.instructor_id = u.id
                WHERE e.student_id = ? AND e.status = 'active' AND c.status = 'active'
                ORDER BY e.enrolled_at DESC
            ''', (student_id,))
            return cursor.fetchall()

    @classmethod
    def get_instructor_courses(cls, instructor_id):
        """Get courses taught by an instructor"""
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT c.id, c.title, c.description, c.category, c.instructor_id, c.image_url,
                       c.price, c.original_price, c.duration, c.level, c.max_students,
                       c.enrolled_count, c.rating, c.status
                FROM courses c
                WHERE c.instructor_id = ? AND c.status = 'active'
                ORDER BY c.created_at DESC
            ''', (instructor_id,))
            return cursor.fetchall()

    def enroll_student(self, student_id):
        """Enroll a student in this course"""
        try:
            with db.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT INTO enrollments (student_id, course_id)
                    VALUES (?, ?)
                ''', (student_id, self.id))

                # Update enrolled count
                cursor.execute('''
                    UPDATE courses
                    SET enrolled_count = enrolled_count + 1
                    WHERE id = ?
                ''', (self.id,))

                conn.commit()
                return True
        except sqlite3.IntegrityError:
            return False  # Already enrolled

    def unenroll_student(self, student_id):
        """Unenroll a student from this course"""
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE enrollments
                SET status = 'dropped'
                WHERE student_id = ? AND course_id = ?
            ''', (student_id, self.id))

            # Update enrolled count
            cursor.execute('''
                UPDATE courses
                SET enrolled_count = enrolled_count - 1
                WHERE id = ? AND enrolled_count > 0
            ''', (self.id,))

            conn.commit()

    def is_enrolled(self, student_id):
        """Check if a student is enrolled in this course"""
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT COUNT(*) FROM enrollments
                WHERE student_id = ? AND course_id = ? AND status = 'active'
            ''', (student_id, self.id))
            return cursor.fetchone()[0] > 0

    def to_dict(self):
        """Convert course object to dictionary"""
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'category': self.category,
            'instructor_id': self.instructor_id,
            'image_url': self.image_url,
            'price': self.price,
            'original_price': self.original_price,
            'duration': self.duration,
            'level': self.level,
            'max_students': self.max_students,
            'enrolled_count': self.enrolled_count,
            'rating': self.rating,
            'status': self.status
        }