"""
Enrollment Model for EduConnect LMS
Handles course enrollments, progress tracking, and completion
"""

import sqlite3
from datetime import datetime
from .database import db

class Enrollment:
    def __init__(self, enrollment_id=None, student_id=None, course_id=None,
                 enrolled_at=None, progress_percentage=0, status='active', completed_at=None):
        self.id = enrollment_id
        self.student_id = student_id
        self.course_id = course_id
        self.enrolled_at = enrolled_at
        self.progress_percentage = progress_percentage
        self.status = status
        self.completed_at = completed_at

    @classmethod
    def get_by_id(cls, enrollment_id):
        """Get enrollment by ID"""
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT id, student_id, course_id, enrolled_at, progress_percentage, status, completed_at
                FROM enrollments
                WHERE id = ?
            ''', (enrollment_id,))

            enrollment_data = cursor.fetchone()
            if enrollment_data:
                return cls(*enrollment_data)
            return None

    @classmethod
    def get_student_enrollments(cls, student_id, status='active'):
        """Get all enrollments for a student"""
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT e.id, e.student_id, e.course_id, e.enrolled_at, e.progress_percentage,
                       e.status, e.completed_at, c.title, c.image_url, c.instructor_id,
                       u.full_name as instructor_name
                FROM enrollments e
                JOIN courses c ON e.course_id = c.id
                LEFT JOIN users u ON c.instructor_id = u.id
                WHERE e.student_id = ? AND e.status = ?
                ORDER BY e.enrolled_at DESC
            ''', (student_id, status))
            rows = cursor.fetchall()

            # Convert to dictionaries
            enrollments = []
            for row in rows:
                enrollment_dict = {
                    'id': row[0],
                    'student_id': row[1],
                    'course_id': row[2],
                    'enrolled_at': row[3],
                    'progress_percentage': row[4],
                    'status': row[5],
                    'completed_at': row[6],
                    'course_title': row[7],
                    'course_image_url': row[8],
                    'instructor_id': row[9],
                    'instructor_name': row[10]
                }
                enrollments.append(enrollment_dict)

            return enrollments

    @classmethod
    def get_course_enrollments(cls, course_id, status='active'):
        """Get all enrollments for a course"""
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT e.id, e.student_id, e.course_id, e.enrolled_at, e.progress_percentage,
                       e.status, e.completed_at, u.full_name, u.email
                FROM enrollments e
                JOIN users u ON e.student_id = u.id
                WHERE e.course_id = ? AND e.status = ?
                ORDER BY e.enrolled_at DESC
            ''', (course_id, status))
            rows = cursor.fetchall()

            # Convert to dictionaries
            enrollments = []
            for row in rows:
                enrollment_dict = {
                    'id': row[0],
                    'student_id': row[1],
                    'course_id': row[2],
                    'enrolled_at': row[3],
                    'progress_percentage': row[4],
                    'status': row[5],
                    'completed_at': row[6],
                    'student_name': row[7],
                    'student_email': row[8]
                }
                enrollments.append(enrollment_dict)

            return enrollments

    @classmethod
    def enroll_student(cls, student_id, course_id):
        """Enroll a student in a course"""
        try:
            with db.get_connection() as conn:
                cursor = conn.cursor()

                # Check if already enrolled
                cursor.execute('''
                    SELECT id FROM enrollments
                    WHERE student_id = ? AND course_id = ? AND status = 'active'
                ''', (student_id, course_id))

                if cursor.fetchone():
                    return False  # Already enrolled

                # Create enrollment
                cursor.execute('''
                    INSERT INTO enrollments (student_id, course_id)
                    VALUES (?, ?)
                ''', (student_id, course_id))

                # Update course enrolled count
                cursor.execute('''
                    UPDATE courses
                    SET enrolled_count = enrolled_count + 1
                    WHERE id = ?
                ''', (course_id,))

                conn.commit()
                return True
        except sqlite3.Error:
            return False

    @classmethod
    def unenroll_student(cls, student_id, course_id):
        """Unenroll a student from a course"""
        with db.get_connection() as conn:
            cursor = conn.cursor()

            # Update enrollment status
            cursor.execute('''
                UPDATE enrollments
                SET status = 'dropped'
                WHERE student_id = ? AND course_id = ? AND status = 'active'
            ''', (student_id, course_id))

            # Update course enrolled count
            cursor.execute('''
                UPDATE courses
                SET enrolled_count = enrolled_count - 1
                WHERE id = ? AND enrolled_count > 0
            ''', (course_id,))

            conn.commit()

    def update_progress(self, progress_percentage):
        """Update enrollment progress"""
        with db.get_connection() as conn:
            cursor = conn.cursor()

            # Update progress
            self.progress_percentage = min(100, max(0, progress_percentage))
            cursor.execute('''
                UPDATE enrollments
                SET progress_percentage = ?
                WHERE id = ?
            ''', (self.progress_percentage, self.id))

            # Check if completed
            if self.progress_percentage >= 100 and self.status == 'active':
                self.status = 'completed'
                self.completed_at = datetime.now().isoformat()
                cursor.execute('''
                    UPDATE enrollments
                    SET status = 'completed', completed_at = ?
                    WHERE id = ?
                ''', (self.completed_at, self.id))

            conn.commit()

    @classmethod
    def get_enrollment_stats(cls, course_id=None, student_id=None):
        """Get enrollment statistics"""
        with db.get_connection() as conn:
            cursor = conn.cursor()

            if course_id:
                # Stats for a specific course
                cursor.execute('''
                    SELECT
                        COUNT(*) as total_enrollments,
                        COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed,
                        COUNT(CASE WHEN status = 'active' THEN 1 END) as active,
                        AVG(progress_percentage) as avg_progress
                    FROM enrollments
                    WHERE course_id = ?
                ''', (course_id,))
            elif student_id:
                # Stats for a specific student
                cursor.execute('''
                    SELECT
                        COUNT(*) as total_enrollments,
                        COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed,
                        COUNT(CASE WHEN status = 'active' THEN 1 END) as active,
                        AVG(progress_percentage) as avg_progress
                    FROM enrollments
                    WHERE student_id = ?
                ''', (student_id,))
            else:
                # Overall stats
                cursor.execute('''
                    SELECT
                        COUNT(*) as total_enrollments,
                        COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed,
                        COUNT(CASE WHEN status = 'active' THEN 1 END) as active,
                        AVG(progress_percentage) as avg_progress
                    FROM enrollments
                ''')

            return cursor.fetchone()

    @classmethod
    def get_recent_enrollments(cls, limit=10):
        """Get recent enrollments"""
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT e.id, e.enrolled_at, u.full_name as student_name, c.title as course_title
                FROM enrollments e
                JOIN users u ON e.student_id = u.id
                JOIN courses c ON e.course_id = c.id
                ORDER BY e.enrolled_at DESC
                LIMIT ?
            ''', (limit,))
            rows = cursor.fetchall()

            # Convert to dictionaries
            enrollments = []
            for row in rows:
                enrollment_dict = {
                    'id': row[0],
                    'enrolled_at': row[1],
                    'student_name': row[2],
                    'course_title': row[3]
                }
                enrollments.append(enrollment_dict)

            return enrollments

    def to_dict(self):
        """Convert enrollment object to dictionary"""
        return {
            'id': self.id,
            'student_id': self.student_id,
            'course_id': self.course_id,
            'enrolled_at': self.enrolled_at,
            'progress_percentage': self.progress_percentage,
            'status': self.status,
            'completed_at': self.completed_at
        }