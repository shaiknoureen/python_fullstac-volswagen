# EduConnect LMS Backend

A simple Python backend for the EduConnect Learning Management System using SQLite for data persistence.

## Features

- User authentication and management (Admin, Instructor, Student roles)
- Course management with enrollment tracking
- Assignment and submission handling
- Messaging system
- Grade management
- Custom HTTP server for frontend integration

## Setup

1. Ensure you have Python 3.6+ installed
2. Navigate to the backend directory
3. Initialize the database:
   ```bash
   python manage.py init
   ```

## Running the Server

Start the development server:
```bash
python server.py
```

The server will run on http://localhost:8000 and serve both the frontend files and handle backend requests.

## Database Management

- Initialize database: `python manage.py init`
- Show statistics: `python manage.py stats`
- Test authentication: `python manage.py test_auth`

## API Endpoints

The server handles the following request types:
- User registration and login
- Course creation and enrollment
- Assignment submissions
- Message sending
- Grade updates

## Architecture

- `database.py`: SQLite database schema and connection
- `user.py`: User authentication and profile management
- `course.py`: Course CRUD operations
- `enrollment.py`: Enrollment tracking and progress
- `server.py`: Custom HTTP server extending SimpleHTTPRequestHandler
- `manage.py`: Database management utilities

## Security

- Passwords are hashed using SHA-256
- No external APIs - all operations are local
- Minimal attack surface with custom server implementation