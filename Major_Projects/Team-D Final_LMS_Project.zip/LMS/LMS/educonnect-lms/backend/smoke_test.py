#!/usr/bin/env python3
"""
Smoke Test for EduConnect LMS Admin API
Tests: Login, User Create, Course Create, User List
"""

import requests
import json
from datetime import datetime

BASE_URL = 'http://localhost:5000/api'
SESSION = requests.Session()

def log(msg, status='INFO'):
    """Simple logging"""
    timestamp = datetime.now().strftime('%H:%M:%S')
    print(f'[{timestamp}] {status:8} | {msg}')

def test_login():
    """Test admin login"""
    log('Testing admin login...', 'TEST')
    try:
        response = SESSION.post(
            f'{BASE_URL}/auth/login',
            json={
                'email': 'admin@example.com',
                'password': 'password123'
            }
        )
        
        if response.status_code == 200:
            data = response.json()
            log(f'✓ Login successful: {data["user"]["full_name"]} ({data["user"]["role"]})', 'PASS')
            return data['user']
        else:
            log(f'✗ Login failed: {response.status_code} - {response.text}', 'FAIL')
            return None
    except Exception as e:
        log(f'✗ Login error: {str(e)}', 'ERROR')
        return None

def test_get_users():
    """Test fetching users list"""
    log('Testing get users...', 'TEST')
    try:
        response = SESSION.get(f'{BASE_URL}/users')
        
        if response.status_code == 200:
            data = response.json()
            user_count = len(data.get('users', []))
            log(f'✓ Fetched {user_count} users', 'PASS')
            if user_count > 0:
                log(f'  Sample user: {data["users"][0]["full_name"]} ({data["users"][0]["email"]})', 'INFO')
            return data.get('users', [])
        else:
            log(f'✗ Get users failed: {response.status_code}', 'FAIL')
            return []
    except Exception as e:
        log(f'✗ Get users error: {str(e)}', 'ERROR')
        return []

def test_create_user():
    """Test creating a new user"""
    log('Testing user create...', 'TEST')
    try:
        new_user = {
            'full_name': 'Test User Smoke',
            'email': f'test_smoke_{int(datetime.now().timestamp())}@example.com',
            'password': 'password123',
            'role': 'student'
        }
        
        response = SESSION.post(
            f'{BASE_URL}/auth/register',
            json=new_user
        )
        
        if response.status_code in [200, 201]:
            log(f'✓ User created: {new_user["email"]}', 'PASS')
            return new_user['email']
        else:
            log(f'✗ User create failed: {response.status_code} - {response.text}', 'FAIL')
            return None
    except Exception as e:
        log(f'✗ User create error: {str(e)}', 'ERROR')
        return None

def test_get_dashboard_stats():
    """Test fetching dashboard stats"""
    log('Testing dashboard stats...', 'TEST')
    try:
        response = SESSION.get(f'{BASE_URL}/stats/dashboard')
        
        if response.status_code == 200:
            data = response.json()
            log(f'✓ Stats fetched:', 'PASS')
            log(f'  Total Users: {data.get("total_users", 0)}', 'INFO')
            log(f'  Total Courses: {data.get("total_courses", 0)}', 'INFO')
            log(f'  Total Enrollments: {data.get("total_enrollments", 0)}', 'INFO')
            return data
        else:
            log(f'✗ Stats fetch failed: {response.status_code}', 'FAIL')
            return None
    except Exception as e:
        log(f'✗ Stats fetch error: {str(e)}', 'ERROR')
        return None

def test_get_courses():
    """Test fetching courses"""
    log('Testing get courses...', 'TEST')
    try:
        response = SESSION.get(f'{BASE_URL}/courses')
        
        if response.status_code == 200:
            data = response.json()
            course_count = len(data.get('courses', []))
            log(f'✓ Fetched {course_count} courses', 'PASS')
            if course_count > 0:
                log(f'  Sample course: {data["courses"][0]["title"]}', 'INFO')
            return data.get('courses', [])
        else:
            log(f'✗ Get courses failed: {response.status_code}', 'FAIL')
            return []
    except Exception as e:
        log(f'✗ Get courses error: {str(e)}', 'ERROR')
        return []

def run_smoke_tests():
    """Run all smoke tests"""
    log('=' * 60, 'INFO')
    log('EduConnect LMS - Admin API Smoke Test', 'INFO')
    log('=' * 60, 'INFO')
    
    results = {
        'login': False,
        'get_users': False,
        'create_user': False,
        'dashboard_stats': False,
        'get_courses': False
    }
    
    # Test 1: Login
    user = test_login()
    if user:
        results['login'] = True
    
    # Test 2: Get Users
    users = test_get_users()
    if users:
        results['get_users'] = True
    
    # Test 3: Create User
    new_email = test_create_user()
    if new_email:
        results['create_user'] = True
    
    # Test 4: Dashboard Stats
    stats = test_get_dashboard_stats()
    if stats:
        results['dashboard_stats'] = True
    
    # Test 5: Get Courses
    courses = test_get_courses()
    if courses:
        results['get_courses'] = True
    
    # Summary
    log('=' * 60, 'INFO')
    log('Test Summary', 'INFO')
    log('=' * 60, 'INFO')
    
    passed = sum(1 for v in results.values() if v)
    total = len(results)
    
    for test_name, result in results.items():
        status = '✓ PASS' if result else '✗ FAIL'
        log(f'{test_name:20} {status}', 'RESULT')
    
    log('=' * 60, 'INFO')
    log(f'Total: {passed}/{total} tests passed', 'RESULT')
    
    if passed == total:
        log('✓ All smoke tests passed!', 'SUCCESS')
        return True
    else:
        log('✗ Some tests failed. Check server logs.', 'WARNING')
        return False

if __name__ == '__main__':
    success = run_smoke_tests()
    exit(0 if success else 1)
