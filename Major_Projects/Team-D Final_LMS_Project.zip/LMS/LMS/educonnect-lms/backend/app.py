"""
EduConnect LMS - Flask Backend Application
Full-stack REST API with authentication, course management, and user roles
"""

from flask import Flask, request, jsonify, session
from flask_cors import CORS
from functools import wraps
from datetime import datetime, timedelta
import sqlite3
import hashlib
import json
import os
from werkzeug.security import generate_password_hash, check_password_hash

# Initialize Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-change-this'
app.config['JSON_SORT_KEYS'] = False
CORS(app, supports_credentials=True, origins=['http://localhost:8000', 'http://localhost:3000'])

# Database configuration
DATABASE = os.path.join(os.path.dirname(__file__), 'lms.db')

def get_db():
    """Get database connection"""
    db = sqlite3.connect(DATABASE)
    db.row_factory = sqlite3.Row
    return db

def init_db():
    """Initialize database tables"""
    db = get_db()
    cursor = db.cursor()
    
    # Users table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL,
            avatar_url TEXT,
            bio TEXT,
            department TEXT,
            is_active BOOLEAN DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Courses table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS courses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT,
            instructor_id INTEGER NOT NULL,
            category TEXT,
            image_url TEXT,
            price REAL DEFAULT 0,
            rating REAL DEFAULT 0,
            student_count INTEGER DEFAULT 0,
            is_active BOOLEAN DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (instructor_id) REFERENCES users(id)
        )
    ''')
    
    # Enrollments table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS enrollments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            course_id INTEGER NOT NULL,
            progress INTEGER DEFAULT 0,
            grade TEXT,
            status TEXT DEFAULT 'active',
            enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            completed_at TIMESTAMP,
            FOREIGN KEY (student_id) REFERENCES users(id),
            FOREIGN KEY (course_id) REFERENCES courses(id),
            UNIQUE(student_id, course_id)
        )
    ''')
    
    # Assignments table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS assignments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            course_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            description TEXT,
            due_date TIMESTAMP,
            max_score INTEGER DEFAULT 100,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (course_id) REFERENCES courses(id)
        )
    ''')
    
    # Submissions table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS submissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            assignment_id INTEGER NOT NULL,
            student_id INTEGER NOT NULL,
            content TEXT,
            file_url TEXT,
            score INTEGER,
            feedback TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (assignment_id) REFERENCES assignments(id),
            FOREIGN KEY (student_id) REFERENCES users(id)
        )
    ''')
    
    # Messages table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sender_id INTEGER NOT NULL,
            receiver_id INTEGER NOT NULL,
            subject TEXT,
            content TEXT,
            is_read BOOLEAN DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (sender_id) REFERENCES users(id),
            FOREIGN KEY (receiver_id) REFERENCES users(id)
        )
    ''')
    
    db.commit()
    
    # Seed demo data
    cursor = db.cursor()
    try:
        # Check if demo users already exist
        existing = cursor.execute("SELECT COUNT(*) as count FROM users").fetchone()
        if existing['count'] == 0:
            # Create demo users
            demo_users = [
                ('John Student', 'student@example.com', 'password123', 'student'),
                ('Jane Instructor', 'instructor@example.com', 'password123', 'instructor'),
                ('Admin User', 'admin@example.com', 'password123', 'admin'),
            ]
            
            for full_name, email, password, role in demo_users:
                hashed_password = generate_password_hash(password)
                cursor.execute('''
                    INSERT INTO users (full_name, email, password, role, avatar_url)
                    VALUES (?, ?, ?, ?, ?)
                ''', (full_name, email, hashed_password, role, f'https://picsum.photos/100/100?random={full_name}'))
            
            db.commit()
    except Exception as e:
        print(f"Demo data seeding error: {e}")
    
    db.close()

# Authentication decorator
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': 'Unauthorized'}), 401
        return f(*args, **kwargs)
    return decorated_function

def role_required(roles):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if 'user_id' not in session:
                return jsonify({'error': 'Unauthorized'}), 401
            
            db = get_db()
            user = db.execute('SELECT role FROM users WHERE id = ?', (session['user_id'],)).fetchone()
            db.close()
            
            if user['role'] not in roles:
                return jsonify({'error': 'Forbidden'}), 403
            return f(*args, **kwargs)
        return decorated_function
    return decorator

# ============= AUTHENTICATION ENDPOINTS =============

@app.route('/api/auth/register', methods=['POST'])
def register():
    """Register a new user"""
    try:
        data = request.json
        
        # Validation
        if not all([data.get('full_name'), data.get('email'), data.get('password'), data.get('role')]):
            return jsonify({'error': 'Missing required fields'}), 400
        
        if len(data['password']) < 8:
            return jsonify({'error': 'Password must be at least 8 characters'}), 400
        
        db = get_db()
        
        # Check if user exists
        existing = db.execute('SELECT id FROM users WHERE email = ?', (data['email'],)).fetchone()
        if existing:
            return jsonify({'error': 'Email already registered'}), 409
        
        # Hash password
        hashed_password = generate_password_hash(data['password'])
        
        # Insert user
        cursor = db.cursor()
        cursor.execute('''
            INSERT INTO users (full_name, email, password, role, bio, department)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (data['full_name'], data['email'], hashed_password, data['role'], 
              data.get('bio', ''), data.get('department', '')))
        
        user_id = cursor.lastrowid
        db.commit()
        db.close()
        
        return jsonify({
            'message': 'Registration successful',
            'user_id': user_id
        }), 201
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/auth/login', methods=['POST'])
def login():
    """Login user"""
    try:
        data = request.json
        
        if not data.get('email') or not data.get('password'):
            return jsonify({'error': 'Missing email or password'}), 400
        
        db = get_db()
        user = db.execute('SELECT * FROM users WHERE email = ? AND is_active = 1', 
                         (data['email'],)).fetchone()
        db.close()
        
        if not user or not check_password_hash(user['password'], data['password']):
            return jsonify({'error': 'Invalid credentials'}), 401
        
        # Set session
        session['user_id'] = user['id']
        session['role'] = user['role']
        session['email'] = user['email']
        
        return jsonify({
            'message': 'Login successful',
            'user': {
                'id': user['id'],
                'full_name': user['full_name'],
                'email': user['email'],
                'role': user['role'],
                'avatar_url': user['avatar_url']
            }
        }), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/auth/logout', methods=['POST'])
@login_required
def logout():
    """Logout user"""
    session.clear()
    return jsonify({'message': 'Logged out successfully'}), 200

@app.route('/api/auth/user', methods=['GET'])
@login_required
def get_current_user():
    """Get current logged-in user"""
    db = get_db()
    user = db.execute('SELECT id, full_name, email, role, avatar_url, bio, department FROM users WHERE id = ?',
                     (session['user_id'],)).fetchone()
    db.close()
    
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    return jsonify(dict(user)), 200

# ============= COURSE ENDPOINTS =============

@app.route('/api/courses', methods=['GET'])
def get_courses():
    """Get all courses with filtering"""
    try:
        category = request.args.get('category')
        search = request.args.get('search')
        limit = int(request.args.get('limit', 50))
        offset = int(request.args.get('offset', 0))
        
        db = get_db()
        query = 'SELECT * FROM courses WHERE is_active = 1'
        params = []
        
        if category:
            query += ' AND category = ?'
            params.append(category)
        
        if search:
            query += ' AND (title LIKE ? OR description LIKE ?)'
            params.extend([f'%{search}%', f'%{search}%'])
        
        query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?'
        params.extend([limit, offset])
        
        courses = db.execute(query, params).fetchall()
        db.close()
        
        return jsonify({
            'courses': [dict(course) for course in courses],
            'limit': limit,
            'offset': offset
        }), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/courses/<int:course_id>', methods=['GET'])
def get_course(course_id):
    """Get specific course"""
    try:
        db = get_db()
        course = db.execute('SELECT * FROM courses WHERE id = ?', (course_id,)).fetchone()
        
        if not course:
            return jsonify({'error': 'Course not found'}), 404
        
        # Get instructor info
        instructor = db.execute('SELECT id, full_name, avatar_url FROM users WHERE id = ?',
                               (course['instructor_id'],)).fetchone()
        
        # Get enrollment count
        students = db.execute('SELECT COUNT(*) as count FROM enrollments WHERE course_id = ?',
                            (course_id,)).fetchone()
        
        db.close()
        
        course_data = dict(course)
        course_data['instructor'] = dict(instructor) if instructor else None
        course_data['student_count'] = students['count']
        
        return jsonify(course_data), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/courses', methods=['POST'])
@login_required
@role_required(['instructor', 'admin'])
def create_course():
    """Create a new course"""
    try:
        data = request.json
        
        if not all([data.get('title'), data.get('description')]):
            return jsonify({'error': 'Missing required fields'}), 400
        
        db = get_db()
        cursor = db.cursor()
        cursor.execute('''
            INSERT INTO courses (title, description, instructor_id, category, price)
            VALUES (?, ?, ?, ?, ?)
        ''', (data['title'], data['description'], session['user_id'],
              data.get('category', 'General'), data.get('price', 0)))
        
        db.commit()
        course_id = cursor.lastrowid
        db.close()
        
        return jsonify({
            'message': 'Course created successfully',
            'course_id': course_id
        }), 201
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/courses/<int:course_id>', methods=['PUT'])
@login_required
@role_required(['instructor', 'admin'])
def update_course(course_id):
    """Update a course"""
    try:
        db = get_db()
        course = db.execute('SELECT instructor_id FROM courses WHERE id = ?', (course_id,)).fetchone()
        
        if not course:
            return jsonify({'error': 'Course not found'}), 404
        
        if course['instructor_id'] != session['user_id'] and session.get('role') != 'admin':
            return jsonify({'error': 'Unauthorized'}), 403
        
        data = request.json
        
        db.execute('''
            UPDATE courses
            SET title = ?, description = ?, category = ?, price = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ''', (data.get('title'), data.get('description'), data.get('category'),
              data.get('price'), course_id))
        
        db.commit()
        db.close()
        
        return jsonify({'message': 'Course updated successfully'}), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/courses/<int:course_id>', methods=['DELETE'])
@login_required
@role_required(['instructor', 'admin'])
def delete_course(course_id):
    """Delete a course"""
    try:
        db = get_db()
        course = db.execute('SELECT instructor_id FROM courses WHERE id = ?', (course_id,)).fetchone()
        
        if not course:
            return jsonify({'error': 'Course not found'}), 404
        
        if course['instructor_id'] != session['user_id'] and session.get('role') != 'admin':
            return jsonify({'error': 'Unauthorized'}), 403
        
        db.execute('UPDATE courses SET is_active = 0 WHERE id = ?', (course_id,))
        db.commit()
        db.close()
        
        return jsonify({'message': 'Course deleted successfully'}), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============= ENROLLMENT ENDPOINTS =============

@app.route('/api/enrollments', methods=['GET'])
@login_required
def get_enrollments():
    """Get user's enrollments"""
    try:
        db = get_db()
        enrollments = db.execute('''
            SELECT e.*, c.title, c.description, c.instructor_id, u.full_name as instructor_name
            FROM enrollments e
            JOIN courses c ON e.course_id = c.id
            JOIN users u ON c.instructor_id = u.id
            WHERE e.student_id = ?
            ORDER BY e.enrolled_at DESC
        ''', (session['user_id'],)).fetchall()
        
        db.close()
        
        return jsonify({
            'enrollments': [dict(e) for e in enrollments]
        }), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/enrollments', methods=['POST'])
@login_required
@role_required(['student'])
def enroll_course():
    """Enroll in a course"""
    try:
        data = request.json
        course_id = data.get('course_id')
        
        if not course_id:
            return jsonify({'error': 'Missing course_id'}), 400
        
        db = get_db()
        
        # Check if course exists
        course = db.execute('SELECT id FROM courses WHERE id = ?', (course_id,)).fetchone()
        if not course:
            return jsonify({'error': 'Course not found'}), 404
        
        # Check if already enrolled
        existing = db.execute('''
            SELECT id FROM enrollments
            WHERE student_id = ? AND course_id = ?
        ''', (session['user_id'], course_id)).fetchone()
        
        if existing:
            return jsonify({'error': 'Already enrolled in this course'}), 409
        
        # Create enrollment
        cursor = db.cursor()
        cursor.execute('''
            INSERT INTO enrollments (student_id, course_id)
            VALUES (?, ?)
        ''', (session['user_id'], course_id))
        
        db.commit()
        enrollment_id = cursor.lastrowid
        db.close()
        
        return jsonify({
            'message': 'Enrolled successfully',
            'enrollment_id': enrollment_id
        }), 201
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============= ASSIGNMENT ENDPOINTS =============

@app.route('/api/assignments', methods=['GET'])
@login_required
def get_assignments():
    """Get assignments for user"""
    try:
        course_id = request.args.get('course_id')
        db = get_db()
        
        if course_id:
            assignments = db.execute('''
                SELECT * FROM assignments
                WHERE course_id = ?
                ORDER BY due_date
            ''', (course_id,)).fetchall()
        else:
            assignments = db.execute('''
                SELECT a.* FROM assignments a
                JOIN enrollments e ON a.course_id = e.course_id
                WHERE e.student_id = ?
                ORDER BY a.due_date
            ''', (session['user_id'],)).fetchall()
        
        db.close()
        
        return jsonify({
            'assignments': [dict(a) for a in assignments]
        }), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/assignments', methods=['POST'])
@login_required
@role_required(['instructor', 'admin'])
def create_assignment():
    """Create a new assignment"""
    try:
        data = request.json
        
        if not all([data.get('course_id'), data.get('title')]):
            return jsonify({'error': 'Missing required fields'}), 400
        
        db = get_db()
        
        # Verify instructor owns the course
        course = db.execute('SELECT instructor_id FROM courses WHERE id = ?',
                          (data['course_id'],)).fetchone()
        
        if not course or (course['instructor_id'] != session['user_id'] and session.get('role') != 'admin'):
            return jsonify({'error': 'Unauthorized'}), 403
        
        cursor = db.cursor()
        cursor.execute('''
            INSERT INTO assignments (course_id, title, description, due_date, max_score)
            VALUES (?, ?, ?, ?, ?)
        ''', (data['course_id'], data['title'], data.get('description'),
              data.get('due_date'), data.get('max_score', 100)))
        
        db.commit()
        assignment_id = cursor.lastrowid
        db.close()
        
        return jsonify({
            'message': 'Assignment created successfully',
            'assignment_id': assignment_id
        }), 201
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============= MESSAGING ENDPOINTS =============

@app.route('/api/messages', methods=['GET'])
@login_required
def get_messages():
    """Get user's messages"""
    try:
        db = get_db()
        messages = db.execute('''
            SELECT m.*, sender.full_name as sender_name, sender.avatar_url as sender_avatar
            FROM messages m
            JOIN users sender ON m.sender_id = sender.id
            WHERE m.receiver_id = ?
            ORDER BY m.created_at DESC
        ''', (session['user_id'],)).fetchall()
        
        db.close()
        
        return jsonify({
            'messages': [dict(m) for m in messages]
        }), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/messages', methods=['POST'])
@login_required
def send_message():
    """Send a message"""
    try:
        data = request.json
        
        if not all([data.get('receiver_id'), data.get('subject'), data.get('content')]):
            return jsonify({'error': 'Missing required fields'}), 400
        
        db = get_db()
        
        # Verify receiver exists
        receiver = db.execute('SELECT id FROM users WHERE id = ?', (data['receiver_id'],)).fetchone()
        if not receiver:
            return jsonify({'error': 'Receiver not found'}), 404
        
        cursor = db.cursor()
        cursor.execute('''
            INSERT INTO messages (sender_id, receiver_id, subject, content)
            VALUES (?, ?, ?, ?)
        ''', (session['user_id'], data['receiver_id'], data['subject'], data['content']))
        
        db.commit()
        message_id = cursor.lastrowid
        db.close()
        
        return jsonify({
            'message': 'Message sent successfully',
            'message_id': message_id
        }), 201
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============= ASSIGNMENT DETAILS & UPDATES =============

@app.route('/api/assignments/<int:assignment_id>', methods=['GET'])
@login_required
def get_assignment(assignment_id):
    """Get assignment details"""
    try:
        db = get_db()
        assignment = db.execute('SELECT * FROM assignments WHERE id = ?', (assignment_id,)).fetchone()
        
        if not assignment:
            return jsonify({'error': 'Assignment not found'}), 404
        
        db.close()
        return jsonify(dict(assignment)), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/assignments/<int:assignment_id>', methods=['PUT'])
@login_required
@role_required(['instructor', 'admin'])
def update_assignment(assignment_id):
    """Update assignment"""
    try:
        data = request.json
        db = get_db()
        
        assignment = db.execute('SELECT a.*, c.instructor_id FROM assignments a JOIN courses c ON a.course_id = c.id WHERE a.id = ?', 
                              (assignment_id,)).fetchone()
        
        if not assignment:
            return jsonify({'error': 'Assignment not found'}), 404
        
        if assignment['instructor_id'] != session['user_id'] and session.get('role') != 'admin':
            return jsonify({'error': 'Unauthorized'}), 403
        
        db.execute('''
            UPDATE assignments
            SET title = ?, description = ?, due_date = ?, max_score = ?
            WHERE id = ?
        ''', (data.get('title'), data.get('description'), data.get('due_date'), 
              data.get('max_score'), assignment_id))
        
        db.commit()
        db.close()
        return jsonify({'message': 'Assignment updated successfully'}), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/assignments/<int:assignment_id>', methods=['DELETE'])
@login_required
@role_required(['instructor', 'admin'])
def delete_assignment(assignment_id):
    """Delete assignment"""
    try:
        db = get_db()
        assignment = db.execute('SELECT a.*, c.instructor_id FROM assignments a JOIN courses c ON a.course_id = c.id WHERE a.id = ?',
                              (assignment_id,)).fetchone()
        
        if not assignment:
            return jsonify({'error': 'Assignment not found'}), 404
        
        if assignment['instructor_id'] != session['user_id'] and session.get('role') != 'admin':
            return jsonify({'error': 'Unauthorized'}), 403
        
        db.execute('DELETE FROM assignments WHERE id = ?', (assignment_id,))
        db.commit()
        db.close()
        return jsonify({'message': 'Assignment deleted successfully'}), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============= SUBMISSIONS ENDPOINTS =============

@app.route('/api/submissions', methods=['GET'])
@login_required
def get_submissions():
    """Get user's submissions"""
    try:
        db = get_db()
        submissions = db.execute('''
            SELECT s.*, a.title, a.max_score, c.title as course_title
            FROM submissions s
            JOIN assignments a ON s.assignment_id = a.id
            JOIN courses c ON a.course_id = c.id
            WHERE s.student_id = ?
            ORDER BY s.created_at DESC
        ''', (session['user_id'],)).fetchall()
        
        db.close()
        return jsonify({'submissions': [dict(s) for s in submissions]}), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/submissions', methods=['POST'])
@login_required
@role_required(['student'])
def create_submission():
    """Submit an assignment"""
    try:
        data = request.json
        
        if not all([data.get('assignment_id'), data.get('content')]):
            return jsonify({'error': 'Missing required fields'}), 400
        
        db = get_db()
        
        # Check if assignment exists
        assignment = db.execute('SELECT id FROM assignments WHERE id = ?', 
                              (data['assignment_id'],)).fetchone()
        if not assignment:
            return jsonify({'error': 'Assignment not found'}), 404
        
        # Check for existing submission
        existing = db.execute('SELECT id FROM submissions WHERE student_id = ? AND assignment_id = ?',
                            (session['user_id'], data['assignment_id'])).fetchone()
        
        if existing:
            # Update existing submission
            db.execute('UPDATE submissions SET content = ?, submitted_at = CURRENT_TIMESTAMP WHERE id = ?',
                      (data['content'], existing['id']))
            submission_id = existing['id']
        else:
            # Create new submission
            cursor = db.cursor()
            cursor.execute('''
                INSERT INTO submissions (student_id, assignment_id, content)
                VALUES (?, ?, ?)
            ''', (session['user_id'], data['assignment_id'], data['content']))
            submission_id = cursor.lastrowid
        
        db.commit()
        db.close()
        
        return jsonify({
            'message': 'Submission successful',
            'submission_id': submission_id
        }), 201
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============= GRADES ENDPOINTS =============

@app.route('/api/grades', methods=['GET'])
@login_required
def get_grades():
    """Get user's grades"""
    try:
        db = get_db()
        
        if session.get('role') == 'student':
            # Students see their own grades
            grades = db.execute('''
                SELECT s.id, a.title, a.max_score, s.score, a.course_id, c.title as course_title, s.feedback
                FROM submissions s
                JOIN assignments a ON s.assignment_id = a.id
                JOIN courses c ON a.course_id = c.id
                WHERE s.student_id = ? AND s.score IS NOT NULL
                ORDER BY s.submitted_at DESC
            ''', (session['user_id'],)).fetchall()
        else:
            # Instructors see their students' grades
            grades = db.execute('''
                SELECT s.id, a.title, a.max_score, s.score, a.course_id, c.title as course_title, 
                       u.full_name as student_name, s.feedback
                FROM submissions s
                JOIN assignments a ON s.assignment_id = a.id
                JOIN courses c ON a.course_id = c.id
                JOIN users u ON s.student_id = u.id
                WHERE c.instructor_id = ? AND s.score IS NOT NULL
                ORDER BY s.submitted_at DESC
            ''', (session['user_id'],)).fetchall()
        
        db.close()
        return jsonify({'grades': [dict(g) for g in grades]}), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/grades/<int:submission_id>', methods=['PUT'])
@login_required
@role_required(['instructor', 'admin'])
def grade_submission(submission_id):
    """Grade a submission"""
    try:
        data = request.json
        db = get_db()
        
        submission = db.execute('''
            SELECT s.*, a.course_id, c.instructor_id
            FROM submissions s
            JOIN assignments a ON s.assignment_id = a.id
            JOIN courses c ON a.course_id = c.id
            WHERE s.id = ?
        ''', (submission_id,)).fetchone()
        
        if not submission:
            return jsonify({'error': 'Submission not found'}), 404
        
        if submission['instructor_id'] != session['user_id'] and session.get('role') != 'admin':
            return jsonify({'error': 'Unauthorized'}), 403
        
        db.execute('''
            UPDATE submissions
            SET score = ?, feedback = ?
            WHERE id = ?
        ''', (data.get('score'), data.get('feedback'), submission_id))
        
        db.commit()
        db.close()
        return jsonify({'message': 'Submission graded successfully'}), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============= USER MANAGEMENT (ADMIN) =============

@app.route('/api/users', methods=['GET'])
@login_required
@role_required(['admin'])
def get_users():
    """Get all users"""
    try:
        role = request.args.get('role')
        search = request.args.get('search')
        limit = int(request.args.get('limit', 50))
        offset = int(request.args.get('offset', 0))
        
        db = get_db()
        query = 'SELECT id, full_name, email, role, avatar_url, is_active FROM users WHERE 1=1'
        params = []
        
        if role:
            query += ' AND role = ?'
            params.append(role)
        
        if search:
            query += ' AND (full_name LIKE ? OR email LIKE ?)'
            params.extend([f'%{search}%', f'%{search}%'])
        
        query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?'
        params.extend([limit, offset])
        
        users = db.execute(query, params).fetchall()
        db.close()
        
        return jsonify({
            'users': [dict(u) for u in users],
            'limit': limit,
            'offset': offset
        }), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/users/<int:user_id>', methods=['PUT'])
@login_required
@role_required(['admin'])
def update_user(user_id):
    """Update user (admin only)"""
    try:
        db = get_db()
        user = db.execute('SELECT id FROM users WHERE id = ?', (user_id,)).fetchone()
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        data = request.json
        
        db.execute('''
            UPDATE users
            SET full_name = ?, role = ?, is_active = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ''', (data.get('full_name'), data.get('role'), data.get('is_active', 1), user_id))
        
        db.commit()
        db.close()
        
        return jsonify({'message': 'User updated successfully'}), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/users/<int:user_id>', methods=['DELETE'])
@login_required
@role_required(['admin'])
def delete_user(user_id):
    """Delete user (deactivate)"""
    try:
        db = get_db()
        
        db.execute('UPDATE users SET is_active = 0 WHERE id = ?', (user_id,))
        db.commit()
        db.close()
        
        return jsonify({'message': 'User deactivated successfully'}), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============= STATISTICS ENDPOINTS =============

@app.route('/api/stats/dashboard', methods=['GET'])
@login_required
@role_required(['admin'])
def get_dashboard_stats():
    """Get dashboard statistics for admin"""
    try:
        db = get_db()
        
        total_users = db.execute('SELECT COUNT(*) as count FROM users WHERE is_active = 1').fetchone()['count']
        total_courses = db.execute('SELECT COUNT(*) as count FROM courses WHERE is_active = 1').fetchone()['count']
        total_enrollments = db.execute('SELECT COUNT(*) as count FROM enrollments').fetchone()['count']
        active_instructors = db.execute('SELECT COUNT(DISTINCT id) as count FROM users WHERE role = "instructor" AND is_active = 1').fetchone()['count']
        
        db.close()
        
        return jsonify({
            'total_users': total_users,
            'total_courses': total_courses,
            'total_enrollments': total_enrollments,
            'active_instructors': active_instructors
        }), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/stats/user', methods=['GET'])
@login_required
def get_user_stats():
    """Get user's personal statistics"""
    try:
        db = get_db()
        user = db.execute('SELECT role FROM users WHERE id = ?', (session['user_id'],)).fetchone()
        
        if user['role'] == 'student':
            enrolled_courses = db.execute('''
                SELECT COUNT(*) as count FROM enrollments WHERE student_id = ?
            ''', (session['user_id'],)).fetchone()['count']
            
            completed_assignments = db.execute('''
                SELECT COUNT(*) as count FROM submissions
                WHERE student_id = ? AND score IS NOT NULL
            ''', (session['user_id'],)).fetchone()['count']
            
            stats = {
                'enrolled_courses': enrolled_courses,
                'completed_assignments': completed_assignments
            }
        
        elif user['role'] == 'instructor':
            total_courses = db.execute('''
                SELECT COUNT(*) as count FROM courses WHERE instructor_id = ?
            ''', (session['user_id'],)).fetchone()['count']
            
            total_students = db.execute('''
                SELECT COUNT(DISTINCT student_id) as count FROM enrollments e
                JOIN courses c ON e.course_id = c.id
                WHERE c.instructor_id = ?
            ''', (session['user_id'],)).fetchone()['count']
            
            stats = {
                'total_courses': total_courses,
                'total_students': total_students
            }
        
        db.close()
        
        return jsonify(stats), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============= ERROR HANDLERS =============

@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Resource not found'}), 404

@app.errorhandler(500)
def server_error(error):
    return jsonify({'error': 'Internal server error'}), 500

# ============= MAIN =============

if __name__ == '__main__':
    # Initialize database
    init_db()
    
    # Run Flask app
    app.run(debug=True, host='0.0.0.0', port=5000)
