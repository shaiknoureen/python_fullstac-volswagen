#!/usr/bin/env python3
"""
EduConnect LMS - Simple Mock Backend Server
Simulates Flask API without requiring Flask installation
Uses built-in Python HTTP server
"""

import json
import sqlite3
import os
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from datetime import datetime
from hashlib import sha256
import threading
import time

# Database path
DB_PATH = 'lms.db'

# Simple in-memory session storage
SESSIONS = {}
SESSION_USERS = {}

# Demo users (email -> password hash)
DEMO_USERS = {
    'admin@example.com': {
        'id': 1,
        'full_name': 'Admin User',
        'email': 'admin@example.com',
        'password': 'password123',
        'role': 'admin'
    },
    'instructor@example.com': {
        'id': 2,
        'full_name': 'Jane Instructor',
        'email': 'instructor@example.com',
        'password': 'password123',
        'role': 'instructor'
    },
    'student@example.com': {
        'id': 3,
        'full_name': 'John Student',
        'email': 'student@example.com',
        'password': 'password123',
        'role': 'student'
    }
}

# In-memory data storage
DATA = {
    'courses': [
        {'id': 1, 'title': 'Python Basics', 'description': 'Learn Python from scratch', 'instructor_id': 2, 'category': 'Technology', 'price': 99.99, 'student_count': 5},
        {'id': 2, 'title': 'Web Development', 'description': 'Build web applications', 'instructor_id': 2, 'category': 'Technology', 'price': 149.99, 'student_count': 8},
        {'id': 3, 'title': 'Business Strategy', 'description': 'Master business planning', 'instructor_id': 2, 'category': 'Business', 'price': 199.99, 'student_count': 3},
    ],
    'assignments': [
        {'id': 1, 'course_id': 1, 'title': 'Assignment 1', 'description': 'Complete Python basics', 'due_date': '2026-02-15', 'max_score': 100},
        {'id': 2, 'course_id': 1, 'title': 'Assignment 2', 'description': 'Build a calculator', 'due_date': '2026-02-22', 'max_score': 100},
    ],
    'enrollments': [
        {'id': 1, 'student_id': 3, 'course_id': 1, 'progress': 60, 'status': 'active'},
        {'id': 2, 'student_id': 3, 'course_id': 2, 'progress': 40, 'status': 'active'},
    ],
    'grades': [
        {'id': 1, 'submission_id': 1, 'student_id': 3, 'score': 85, 'feedback': 'Good work!'},
    ]
}


class APIHandler(BaseHTTPRequestHandler):
    """Handle HTTP requests for the API"""
    
    def do_POST(self):
        """Handle POST requests"""
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length).decode('utf-8')
        
        path = urlparse(self.path).path
        
        # Login endpoint
        if path == '/api/auth/login':
            data = json.loads(body) if body else {}
            email = data.get('email')
            password = data.get('password')
            
            if email in DEMO_USERS and DEMO_USERS[email]['password'] == password:
                user = DEMO_USERS[email]
                session_id = sha256(f"{email}{time.time()}".encode()).hexdigest()
                SESSIONS[session_id] = email
                SESSION_USERS[session_id] = user
                
                response = {
                    'success': True,
                    'user': {
                        'id': user['id'],
                        'full_name': user['full_name'],
                        'email': user['email'],
                        'role': user['role']
                    },
                    'session_id': session_id
                }
                self.send_json(response)
            else:
                self.send_json({'error': 'Invalid credentials'}, 401)
        
        # Register endpoint
        elif path == '/api/auth/register':
            data = json.loads(body) if body else {}
            email = data.get('email')
            
            if email in DEMO_USERS:
                self.send_json({'error': 'Email already registered'}, 400)
            else:
                new_id = max([u['id'] for u in DEMO_USERS.values()]) + 1
                DEMO_USERS[email] = {
                    'id': new_id,
                    'full_name': data.get('full_name'),
                    'email': email,
                    'password': data.get('password'),
                    'role': data.get('role', 'student')
                }
                self.send_json({'success': True, 'message': 'User registered'})
        
        else:
            self.send_json({'error': 'Not found'}, 404)
    
    def do_GET(self):
        """Handle GET requests"""
        path = urlparse(self.path).path
        query = parse_qs(urlparse(self.path).query)
        
        # Get dashboard stats
        if path == '/api/stats/dashboard':
            response = {
                'total_users': len(DEMO_USERS),
                'total_courses': len(DATA['courses']),
                'total_students_enrolled': len(DATA['enrollments']),
                'total_revenue': sum(c['price'] * c['student_count'] for c in DATA['courses'])
            }
            self.send_json(response)
        
        # Get all courses
        elif path == '/api/courses':
            self.send_json({'courses': DATA['courses']})
        
        # Get course by ID
        elif path.startswith('/api/courses/'):
            course_id = int(path.split('/')[-1])
            course = next((c for c in DATA['courses'] if c['id'] == course_id), None)
            if course:
                self.send_json(course)
            else:
                self.send_json({'error': 'Course not found'}, 404)
        
        # Get all users
        elif path == '/api/users':
            users = [{'id': u['id'], 'full_name': u['full_name'], 'email': u['email'], 'role': u['role']} 
                    for u in DEMO_USERS.values()]
            self.send_json({'users': users})
        
        # Get all assignments
        elif path == '/api/assignments':
            self.send_json({'assignments': DATA['assignments']})
        
        # Get all enrollments
        elif path == '/api/enrollments':
            self.send_json({'enrollments': DATA['enrollments']})
        
        # Get all grades
        elif path == '/api/grades':
            self.send_json({'grades': DATA['grades']})
        
        # Get instructor stats
        elif path == '/api/instructor/stats':
            stats = {
                'active_courses': len([c for c in DATA['courses'] if c['instructor_id'] == 2]),
                'total_students': len([e for e in DATA['enrollments']]),
                'pending_grading': 0
            }
            self.send_json(stats)
        
        # Get instructor courses
        elif path == '/api/instructor/courses':
            courses = [c for c in DATA['courses'] if c['instructor_id'] == 2]
            self.send_json({'courses': courses})
        
        else:
            self.send_json({'error': 'Endpoint not found'}, 404)
    
    def do_PUT(self):
        """Handle PUT requests"""
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length).decode('utf-8')
        data = json.loads(body) if body else {}
        
        path = urlparse(self.path).path
        
        # Update course
        if path.startswith('/api/courses/'):
            course_id = int(path.split('/')[-1])
            course = next((c for c in DATA['courses'] if c['id'] == course_id), None)
            if course:
                course.update(data)
                self.send_json({'success': True, 'course': course})
            else:
                self.send_json({'error': 'Course not found'}, 404)
        else:
            self.send_json({'error': 'Not found'}, 404)
    
    def do_DELETE(self):
        """Handle DELETE requests"""
        path = urlparse(self.path).path
        
        # Delete course
        if path.startswith('/api/courses/'):
            course_id = int(path.split('/')[-1])
            global DATA
            DATA['courses'] = [c for c in DATA['courses'] if c['id'] != course_id]
            self.send_json({'success': True, 'message': 'Course deleted'})
        
        # Delete user
        elif path.startswith('/api/users/'):
            user_id = int(path.split('/')[-1])
            # Mark user as inactive instead of deleting
            for email, user in DEMO_USERS.items():
                if user['id'] == user_id:
                    user['is_active'] = False
                    self.send_json({'success': True, 'message': 'User deactivated'})
                    return
            self.send_json({'error': 'User not found'}, 404)
        else:
            self.send_json({'error': 'Not found'}, 404)
    
    def do_OPTIONS(self):
        """Handle CORS preflight requests"""
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization')
        self.end_headers()
    
    def send_json(self, data, status=200):
        """Send JSON response"""
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization')
        self.end_headers()
        self.wfile.write(json.dumps(data).encode('utf-8'))
    
    def log_message(self, format, *args):
        """Override to customize logging"""
        print(f"[{self.log_date_time_string()}] {format % args}")


def run_server(port=5000):
    """Run the mock backend server"""
    server_address = ('', port)
    httpd = HTTPServer(server_address, APIHandler)
    print(f"🚀 Mock Backend Server running on http://localhost:{port}")
    print("📊 API Endpoints available:")
    print("  - POST /api/auth/login")
    print("  - POST /api/auth/register")
    print("  - GET  /api/courses")
    print("  - GET  /api/users")
    print("  - GET  /api/assignments")
    print("  - GET  /api/enrollments")
    print("  - GET  /api/stats/dashboard")
    print("  - GET  /api/instructor/stats")
    print("  - POST /api/courses (create)")
    print("  - PUT  /api/courses/:id (update)")
    print("  - DELETE /api/courses/:id (delete)")
    print("\n✅ Ready to serve requests!\n")
    httpd.serve_forever()


if __name__ == '__main__':
    run_server()
