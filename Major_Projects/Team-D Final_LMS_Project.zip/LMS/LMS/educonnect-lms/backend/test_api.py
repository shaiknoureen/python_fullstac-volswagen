#!/usr/bin/env python3
"""
Test script for EduConnect LMS backend
"""

import urllib.request
import json
import threading
import time
import sys
import os

# Add the backend directory to the path
sys.path.insert(0, os.path.dirname(__file__))

from server import run_server

def start_server():
    """Start server in a thread"""
    run_server(8001)  # Use different port

def test_api():
    """Test API endpoints"""
    print("Starting API tests...")
    time.sleep(2)  # Wait for server to start

    try:
        # Test courses API
        print("Testing courses API...")
        response = urllib.request.urlopen('http://localhost:8001/api/courses')
        data = json.loads(response.read().decode('utf-8'))
        print(f'SUCCESS: Courses API returned {len(data)} courses')
        if len(data) > 0:
            print(f'First course: {data[0]["title"]}')

        # Test login API
        print("Testing login API...")
        login_data = json.dumps({
            'email': 'admin@educonnect.com',
            'password': 'admin123'
        }).encode('utf-8')

        req = urllib.request.Request('http://localhost:8001/api/auth/login',
                                   data=login_data,
                                   headers={'Content-Type': 'application/json'})
        response = urllib.request.urlopen(req)
        result = json.loads(response.read().decode('utf-8'))
        print(f'Login test: {result}')

    except Exception as e:
        print(f'ERROR: {e}')
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    # Start server in background thread
    server_thread = threading.Thread(target=start_server, daemon=True)
    server_thread.start()

    # Run tests
    test_api()

if __name__ == "__main__":
    test_api()