"""
Database Management Utilities for EduConnect LMS
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from models.database import db
from models.user import User
from models.course import Course
from models.enrollment import Enrollment

def init_database():
    """Initialize the database with sample data"""
    print("Initializing database...")
    db.reset_database()
    print("Database initialized successfully!")

def show_stats():
    """Show database statistics"""
    print("=== EduConnect LMS Statistics ===")
    print(f"Total Users: {User.get_user_count()}")
    print(f"Admin Users: {User.get_user_count('admin')}")
    print(f"Instructor Users: {User.get_user_count('instructor')}")
    print(f"Student Users: {User.get_user_count('student')}")
    print(f"Total Courses: {Course.get_course_count()}")
    print(f"Active Enrollments: {Enrollment.get_enrollment_stats()[0]}")

def list_users():
    """List all users"""
    users = User.get_all_users()
    print("=== Users ===")
    for user in users:
        print(f"ID: {user[0]}, Name: {user[1]}, Email: {user[2]}, Role: {user[3]}")

def list_courses():
    """List all courses"""
    courses = Course.get_all_courses()
    print("=== Courses ===")
    for course in courses:
        print(f"ID: {course[0]}, Title: {course[1]}, Category: {course[2]}, Instructor: {course[14]}")

def test_authentication():
    """Test user authentication"""
    print("=== Testing Authentication ===")

    # Test admin login
    admin = User.authenticate('admin@educonnect.com', 'admin123')
    print(f"Admin login: {'Success' if admin else 'Failed'}")

    # Test instructor login
    instructor = User.authenticate('sarah.johnson@educonnect.com', 'instructor123')
    print(f"Instructor login: {'Success' if instructor else 'Failed'}")

    # Test student login
    student = User.authenticate('john.smith@educonnect.com', 'student123')
    print(f"Student login: {'Success' if student else 'Failed'}")

def main():
    """Main function"""
    if len(sys.argv) < 2:
        print("Usage: python manage.py <command>")
        print("Commands:")
        print("  init        - Initialize database")
        print("  stats       - Show database statistics")
        print("  users       - List all users")
        print("  courses     - List all courses")
        print("  test-auth   - Test authentication")
        return

    command = sys.argv[1]

    if command == 'init':
        init_database()
    elif command == 'stats':
        show_stats()
    elif command == 'users':
        list_users()
    elif command == 'courses':
        list_courses()
    elif command == 'test-auth':
        test_authentication()
    else:
        print(f"Unknown command: {command}")

if __name__ == "__main__":
    main()