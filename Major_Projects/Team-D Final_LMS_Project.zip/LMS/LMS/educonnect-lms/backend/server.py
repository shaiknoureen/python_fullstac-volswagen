"""
Simple HTTP Server for EduConnect LMS
Serves frontend files and handles basic backend operations
"""

import http.server
import socketserver
import urllib.parse
import json
import os
from datetime import datetime
from models.user import User
from models.course import Course
from models.enrollment import Enrollment

class LMSRequestHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        # Set the directory to serve files from
        self.directory = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        print(f"Serving files from: {self.directory}")  # Debug print
        super().__init__(*args, directory=self.directory, **kwargs)

    def do_GET(self):
        """Handle GET requests"""
        parsed_path = urllib.parse.urlparse(self.path)
        path = parsed_path.path

        # Handle API endpoints
        if path.startswith('/api/'):
            self.handle_api_get(path, parsed_path.query)
        else:
            # Serve static files
            super().do_GET()

    def do_POST(self):
        """Handle POST requests"""
        parsed_path = urllib.parse.urlparse(self.path)
        path = parsed_path.path

        # Handle API endpoints
        if path.startswith('/api/'):
            self.handle_api_post(path)
        else:
            # Handle form submissions
            self.handle_form_post(path)

    def handle_api_get(self, path, query):
        """Handle API GET requests"""
        try:
            if path == '/api/courses':
                self.get_courses(query)
            elif path == '/api/users':
                self.get_users(query)
            elif path == '/api/enrollments':
                self.get_enrollments(query)
            else:
                self.send_error(404, "API endpoint not found")
        except Exception as e:
            self.send_error(500, f"Server error: {str(e)}")

    def handle_api_post(self, path):
        """Handle API POST requests"""
        try:
            if path == '/api/auth/login':
                self.handle_login()
            elif path == '/api/auth/register':
                self.handle_register()
            elif path == '/api/courses':
                self.create_course()
            elif path == '/api/enrollments':
                self.create_enrollment()
            else:
                self.send_error(404, "API endpoint not found")
        except Exception as e:
            self.send_error(500, f"Server error: {str(e)}")

    def handle_form_post(self, path):
        """Handle form submissions"""
        try:
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length).decode('utf-8')
            form_data = urllib.parse.parse_qs(post_data)

            if path == '/login.html':
                self.handle_login_form(form_data)
            elif path == '/register.html':
                self.handle_register_form(form_data)
            else:
                self.send_error(404, "Form handler not found")
        except Exception as e:
            self.send_error(500, f"Server error: {str(e)}")

    def get_courses(self, query):
        """Get courses with optional filtering"""
        params = urllib.parse.parse_qs(query)
        category = params.get('category', [None])[0]
        search = params.get('search', [None])[0]
        limit = int(params.get('limit', ['50'])[0])
        offset = int(params.get('offset', ['0'])[0])

        if search:
            courses = Course.search_courses(search, category, limit, offset)
        else:
            courses = Course.get_all_courses(category, None, limit, offset)

        self.send_json_response(courses)

    def get_users(self, query):
        """Get users with optional filtering"""
        params = urllib.parse.parse_qs(query)
        role = params.get('role', [None])[0]
        limit = int(params.get('limit', ['50'])[0])
        offset = int(params.get('offset', ['0'])[0])

        users = User.get_all_users(role, limit, offset)
        self.send_json_response(users)

    def get_enrollments(self, query):
        """Get enrollments"""
        params = urllib.parse.parse_qs(query)
        student_id = params.get('student_id', [None])[0]
        course_id = params.get('course_id', [None])[0]

        if student_id:
            enrollments = Enrollment.get_student_enrollments(int(student_id))
        elif course_id:
            enrollments = Enrollment.get_course_enrollments(int(course_id))
        else:
            enrollments = Enrollment.get_recent_enrollments()

        self.send_json_response(enrollments)

    def handle_login(self):
        """Handle login API request"""
        data = self.get_json_data()
        user = User.authenticate(data.get('email'), data.get('password'))

        if user:
            response = {
                'success': True,
                'user': user.to_dict(),
                'redirect': self.get_redirect_url(user.role)
            }
        else:
            response = {'success': False, 'message': 'Invalid credentials'}

        self.send_json_response(response)

    def handle_register(self):
        """Handle registration API request"""
        data = self.get_json_data()
        user = User.register(
            data.get('full_name'),
            data.get('email'),
            data.get('password'),
            data.get('role', 'student')
        )

        if user:
            response = {
                'success': True,
                'user': user.to_dict(),
                'redirect': self.get_redirect_url(user.role)
            }
        else:
            response = {'success': False, 'message': 'Registration failed'}

        self.send_json_response(response)

    def create_course(self):
        """Create a new course"""
        data = self.get_json_data()
        course = Course.create_course(
            data.get('title'),
            data.get('description'),
            data.get('category'),
            data.get('instructor_id'),
            data.get('image_url'),
            data.get('price', 0),
            data.get('original_price', 0),
            data.get('duration'),
            data.get('level', 'Beginner'),
            data.get('max_students', 0)
        )

        if course:
            response = {'success': True, 'course': course.to_dict()}
        else:
            response = {'success': False, 'message': 'Course creation failed'}

        self.send_json_response(response)

    def create_enrollment(self):
        """Create a new enrollment"""
        data = self.get_json_data()
        success = Enrollment.enroll_student(data.get('student_id'), data.get('course_id'))

        if success:
            response = {'success': True, 'message': 'Enrollment successful'}
        else:
            response = {'success': False, 'message': 'Enrollment failed'}

        self.send_json_response(response)

    def handle_login_form(self, form_data):
        """Handle login form submission"""
        email = form_data.get('email', [''])[0]
        password = form_data.get('password', [''])[0]
        role = form_data.get('role', ['student'])[0]

        user = User.authenticate(email, password)

        if user and user.role == role:
            # Create session and redirect
            redirect_url = self.get_redirect_url(user.role)
            self.send_redirect(redirect_url)
        else:
            # Redirect back to login with error
            self.send_redirect('/login.html?error=1')

    def handle_register_form(self, form_data):
        """Handle registration form submission"""
        full_name = form_data.get('full_name', [''])[0]
        email = form_data.get('email', [''])[0]
        password = form_data.get('password', [''])[0]
        role = form_data.get('role', ['student'])[0]

        user = User.register(full_name, email, password, role)

        if user:
            redirect_url = self.get_redirect_url(user.role)
            self.send_redirect(redirect_url)
        else:
            self.send_redirect('/register.html?error=1')

    def get_redirect_url(self, role):
        """Get redirect URL based on user role"""
        redirects = {
            'admin': '/admin/admin-dashboard.html',
            'instructor': '/instructor/instructor-dashboard.html',
            'student': '/student/student-dashboard.html'
        }
        return redirects.get(role, '/index.html')

    def get_json_data(self):
        """Get JSON data from request body"""
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length).decode('utf-8')
        return json.loads(post_data)

    def send_json_response(self, data):
        """Send JSON response"""
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps(data).encode())

    def send_redirect(self, location):
        """Send redirect response"""
        self.send_response(302)
        self.send_header('Location', location)
        self.end_headers()

def run_server(port=8000):
    """Run the LMS server"""
    try:
        with socketserver.TCPServer(("", port), LMSRequestHandler) as httpd:
            print(f"Server running at http://localhost:{port}")
            print("Press Ctrl+C to stop")
            try:
                httpd.serve_forever()
            except KeyboardInterrupt:
                print("\nServer stopped by user")
    except Exception as e:
        print(f"Server error: {e}")
        import traceback
        traceback.print_exc()
    finally:
        print("Server stopped")

if __name__ == "__main__":
    run_server()