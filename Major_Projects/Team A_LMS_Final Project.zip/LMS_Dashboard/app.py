from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import os

app = Flask(__name__)
app.secret_key = 'smart_lms_2026'

# --- DATABASE CONFIG ---
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'lms.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db_sq = SQLAlchemy(app)

# --- MODELS ---
class User(db_sq.Model):
    id = db_sq.Column(db_sq.Integer, primary_key=True)
    name = db_sq.Column(db_sq.String(100), nullable=False) 
    username = db_sq.Column(db_sq.String(50), unique=True, nullable=False)
    email = db_sq.Column(db_sq.String(120), unique=True, nullable=False) 
    password = db_sq.Column(db_sq.String(200), nullable=False)
    role = db_sq.Column(db_sq.String(20), nullable=False)

# NEW: Quiz Model
class Quiz(db_sq.Model):
    id = db_sq.Column(db_sq.Integer, primary_key=True)
    title = db_sq.Column(db_sq.String(100), nullable=False)
    faculty_username = db_sq.Column(db_sq.String(50), nullable=False)
    questions = db_sq.relationship('Question', backref='quiz', lazy=True, cascade="all, delete-orphan")

# NEW: Question Model
class Question(db_sq.Model):
    id = db_sq.Column(db_sq.Integer, primary_key=True)
    quiz_id = db_sq.Column(db_sq.Integer, db_sq.ForeignKey('quiz.id'), nullable=False)
    question_text = db_sq.Column(db_sq.Text, nullable=False)
    op1 = db_sq.Column(db_sq.String(100), nullable=False)
    op2 = db_sq.Column(db_sq.String(100), nullable=False)
    op3 = db_sq.Column(db_sq.String(100), nullable=False)
    op4 = db_sq.Column(db_sq.String(100), nullable=False)
    correct_ans = db_sq.Column(db_sq.String(10), nullable=False)

class QuizResult(db_sq.Model):
    id = db_sq.Column(db_sq.Integer, primary_key=True)
    student_username = db_sq.Column(db_sq.String(50), nullable=False)
    quiz_id = db_sq.Column(db_sq.Integer, nullable=False)
    score = db_sq.Column(db_sq.Integer, nullable=False)
    __table_args__ = (
        db_sq.UniqueConstraint('student_username', 'quiz_id'),
    )

class Course(db_sq.Model):
    id = db_sq.Column(db_sq.Integer, primary_key=True)
    title = db_sq.Column(db_sq.String(200), nullable=False)
    description = db_sq.Column(db_sq.Text, nullable=False)
    video_url = db_sq.Column(db_sq.String(300), nullable=False)

class Enrollment(db_sq.Model):
    id = db_sq.Column(db_sq.Integer, primary_key=True)
    student_username = db_sq.Column(db_sq.String(50), nullable=False)
    course_id = db_sq.Column(db_sq.Integer, nullable=False)
    progress = db_sq.Column(db_sq.Integer, default=0)  # 👈 percentage watched


with app.app_context():
    db_sq.create_all()


# --- LOGIN/SIGNUP LOGIC ---
@app.route('/auth', methods=['POST'])
def auth():
    action = request.form.get('action')
    name = request.form.get('name') 
    username = request.form.get('username')
    email = request.form.get('email') 
    password = request.form.get('password')
    role = request.form.get('role')

    if action == 'signup':
        if User.query.filter_by(username=username).first():
            flash('Username already exists!')
            return redirect(url_for('login_page'))
        
        new_user = User(name=name, username=username, email=email, 
                        password=generate_password_hash(password), role=role)
        db_sq.session.add(new_user)
        db_sq.session.commit()
        flash('Account created! Please login.')
        return redirect(url_for('login_page'))
    else:
        user = User.query.filter_by(username=username, role=role).first()
        if user and check_password_hash(user.password, password):
            session['username'] = user.username
            session['full_name'] = user.name 
            session['role'] = user.role
            return redirect(url_for(f'{user.role}_dash'))
        flash('Invalid login for selected role.')
        return redirect(url_for('login_page'))

@app.route('/add_quiz', methods=['POST'])
def add_quiz():
    if session.get('role') != 'faculty':
        return redirect(url_for('login_page'))

    title = request.form.get('title').strip()
    faculty = session['username']

    # 1️⃣ Check if quiz with this title already exists for this faculty
    quiz = Quiz.query.filter_by(
        title=title,
        faculty_username=faculty
    ).first()

    # 2️⃣ If not, create the quiz ONCE
    if not quiz:
        quiz = Quiz(
            title=title,
            faculty_username=faculty
        )
        db_sq.session.add(quiz)
        db_sq.session.flush()   # ensures quiz.id is available

    # 3️⃣ Add a new question to the SAME quiz
    question = Question(
        quiz_id=quiz.id,
        question_text=request.form.get('question_text'),
        op1=request.form.get('op1'),
        op2=request.form.get('op2'),
        op3=request.form.get('op3'),
        op4=request.form.get('op4'),
        correct_ans=request.form.get('correct_ans')
    )

    db_sq.session.add(question)
    db_sq.session.commit()

    flash("Question added to the quiz successfully!")
    return redirect(url_for('faculty_dash'))



# --- DASHBOARD ROUTES ---
@app.route('/')
def login_page():
    return render_template('login.html')

@app.route('/dashboard/student')
def student_dash():
    if session.get('role') != 'student':
        return redirect(url_for('login_page'))

    results = db_sq.session.query(
        Quiz.title,
        QuizResult.score
    ).join(Quiz, Quiz.id == QuizResult.quiz_id)\
     .filter(QuizResult.student_username == session['username'])\
     .all()

    quiz_data = [
        {"title": r[0], "score": r[1]}
        for r in results
    ]

    user_context = {
        "name": session.get('full_name', 'Student'),
        "quiz_data": quiz_data,
        "quiz_scores": [q["score"] for q in quiz_data],
        "quiz_titles": [q["title"] for q in quiz_data]
    }

    data_context = {
        "courses": [{"title": "Advanced Web Dev", "url": "https://www.youtube.com/embed/qz0aGYrrlhU"}]
    }

    return render_template(
        'student_dash.html',
        user=user_context,
        db=data_context
    )


@app.route('/dashboard/admin')
def admin_dash():
    if session.get('role') != 'admin': return redirect(url_for('login_page'))
    students_query = User.query.filter_by(role='student').all()
    teachers_query = User.query.filter_by(role='faculty').all()
    data_context = {
        "students": [{"id": s.id, "name": s.name, "id_num": "STU-" + str(s.id)} for s in students_query],
        "teachers": [{"id": t.id, "name": t.name, "dept": "General Academics"} for t in teachers_query]
    }
    return render_template('admin_dash.html', username=session.get('full_name', 'Admin'), db=data_context)

@app.route('/dashboard/faculty')
def faculty_dash():
    if session.get('role') != 'faculty': return redirect(url_for('login_page'))
    data_context = {"courses": [{"title": "Advanced Web Dev", "url": "https://www.youtube.com/embed/qz0aGYrrlhU"}]}
    return render_template('faculty_dash.html', username=session.get('full_name', 'Faculty'), db=data_context)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login_page'))


@app.route('/student/quizzes')
def student_quizzes():
    if session.get('role') != 'student':
        return redirect(url_for('login_page'))

    quizzes = Quiz.query.all()
    return render_template('student_quizzes.html', quizzes=quizzes)

@app.route('/student/quiz/<int:quiz_id>')
def take_quiz(quiz_id):
    if session.get('role') != 'student':
        return redirect(url_for('login_page'))

    quiz = Quiz.query.get_or_404(quiz_id)
    questions = Question.query.filter_by(quiz_id=quiz.id).all()

    return render_template(
        'take_quiz.html',
        quiz=quiz,
        questions=questions
    )

@app.route('/student/quiz/submit/<int:quiz_id>', methods=['POST'])
def submit_quiz(quiz_id):
    if session.get('role') != 'student':
        return redirect(url_for('login_page'))

    questions = Question.query.filter_by(quiz_id=quiz_id).all()
    total = len(questions)
    correct = 0

    for q in questions:
        selected = request.form.get(f"q_{q.id}")
        if selected == q.correct_ans:
            correct += 1

    percentage = round((correct / total) * 100, 2)

    # ✅ SAVE RESULT
    # ✅ SAVE / UPDATE RESULT (ONE RESULT PER QUIZ)
    existing_result = QuizResult.query.filter_by(
        student_username=session['username'],
        quiz_id=quiz_id
    ).first()

    if existing_result:
        # Re-attempt → update score
        existing_result.score = percentage
    else:
        # First attempt → insert
        db_sq.session.add(
        QuizResult(
            student_username=session['username'],
            quiz_id=quiz_id,
            score=percentage
        )
    )

    db_sq.session.commit()

    return render_template(
        'quiz_result.html',
        score=percentage,
        correct=correct,
        total=total
    )

@app.route('/seed_courses')
def seed_courses():
    if Course.query.first():
        return "Courses already exist"

    courses = [
        ("Java for Beginners", "Complete Java fundamentals for beginners", "https://www.youtube.com/embed/grEKMHGYyns"),
        ("Data Structures in Java", "Learn arrays, stacks, queues, linked lists", "https://www.youtube.com/embed/BBpAmxU_NQo"),
        ("Python for Beginners", "Python basics to advanced concepts", "https://www.youtube.com/embed/_uQrJ0TkZlc"),
        ("C++ Full Course", "Complete C++ programming for interviews", "https://www.youtube.com/embed/vLnPwxZdW4Y"),
        ("Operating Systems", "OS concepts for software engineers", "https://www.youtube.com/embed/26QPDBe-NB8"),
        ("DBMS Full Course", "Database management systems concepts", "https://www.youtube.com/embed/HXV3zeQKqGY"),
        ("Computer Networks", "Networking fundamentals explained", "https://www.youtube.com/embed/qiQR5rTSshw"),
        ("System Design Basics", "System design fundamentals", "https://www.youtube.com/embed/UzLMhqg3_Wc"),
        ("Git & GitHub", "Version control with Git", "https://www.youtube.com/embed/RGOj5yH7evk"),
        ("REST APIs", "RESTful API design", "https://www.youtube.com/embed/Q-BpqyOT3a8"),
    ]

    # duplicate to reach ~50
    full_list = courses * 5

    for title, desc, url in full_list:
        db_sq.session.add(Course(title=title, description=desc, video_url=url))

    db_sq.session.commit()
    return "50 courses added successfully"

@app.route('/student/library')
def content_library():
    if session.get('role') != 'student':
        return redirect(url_for('login_page'))

    courses = Course.query.all()
    enrolled_ids = [
        e.course_id for e in Enrollment.query.filter_by(
            student_username=session['username']
        ).all()
    ]

    return render_template(
        'content_library.html',
        courses=courses,
        enrolled_ids=enrolled_ids
    )


@app.route('/student/enroll/<int:course_id>', methods=['POST'])
def enroll_course(course_id):
    if session.get('role') != 'student':
        return {"status": "unauthorized"}, 401

    already = Enrollment.query.filter_by(
        student_username=session['username'],
        course_id=course_id
    ).first()

    if not already:
        db_sq.session.add(
            Enrollment(
                student_username=session['username'],
                course_id=course_id
            )
        )
        db_sq.session.commit()

    return {"status": "enrolled"}


@app.route('/student/my-courses')
def my_courses():
    if session.get('role') != 'student':
        return redirect(url_for('login_page'))

    data = db_sq.session.query(
        Course.id,
        Course.title,
        Course.description,
        Enrollment.progress
    ).join(
        Enrollment, Course.id == Enrollment.course_id
    ).filter(
        Enrollment.student_username == session['username']
    ).all()

    courses = [
        {
            "id": d.id,
            "title": d.title,
            "description": d.description,
            "progress": d.progress
        }
        for d in data
    ]

    return render_template('my_courses.html', courses=courses)



@app.route('/student/remove/<int:course_id>', methods=['POST'])
def remove_course(course_id):
    if session.get('role') != 'student':
        return {"status": "unauthorized"}, 401

    enrollment = Enrollment.query.filter_by(
        student_username=session['username'],
        course_id=course_id
    ).first()

    if enrollment:
        db_sq.session.delete(enrollment)
        db_sq.session.commit()

    return {"status": "removed"}

@app.route('/student/update-progress/<int:course_id>', methods=['POST'])
def update_progress(course_id):
    enrollment = Enrollment.query.filter_by(
        student_username=session['username'],
        course_id=course_id
    ).first()

    if enrollment:
        enrollment.progress = min(enrollment.progress + 25, 100)
        db_sq.session.commit()

    return {"status": "updated"}

@app.route('/student/course/<int:course_id>')
def watch_course(course_id):
    if session.get('role') != 'student':
        return redirect(url_for('login_page'))

    course = Course.query.get_or_404(course_id)

    enrollment = Enrollment.query.filter_by(
        student_username=session['username'],
        course_id=course_id
    ).first()

    return render_template('watch_course.html', course=course)

@app.route('/student/results')
def student_results():
    if session.get('role') != 'student':
        return redirect(url_for('login_page'))

    results = db_sq.session.query(
        Quiz.title,
        QuizResult.score
    ).join(
        Quiz, Quiz.id == QuizResult.quiz_id
    ).filter(
        QuizResult.student_username == session['username']
    ).all()

    exam_results = [
        {
            "title": r.title,
            "score": r.score
        }
        for r in results
    ]

    return render_template(
        'exam_results.html',
        results=exam_results
    )

if __name__ == '__main__':
    app.run(debug=True)