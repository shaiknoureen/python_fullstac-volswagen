// ================================
// Student Dashboard Initialization
// ================================
document.addEventListener('DOMContentLoaded', () => {
    checkAuth();
    initializeDashboard();
});

// ================================
// Authentication Check
// ================================
function checkAuth() {
    // Try server-side session first
    fetch('/api/user', { credentials: 'same-origin' })
        .then(res => {
            if (!res.ok) throw new Error('no-session');
            return res.json();
        })
        .then(data => {
            if (data.status === 'success') {
                currentUser = data.user;
                localStorage.setItem('user', JSON.stringify(currentUser));

                // Verify role - redirect instructors to instructor dashboard
                if (currentUser.role === 'instructor' || currentUser.role === 'admin') {
                    window.location.href = '/instructor_dashboard.html';
                    return;
                }

                const userGreeting = document.getElementById('userGreeting');
                if (userGreeting) userGreeting.textContent = `Welcome, ${currentUser.username}!`;
                return;
            }
            throw new Error('no-session');
        })
        .catch(() => {
            // Fallback to localStorage
            const user = localStorage.getItem('user');
            
            if (!user) {
                window.location.href = '/';
                return;
            }

            currentUser = JSON.parse(user);
            
            // Verify role
            if (currentUser.role === 'instructor' || currentUser.role === 'admin') {
                window.location.href = '/instructor_dashboard.html';
                return;
            }

            const userGreeting = document.getElementById('userGreeting');
            if (userGreeting) userGreeting.textContent = `Welcome, ${currentUser.username}!`;
        });
}

// ================================
// Initialize Dashboard
// ================================
function initializeDashboard() {
    loadDashboardStats();
    loadMyCourses();
}

async function loadDashboardStats() {
    try {
        const response = await fetch('/api/my-courses', { credentials: 'same-origin' });
        const data = await response.json();

        if (data.status === 'success') {
            const courses = data.courses;
            const enrolledCount = courses.length;
            const avgProgress = courses.length > 0 
                ? Math.round(courses.reduce((sum, c) => sum + (c.progress || 0), 0) / courses.length) 
                : 0;

            updateStats(enrolledCount, avgProgress);
        }
    } catch (error) {
        console.error('Error loading stats:', error);
    }
}

function updateStats(enrolledCount, avgProgress) {
    const statsContainer = document.getElementById('statsContainer');
    if (!statsContainer) return;
    
    statsContainer.innerHTML = `
        <div class="stat-card">
            <div class="stat-value">${enrolledCount}</div>
            <div class="stat-label">Courses Enrolled</div>
        </div>
        <div class="stat-card">
            <div class="stat-value">${avgProgress}%</div>
            <div class="stat-label">Average Progress</div>
        </div>
        <div class="stat-card">
            <div class="stat-value">0</div>
            <div class="stat-label">Certificates</div>
        </div>
        <div class="stat-card">
            <div class="stat-value">0h</div>
            <div class="stat-label">Hours Learned</div>
        </div>
    `;
}

// ================================
// My Courses Section
// ================================
async function loadMyCourses() {
    try {
        const response = await fetch('/api/my-courses', { credentials: 'same-origin' });
        const data = await response.json();

        if (data.status === 'success') {
            const courses = data.courses;
            const container = document.getElementById('myCoursesContainer');
            const continueLearningContainer = document.getElementById('continueLearningContainer');

            if (courses.length === 0) {
                const emptyHtml = `
                    <div style="grid-column: 1 / -1; text-align: center; padding: 40px; color: var(--gray);">
                        <p><i class="fas fa-inbox"></i> You haven't enrolled in any courses yet.</p>
                        <a href="/" class="nav-button" style="display: inline-block; margin-top: 20px;">Browse Courses</a>
                    </div>
                `;
                if (container) container.innerHTML = emptyHtml;
                if (continueLearningContainer) continueLearningContainer.innerHTML = emptyHtml;
            } else {
                const courseHtml = courses.map(course => `
                    <div class="course-card" onclick="viewCourseLessons(${course.id})">
                        <div class="course-media">
                            <img class="course-thumb" src="${getCourseThumbnail(course)}" alt="${course.title || 'Course'} thumbnail">
                            <div class="course-media-overlay"></div>
                            <div class="course-media-tag">${course.category || 'General'}</div>
                        </div>
                        <div class="course-body">
                            <span class="course-category">${course.category || 'General'}</span>
                            <h3 class="course-title">${course.title || 'Course'}</h3>
                            <p class="course-description">${course.description || 'Course content'}</p>
                            <div style="margin-top: 15px; padding-top: 15px; border-top: 1px solid var(--border);">
                                <div style="width: 100%; height: 8px; background: var(--border); border-radius: 4px; overflow: hidden;">
                                    <div style="width: ${course.progress || 0}%; height: 100%; background: var(--primary);"></div>
                                </div>
                                <small style="color: var(--gray); display: block; margin-top: 8px;">
                                    Progress: ${course.progress || 0}%
                                </small>
                            </div>
                        </div>
                    </div>
                `).join('');

                if (container) container.innerHTML = courseHtml;
                if (continueLearningContainer) continueLearningContainer.innerHTML = courseHtml.slice(0, 3);
            }
        }
    } catch (error) {
        console.error('Error loading courses:', error);
    }
}

function getCourseThumbnail(course) {
    if (course.thumbnail_url) return course.thumbnail_url;
    if (course.thumbnail) return course.thumbnail;
    if (course.image_url) return course.image_url;

    const fallbackByCategory = {
        "Web Development": "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=900&q=80",
        "Data Science": "https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=900&q=80",
        "Design": "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=900&q=80",
        "Mobile Development": "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=900&q=80",
        "Cloud": "https://images.unsplash.com/photo-1487058792275-0ad4aaf24ca7?auto=format&fit=crop&w=900&q=80",
        "Marketing": "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=900&q=80",
        "Business": "https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=900&q=80"
    };

    return fallbackByCategory[course.category] || "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=900&q=80";
}

function viewCourseLessons(courseId) {
    window.location.href = `/course-detail.html?id=${courseId}`;
}

// ================================
// Progress Tracking
// ================================
async function loadProgress() {
    try {
        const response = await fetch('/api/my-courses', { credentials: 'same-origin' });
        const data = await response.json();

        if (data.status === 'success') {
            const courses = data.courses;
            let html = '<h3 style="margin-bottom: 20px;">Your Learning Progress</h3>';
            
            if (courses.length === 0) {
                html += '<p style="color: var(--gray);">No enrolled courses</p>';
            } else {
                html += '<div style="display: grid; gap: 20px;">';
                courses.forEach(course => {
                    html += `
                        <div style="padding: 15px; border: 1px solid var(--border); border-radius: 8px;">
                            <h4>${course.title}</h4>
                            <div style="margin: 10px 0;">
                                <div style="width: 100%; height: 10px; background: var(--border); border-radius: 5px; overflow: hidden;">
                                    <div style="width: ${course.progress || 0}%; height: 100%; background: var(--primary); transition: width 0.3s;"></div>
                                </div>
                                <small style="color: var(--gray);">${course.progress || 0}% Complete</small>
                            </div>
                        </div>
                    `;
                });
                html += '</div>';
            }
            
            const container = document.getElementById('progressSection');
            if (container) container.innerHTML = html;
        }
    } catch (error) {
        console.error('Error loading progress:', error);
    }
}

// ================================
// Certificates
// ================================
async function loadCertificates() {
    const container = document.getElementById('certificatesSection');
    if (!container) return;
    
    try {
        const response = await fetch('/api/my-courses', { credentials: 'same-origin' });
        const data = await response.json();

        if (data.status === 'success') {
            const completedCourses = data.courses.filter(c => c.progress === 100);
            
            let html = '<h3 style="margin-bottom: 20px;">Your Certificates</h3>';
            
            if (completedCourses.length === 0) {
                html += '<p style="color: var(--gray);">Complete a course to earn a certificate!</p>';
            } else {
                html += '<div style="display: grid; gap: 15px;">';
                completedCourses.forEach(course => {
                    html += `
                        <div style="padding: 20px; border: 2px solid var(--primary); border-radius: 8px; text-align: center;">
                            <i class="fas fa-certificate" style="font-size: 48px; color: var(--primary); margin-bottom: 10px;"></i>
                            <h4>${course.title}</h4>
                            <p style="color: var(--gray); font-size: 14px;">Certificate of Completion</p>
                            <button class="nav-button" style="margin-top: 10px;" onclick="downloadCertificate(${course.id})">
                                Download
                            </button>
                        </div>
                    `;
                });
                html += '</div>';
            }
            
            container.innerHTML = html;
        }
    } catch (error) {
        console.error('Error loading certificates:', error);
    }
}

function downloadCertificate(courseId) {
    showAlert('Certificate download feature coming soon!', 'info');
}

// ================================
// Profile Management
// ================================
async function loadProfile() {
    const container = document.getElementById('profileSection');
    if (!container) return;
    
    let html = `
        <h3 style="margin-bottom: 20px;">My Profile</h3>
        <div style="max-width: 600px;">
            <form id="profileForm" onsubmit="handleProfileUpdate(event)">
                <div style="margin-bottom: 15px;">
                    <label class="form-label">Username</label>
                    <input type="text" class="form-control" value="${currentUser.username}" disabled>
                </div>
                <div style="margin-bottom: 15px;">
                    <label class="form-label">Email</label>
                    <input type="email" class="form-control" id="profileEmail" value="${currentUser.email}">
                </div>
                <div style="margin-bottom: 15px;">
                    <label class="form-label">New Password (optional)</label>
                    <input type="password" class="form-control" id="profilePassword" placeholder="Leave empty to keep current password">
                </div>
                <button type="submit" class="nav-button">Update Profile</button>
            </form>
        </div>
    `;
    
    container.innerHTML = html;
    document.getElementById('profileForm').addEventListener('submit', handleProfileUpdate);
}

async function handleProfileUpdate(e) {
    e.preventDefault();
    
    const email = document.getElementById('profileEmail').value;
    const password = document.getElementById('profilePassword').value;
    
    try {
        const updateData = { email };
        if (password) updateData.password = password;
        
        const response = await fetch('/api/update-profile', {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(updateData)
        });
        
        const data = await response.json();
        
        if (data.status === 'success') {
            currentUser.email = email;
            localStorage.setItem('user', JSON.stringify(currentUser));
            showAlert('Profile updated successfully!', 'success');
        } else {
            showAlert(data.message || 'Failed to update profile', 'error');
        }
    } catch (error) {
        showAlert('Connection error', 'error');
        console.error('Profile update error:', error);
    }
}

// ================================
// Section Navigation
// ================================
function showSection(sectionId) {
    document.querySelectorAll('.dashboard-section').forEach(section => {
        section.style.display = 'none';
    });

    const section = document.getElementById(sectionId);
    if (section) section.style.display = 'block';

    document.querySelectorAll('.sidebar-link').forEach(link => {
        link.classList.remove('active');
    });
    
    if (event && event.target) {
        event.target.closest('.sidebar-link')?.classList.add('active');
    }
}

// ================================
// Logout
// ================================
async function logout() {
    try {
        await fetch('/api/logout', {
            method: 'POST',
            credentials: 'same-origin'
        });
    } catch (error) {
        console.error('Logout error:', error);
    }
    
    localStorage.removeItem('user');
    localStorage.removeItem('session_id');
    currentUser = null;
    window.location.href = '/';
}

// ================================
// Alert Helper
// ================================
function showAlert(message, type = 'info') {
    const alertDiv = document.createElement('div');
    alertDiv.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 20px;
        background: ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#3b82f6'};
        color: white;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 9999;
        max-width: 400px;
        word-wrap: break-word;
    `;
    
    alertDiv.textContent = message;
    document.body.appendChild(alertDiv);
    
    setTimeout(() => alertDiv.remove(), 3000);
}
