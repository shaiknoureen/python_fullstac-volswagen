// ================================
// Instructor Dashboard Initialization
// ================================
document.addEventListener('DOMContentLoaded', () => {
    checkAuth();
    initializeDashboard();
    setupEventListeners();
});

// ================================
// Authentication Check
// ================================
function checkAuth() {
    // Prefer server-side session (HttpOnly cookie)
    fetch('/api/user', { credentials: 'same-origin' })
        .then(res => {
            if (!res.ok) throw new Error('no-session');
            return res.json();
        })
        .then(data => {
            if (data.status === 'success') {
                currentUser = data.user;
                localStorage.setItem('user', JSON.stringify(currentUser));

                // Verify role
                if (currentUser.role !== 'instructor' && currentUser.role !== 'admin') {
                    window.location.href = '/student_dashboard.html';
                    return;
                }

                const userGreeting = document.getElementById('userGreeting');
                if (userGreeting) userGreeting.textContent = `Welcome, ${currentUser.username}!`;
                return;
            }
            throw new Error('no-session');
        })
        .catch(() => {
            // Fallback to localStorage
            const user = localStorage.getItem('user');
            const sessionId = localStorage.getItem('session_id');

            if (!user || !sessionId) {
                window.location.href = '/';
                return;
            }

            currentUser = JSON.parse(user);
            currentSession = sessionId;

            if (currentUser.role !== 'instructor' && currentUser.role !== 'admin') {
                window.location.href = '/student_dashboard.html';
                return;
            }

            const userGreeting = document.getElementById('userGreeting');
            if (userGreeting) userGreeting.textContent = `Welcome, ${currentUser.username}!`;
        });
}

// ================================
// Initialize Dashboard
// ================================
function initializeDashboard() {
    loadDashboardStats();
    loadMyCourses();
}

async function loadDashboardStats() {
    try {
        const response = await fetch('/api/courses', { credentials: 'same-origin' });
        const data = await response.json();

        if (data.status === 'success') {
            const courses = data.courses.filter(c => c.instructor_id === currentUser.id);
            const enrollmentCount = courses.reduce((sum, c) => sum + (c.enrollment_count || 0), 0);

            updateStats(courses.length, enrollmentCount);
        }
    } catch (error) {
        console.error('Error loading stats:', error);
    }
}

function updateStats(courseCount, studentCount) {
    const statsContainer = document.getElementById('statsContainer');
    statsContainer.innerHTML = `
        <div class="stat-card">
            <div class="stat-value">${courseCount}</div>
            <div class="stat-label">Courses Created</div>
        </div>
        <div class="stat-card">
            <div class="stat-value">${studentCount}</div>
            <div class="stat-label">Total Students</div>
        </div>
        <div class="stat-card">
            <div class="stat-value">${studentCount}</div>
            <div class="stat-label">Total Enrollments</div>
        </div>
        <div class="stat-card">
            <div class="stat-value">${courseCount}</div>
            <div class="stat-label">Active Courses</div>
        </div>
    `;
}

// ================================
// Event Listeners Setup
// ================================
function setupEventListeners() {
    const createCourseForm = document.getElementById('createCourseForm');
    if (createCourseForm) {
        createCourseForm.addEventListener('submit', handleCreateCourse);
    }

    const profileForm = document.getElementById('profileForm');
    if (profileForm) {
        profileForm.addEventListener('submit', handleProfileUpdate);
    }
}

// ================================
// Modal Functions
// ================================
function openCreateCourseModal() {
    document.getElementById('createCourseModal').classList.add('active');
}

function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('active');
}

// ================================
// Course Management
// ================================
async function handleCreateCourse(e) {
    e.preventDefault();

    const title = document.getElementById('courseTitle').value;
    const description = document.getElementById('courseDescription').value;
    const category = document.getElementById('courseCategory').value;
    const price = parseFloat(document.getElementById('coursePrice').value);

    try {
        // collect lessons from textarea (one URL per line)
        const lessonsRaw = document.getElementById('courseLessons').value || '';
        const lessons = lessonsRaw.split('\n').map(s => s.trim()).filter(Boolean).map((url, idx) => ({
            title: `Lesson ${idx + 1}`,
            video_url: url
        }));

        const response = await fetch('/api/create-course', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            credentials: 'same-origin',
            body: JSON.stringify({
                title,
                description,
                category,
                price
                , lessons
            })
        });

        const data = await response.json();

        if (data.status === 'success') {
            showAlert('Course created successfully!', 'success');
            closeModal('createCourseModal');
            document.getElementById('createCourseForm').reset();
            setTimeout(() => {
                loadMyCourses();
                loadDashboardStats();
            }, 1000);
        } else {
            showAlert(data.message || 'Failed to create course', 'error');
        }
    } catch (error) {
        showAlert('Connection error', 'error');
        console.error('Create course error:', error);
    }
}

async function loadMyCourses() {
    showSection('myCoursesSection');

    try {
        const response = await fetch('/api/courses', { credentials: 'same-origin' });
        const data = await response.json();

        if (data.status === 'success') {
            const myCourses = data.courses.filter(c => c.instructor_id === currentUser.id);
            const container = document.getElementById('allCoursesContainer');

            if (myCourses.length === 0) {
                container.innerHTML = `
                    <div style="grid-column: 1 / -1; text-align: center; padding: 40px; color: var(--gray);">
                        <p><i class="fas fa-inbox"></i> No courses created yet.</p>
                        <button class="nav-button" onclick="openCreateCourseModal()" style="margin-top: 20px;">Create Your First Course</button>
                    </div>
                `;
            } else {
                container.innerHTML = myCourses.map(course => `
                    <div class="course-card">
                        <div class="course-header">
                            📚
                        </div>
                        <div class="course-body">
                            <span class="course-category">${course.category}</span>
                            <h3 class="course-title">${course.title}</h3>
                            <p class="course-description">${course.description}</p>
                            <div style="margin-top: 15px; padding-top: 15px; border-top: 1px solid var(--border);">
                                <small style="color: var(--gray);">
                                    <i class="fas fa-users"></i> Students enrolled | 
                                    <i class="fas fa-dollar-sign"></i> $${course.price || '0'}
                                </small>
                            </div>
                            <button class="enroll-btn" style="width: 100%; margin-top: 15px;" onclick="editCourse(${course.id})">
                                Edit Course
                            </button>
                        </div>
                    </div>
                `).join('');
            }

            // Also update dashboard view
            const dashboardContainer = document.getElementById('myCoursesContainer');
            if (dashboardContainer && myCourses.length > 0) {
                dashboardContainer.innerHTML = myCourses.slice(0, 3).map(course => `
                    <div class="course-card">
                        <div class="course-header">
                            📚
                        </div>
                        <div class="course-body">
                            <span class="course-category">${course.category}</span>
                            <h3 class="course-title">${course.title}</h3>
                            <p class="course-description">${course.description}</p>
                        </div>
                    </div>
                `).join('');
            }
        }
    } catch (error) {
        console.error('Error loading courses:', error);
    }
}

function editCourse(courseId) {
    // TODO: Implement course editing
    showAlert('Course editing coming soon!', 'info');
}

// ================================
// Analytics Section
// ================================
async function loadAnalytics() {
    showSection('analyticsSection');
    const section = document.getElementById('analyticsSection');

    try {
        const response = await fetch('/api/courses', { credentials: 'same-origin' });
        const data = await response.json();

        if (data.status === 'success') {
            const myCourses = data.courses.filter(c => c.instructor_id === currentUser.id);

            if (myCourses.length === 0) {
                section.innerHTML = `
                    <div class="card">
                        <div class="card-body" style="text-align: center; padding: 40px; color: var(--gray);">
                            <p>Create courses to see analytics data.</p>
                        </div>
                    </div>
                `;
            } else {
                let html = `
                    <div class="card">
                        <div class="card-header">
                            <h3>Course Performance</h3>
                        </div>
                        <div class="card-body">
                            <table style="width: 100%;">
                                <thead>
                                    <tr style="border-bottom: 2px solid var(--border);">
                                        <th style="text-align: left; padding: 10px 0;">Course</th>
                                        <th style="text-align: right; padding: 10px 0;">Students</th>
                                        <th style="text-align: right; padding: 10px 0;">Revenue</th>
                                    </tr>
                                </thead>
                                <tbody>
                `;

                myCourses.forEach(course => {
                    const studentCount = course.student_count || 0;
                    const revenue = (studentCount * (course.price || 0)).toFixed(2);

                    html += `
                        <tr style="border-bottom: 1px solid var(--border);">
                            <td style="padding: 12px 0;">${course.title}</td>
                            <td style="text-align: right; padding: 12px 0;">${studentCount}</td>
                            <td style="text-align: right; padding: 12px 0;">$${revenue}</td>
                        </tr>
                    `;
                });

                html += '</tbody></table></div></div>';
                section.innerHTML = html;
            }
        }
    } catch (error) {
        console.error('Error loading analytics:', error);
    }
}

// ================================
// Students Section
// ================================
async function loadStudents() {
    showSection('studentsSection');
    
    try {
        const response = await fetch('/api/courses', { credentials: 'same-origin' });
        const data = await response.json();

        if (data.status === 'success') {
            const myCourses = data.courses.filter(c => c.instructor_id === currentUser.id);
            
            let html = `
                <div class="card">
                    <div class="card-header">
                        <h3>Your Students (${myCourses.length > 0 ? 'Coming Soon' : '0'})</h3>
                    </div>
                    <div class="card-body">
                        <table style="width: 100%;">
                            <thead>
                                <tr style="border-bottom: 2px solid var(--border);">
                                    <th style="text-align: left; padding: 10px 0;">Name</th>
                                    <th style="text-align: left; padding: 10px 0;">Courses</th>
                                    <th style="text-align: left; padding: 10px 0;">Progress</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="3" style="text-align: center; padding: 20px; color: var(--gray);">
                                        Student list will appear as they enroll in your courses
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            `;

            document.getElementById('studentsSection').innerHTML = html;
        }
    } catch (error) {
        console.error('Error loading students:', error);
    }
}

// ================================
// Profile Section
// ================================
function loadProfile() {
    showSection('profileSection');
    
    document.getElementById('profileUsername').value = currentUser.username;
    document.getElementById('profileEmail').value = currentUser.email || '';
    document.getElementById('profileBio').value = currentUser.bio || '';
}

async function handleProfileUpdate(e) {
    e.preventDefault();

    const email = document.getElementById('profileEmail').value;
    const bio = document.getElementById('profileBio').value;

    try {
        const response = await fetch('/api/update-profile', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            credentials: 'same-origin',
            body: JSON.stringify({ email, bio })
        });

        const data = await response.json();

        if (data.status === 'success') {
            currentUser.email = email;
            currentUser.bio = bio;
            localStorage.setItem('user', JSON.stringify(currentUser));
            showAlert('Profile updated successfully!', 'success');
        } else {
            showAlert(data.message || 'Failed to update profile', 'error');
        }
    } catch (error) {
        showAlert('Connection error', 'error');
        console.error('Update error:', error);
    }
}

// ================================
// Section Navigation
// ================================
function showSection(sectionId) {
    document.querySelectorAll('.dashboard-section').forEach(section => {
        section.style.display = 'none';
    });

    const section = document.getElementById(sectionId);
    if (section) {
        section.style.display = 'block';
    }

    if (event && event.target) {
        document.querySelectorAll('.sidebar-link').forEach(link => {
            link.classList.remove('active');
        });
        const link = event.target.closest('.sidebar-link');
        if (link) {
            link.classList.add('active');
        }
    }
}

// ================================
// Utility Functions
// ================================
function showAlert(message, type = 'info') {
    const alertContainer = document.getElementById('alertContainer');
    const alertId = 'alert-' + Date.now();

    const alertHTML = `
        <div id="${alertId}" class="alert alert-${type}" style="animation: slideIn 0.3s ease;">
            <strong>${type.charAt(0).toUpperCase() + type.slice(1)}!</strong> ${message}
        </div>
    `;

    alertContainer.insertAdjacentHTML('beforeend', alertHTML);

    setTimeout(() => {
        const alert = document.getElementById(alertId);
        if (alert) {
            alert.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => alert.remove(), 300);
        }
    }, 4000);
}

function logout() {
    fetch('/api/logout', { method: 'POST', credentials: 'same-origin' }).catch(() => {});
    localStorage.removeItem('session_id');
    localStorage.removeItem('user');
    window.location.href = '/';
}
