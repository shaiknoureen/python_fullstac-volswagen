// ================================
// Global State Management
// ================================
let currentUser = null;
let currentSession = null;

// ================================
// Initialize on Page Load
// ================================
document.addEventListener('DOMContentLoaded', () => {
    loadCourses();
    setupEventListeners();
    checkUserSession();
});

// ================================
// Event Listeners
// ================================
function setupEventListeners() {
    // Navigation buttons
    document.getElementById('loginBtn').addEventListener('click', () => {
        openModal('loginModal');
    });

    document.getElementById('signupBtn').addEventListener('click', () => {
        openModal('signupModal');
    });

    document.getElementById('exploreBtn').addEventListener('click', () => {
        document.getElementById('courses').scrollIntoView({ behavior: 'smooth' });
    });

    document.getElementById('ctaSignupBtn').addEventListener('click', () => {
        openModal('signupModal');
    });

    // Form submissions
    document.getElementById('loginForm').addEventListener('submit', handleLogin);
    document.getElementById('signupForm').addEventListener('submit', handleSignup);

    // Close modals on outside click
    document.addEventListener('click', (e) => {
        if (e.target.classList.contains('modal')) {
            e.target.classList.remove('active');
        }
    });
}

// ================================
// Modal Functions
// ================================
function openModal(modalId) {
    document.getElementById(modalId).classList.add('active');
}

function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('active');
}

function switchModal(fromModal, toModal) {
    closeModal(fromModal);
    setTimeout(() => openModal(toModal), 300);
}

// ================================
// Courses Loading
// ================================
async function loadCourses() {
    try {
        const response = await fetch('/api/courses');
        const data = await response.json();

        if (data.status === 'success') {
            const coursesContainer = document.getElementById('coursesContainer');
            
            // Sample courses if none exist
            const courses = data.courses.length > 0 ? data.courses : getSampleCourses();
            
            coursesContainer.innerHTML = courses.map(course => `
                <div class="course-card" onclick="viewCourse(${course.id || 1})">
                    <div class="course-header">
                        ${getRandomIcon()}
                    </div>
                    <div class="course-body">
                        <span class="course-category">${course.category || 'Technology'}</span>
                        <h3 class="course-title">${course.title || 'Course Title'}</h3>
                        <p class="course-instructor">by ${course.instructor_name || 'Expert Instructor'}</p>
                        <p class="course-description">${course.description || 'Learn amazing skills in this comprehensive course'}</p>
                        <div class="course-footer">
                            <span class="course-price">$${course.price || '0'}</span>
                            <button class="enroll-btn" onclick="enrollCourse(event, ${course.id || 1})">
                                ${currentUser ? 'Enroll' : 'View'}
                            </button>
                        </div>
                    </div>
                </div>
            `).join('');
        }
    } catch (error) {
        console.error('Error loading courses:', error);
        loadSampleCourses();
    }
}

function getSampleCourses() {
    return [
        {
            id: 1,
            title: "Complete Web Development Bootcamp",
            description: "Master HTML, CSS, JavaScript, and modern frameworks",
            category: "Web Development",
            instructor_name: "John Smith",
            price: 99.99
        },
        {
            id: 2,
            title: "Python for Data Science",
            description: "Learn data analysis, visualization, and machine learning",
            category: "Data Science",
            instructor_name: "Sarah Johnson",
            price: 89.99
        },
        {
            id: 3,
            title: "UI/UX Design Fundamentals",
            description: "Create stunning user experiences with modern design principles",
            category: "Design",
            instructor_name: "Emma Davis",
            price: 79.99
        },
        {
            id: 4,
            title: "Mobile App Development with React Native",
            description: "Build cross-platform mobile apps like a pro",
            category: "Mobile Development",
            instructor_name: "Michael Chen",
            price: 109.99
        },
        {
            id: 5,
            title: "Cloud Computing with AWS",
            description: "Deploy and scale applications on Amazon Web Services",
            category: "Cloud",
            instructor_name: "Alex Rodriguez",
            price: 119.99
        },
        {
            id: 6,
            title: "Digital Marketing Mastery",
            description: "Learn SEO, content marketing, and social media strategies",
            category: "Marketing",
            instructor_name: "Lisa Wang",
            price: 69.99
        }
    ];
}

function loadSampleCourses() {
    const coursesContainer = document.getElementById('coursesContainer');
    coursesContainer.innerHTML = getSampleCourses().map(course => `
        <div class="course-card" onclick="viewCourse(${course.id})">
            <div class="course-header">
                ${getRandomIcon()}
            </div>
            <div class="course-body">
                <span class="course-category">${course.category}</span>
                <h3 class="course-title">${course.title}</h3>
                <p class="course-instructor">by ${course.instructor_name}</p>
                <p class="course-description">${course.description}</p>
                <div class="course-footer">
                    <span class="course-price">$${course.price}</span>
                    <button class="enroll-btn" onclick="enrollCourse(event, ${course.id})">
                        ${currentUser ? 'Enroll' : 'View'}
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

function getRandomIcon() {
    const icons = ['📚', '💻', '🎨', '📊', '🚀', '🔬', '📱', '🎬'];
    return icons[Math.floor(Math.random() * icons.length)];
}

// ================================
// Authentication Functions
// ================================
async function handleLogin(e) {
    e.preventDefault();

    const username = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;

    try {
        const response = await fetch('/api/login', {
            method: 'POST',
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        });

        const data = await response.json();

        if (data.status === 'success') {
            currentUser = data.user;
            currentSession = data.session_id;
            localStorage.setItem('session_id', data.session_id);
            localStorage.setItem('user', JSON.stringify(data.user));
            
            showAlert('Login successful! Redirecting...', 'success');
            setTimeout(() => {
                window.location.href = '/dashboard.html';
            }, 1500);
        } else {
            showAlert(data.message || 'Login failed', 'error');
        }
    } catch (error) {
        showAlert('Connection error', 'error');
        console.error('Login error:', error);
    }

    document.getElementById('loginForm').reset();
}

async function handleSignup(e) {
    e.preventDefault();

    const username = document.getElementById('signupUsername').value;
    const email = document.getElementById('signupEmail').value;
    const password = document.getElementById('signupPassword').value;
    const role = document.getElementById('signupRole').value;

    try {
        const response = await fetch('/api/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, email, password, role })
        });

        const data = await response.json();

        if (data.status === 'success') {
            showAlert('Account created successfully! Please login.', 'success');
            closeModal('signupModal');
            document.getElementById('signupForm').reset();
            setTimeout(() => {
                openModal('loginModal');
            }, 500);
        } else {
            showAlert(data.message || 'Signup failed', 'error');
        }
    } catch (error) {
        showAlert('Connection error', 'error');
        console.error('Signup error:', error);
    }
}

async function checkUserSession() {
    // Prefer server-side session (cookie). If server returns a user, persist locally.
    try {
        const res = await fetch('/api/user', { credentials: 'same-origin' });
        if (res.ok) {
            const data = await res.json();
            if (data.status === 'success') {
                currentUser = data.user;
                currentSession = localStorage.getItem('session_id') || '';
                localStorage.setItem('user', JSON.stringify(currentUser));
                updateNavForLoggedIn();
                return;
            }
        }
    } catch (e) {
        // ignore and fallback to localStorage
    }

    const sessionId = localStorage.getItem('session_id');
    const userData = localStorage.getItem('user');

    if (sessionId && userData) {
        currentUser = JSON.parse(userData);
        currentSession = sessionId;
        updateNavForLoggedIn();
    }
}

function updateNavForLoggedIn() {
    if (currentUser) {
        document.getElementById('loginBtn').textContent = 'Dashboard';
        document.getElementById('loginBtn').onclick = () => {
            window.location.href = '/dashboard.html';
        };
        document.getElementById('signupBtn').textContent = 'Logout';
        document.getElementById('signupBtn').onclick = logout;
    }
}

function logout() {
    // Call server to destroy session (clears HttpOnly cookie), then clear local state
    fetch('/api/logout', { method: 'POST', credentials: 'same-origin' }).catch(() => {});
    localStorage.removeItem('session_id');
    localStorage.removeItem('user');
    currentUser = null;
    currentSession = null;
    window.location.href = '/';
}

// ================================
// Course Functions
// ================================
function viewCourse(courseId) {
    if (currentUser) {
        window.location.href = `/course-detail.html?id=${courseId}`;
    } else {
        showAlert('Please login to view course details', 'info');
        openModal('loginModal');
    }
}

async function enrollCourse(event, courseId) {
    event.stopPropagation();

    if (!currentUser) {
        showAlert('Please login to enroll', 'info');
        openModal('loginModal');
        return;
    }

    try {
        const response = await fetch('/api/enroll-course', {
            method: 'POST',
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ course_id: courseId })
        });

        const data = await response.json();

        if (data.status === 'success') {
            showAlert('Enrolled successfully!', 'success');
            setTimeout(() => {
                window.location.href = '/student_dashboard.html';
            }, 1500);
        } else {
            showAlert(data.message || 'Enrollment failed', 'error');
        }
    } catch (error) {
        showAlert('Connection error', 'error');
        console.error('Enrollment error:', error);
    }
}

// ================================
// Utility Functions
// ================================
function showAlert(message, type = 'info') {
    const alertContainer = document.getElementById('alertContainer');
    const alertId = 'alert-' + Date.now();

    const alertHTML = `
        <div id="${alertId}" class="alert alert-${type}" style="animation: slideIn 0.3s ease;">
            <strong>${type.charAt(0).toUpperCase() + type.slice(1)}!</strong> ${message}
        </div>
    `;

    alertContainer.insertAdjacentHTML('beforeend', alertHTML);

    setTimeout(() => {
        const alert = document.getElementById(alertId);
        if (alert) {
            alert.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => alert.remove(), 300);
        }
    }, 4000);
}

// ================================
// Animations
// ================================
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }

    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);
