// ================================
// Dashboard Initialization
// ================================
document.addEventListener('DOMContentLoaded', () => {
    checkAuth();
    initializeDashboard();
    setupProfileForm();
});

// ================================
// Authentication Check
// ================================
function checkAuth() {
    // Try server-side session first (works with HttpOnly cookie)
    fetch('/api/user', { credentials: 'same-origin' })
        .then(res => {
            if (!res.ok) throw new Error('no-server-session');
            return res.json();
        })
        .then(data => {
            if (data.status === 'success') {
                currentUser = data.user;
                // persist user locally for UI usage
                localStorage.setItem('user', JSON.stringify(currentUser));

                // Update UI
                const userGreeting = document.getElementById('userGreeting');
                userGreeting.textContent = `Welcome, ${currentUser.username}!`;

                const lastLogin = document.getElementById('lastLogin');
                lastLogin.textContent = `Last login: Today at ${new Date().toLocaleTimeString()}`;
                return;
            }
            throw new Error('no-session');
        })
        .catch(() => {
            // fallback to localStorage-based session
            const user = localStorage.getItem('user');
            const sessionId = localStorage.getItem('session_id');

            if (!user || !sessionId) {
                window.location.href = '/';
                return;
            }

            currentUser = JSON.parse(user);
            currentSession = sessionId;

            const userGreeting = document.getElementById('userGreeting');
            userGreeting.textContent = `Welcome, ${currentUser.username}!`;

            const lastLogin = document.getElementById('lastLogin');
            lastLogin.textContent = `Last login: Today at ${new Date().toLocaleTimeString()}`;
        });
}

// ================================
// Dashboard Initialization
// ================================
function initializeDashboard() {
    loadDashboardStats();
    loadMyCourses();
}

async function loadDashboardStats() {
    try {
        const response = await fetch('/api/my-courses', { credentials: 'same-origin' });
        const data = await response.json();

        if (data.status === 'success') {
            const courses = data.courses;
            const enrolledCount = courses.length;
            const avgProgress = courses.length > 0 
                ? Math.round(courses.reduce((sum, c) => sum + (c.progress || 0), 0) / courses.length) 
                : 0;

            updateStats(enrolledCount, avgProgress);
        }
    } catch (error) {
        console.error('Error loading stats:', error);
    }
}

function updateStats(enrolledCount, avgProgress) {
    const statsContainer = document.getElementById('statsContainer');
    statsContainer.innerHTML = `
        <div class="stat-card">
            <div class="stat-value">${enrolledCount}</div>
            <div class="stat-label">Courses Enrolled</div>
        </div>
        <div class="stat-card">
            <div class="stat-value">${avgProgress}%</div>
            <div class="stat-label">Average Progress</div>
        </div>
        <div class="stat-card">
            <div class="stat-value">0</div>
            <div class="stat-label">Certificates</div>
        </div>
        <div class="stat-card">
            <div class="stat-value">0h</div>
            <div class="stat-label">Hours Learned</div>
        </div>
    `;
}

// ================================
// Section Navigation
// ================================
function showSection(sectionId) {
    // Hide all sections
    document.querySelectorAll('.dashboard-section').forEach(section => {
        section.style.display = 'none';
    });

    // Show selected section
    const section = document.getElementById(sectionId);
    if (section) {
        section.style.display = 'block';
    }

    // Update sidebar active state
    document.querySelectorAll('.sidebar-link').forEach(link => {
        link.classList.remove('active');
    });
    event.target.closest('.sidebar-link').classList.add('active');
}

// ================================
// My Courses Section
// ================================
async function loadMyCourses() {
    showSection('myCoursesSection');

    try {
        const response = await fetch('/api/my-courses', { credentials: 'same-origin' });
        const data = await response.json();

        if (data.status === 'success') {
            const courses = data.courses;
            const container = document.getElementById('myCoursesContainer');

            if (courses.length === 0) {
                container.innerHTML = `
                    <div style="grid-column: 1 / -1; text-align: center; padding: 40px; color: var(--gray);">
                        <p><i class="fas fa-inbox"></i> You haven't enrolled in any courses yet.</p>
                        <a href="/" class="nav-button" style="display: inline-block; margin-top: 20px;">Browse Courses</a>
                    </div>
                `;
            } else {
                container.innerHTML = courses.map(course => `
                    <div class="course-card" onclick="viewCourseDetail(${course.id})">
                        <div class="course-header">
                            🎓
                        </div>
                        <div class="course-body">
                            <span class="course-category">${course.category || 'Technology'}</span>
                            <h3 class="course-title">${course.title}</h3>
                            <p class="course-description">${course.description || 'Course content'}</p>
                            <div style="margin-top: 15px;">
                                <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                                    <span style="font-size: 12px; color: var(--gray);">Progress</span>
                                    <span style="font-size: 12px; font-weight: 600;">${course.progress || 0}%</span>
                                </div>
                                <div style="background: var(--border); border-radius: 8px; height: 8px; overflow: hidden;">
                                    <div style="background: var(--primary); height: 100%; width: ${course.progress || 0}%;"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                `).join('');
            }
        }
    } catch (error) {
        console.error('Error loading courses:', error);
    }
}

function viewCourseDetail(courseId) {
    window.location.href = `/course-detail.html?id=${courseId}`;
}

// ================================
// Progress Section
// ================================
function loadProgress() {
    showSection('progressSection');
    const section = document.getElementById('progressSection');

    section.innerHTML = `
        <div class="card">
            <div class="card-header">
                <h3>Your Learning Progress</h3>
            </div>
            <div class="card-body" id="progressContent">
                <p style="color: var(--gray); text-align: center;">Loading progress data...</p>
            </div>
        </div>
    `;

    // Load progress data
    loadProgressData();
}

async function loadProgressData() {
    try {
        const response = await fetch('/api/my-courses', { credentials: 'same-origin' });
        const data = await response.json();

        if (data.status === 'success' && data.courses.length > 0) {
            const courses = data.courses;
            const progressContent = document.getElementById('progressContent');

            const totalProgress = Math.round(
                courses.reduce((sum, c) => sum + (c.progress || 0), 0) / courses.length
            );

            let html = `
                <div style="margin-bottom: 30px;">
                    <h4>Overall Progress</h4>
                    <div style="margin-top: 15px;">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                            <span>${totalProgress}%</span>
                        </div>
                        <div style="background: var(--border); border-radius: 8px; height: 20px; overflow: hidden;">
                            <div style="background: linear-gradient(90deg, var(--primary), var(--secondary)); height: 100%; width: ${totalProgress}%;"></div>
                        </div>
                    </div>
                </div>

                <h4>Per Course Progress</h4>
                <table style="width: 100%; margin-top: 15px;">
                    <thead>
                        <tr style="border-bottom: 2px solid var(--border);">
                            <th style="text-align: left; padding: 10px 0;">Course</th>
                            <th style="text-align: right; padding: 10px 0;">Progress</th>
                        </tr>
                    </thead>
                    <tbody>
            `;

            courses.forEach(course => {
                html += `
                    <tr style="border-bottom: 1px solid var(--border);">
                        <td style="padding: 12px 0;">${course.title}</td>
                        <td style="text-align: right; padding: 12px 0;">
                            <span style="color: var(--primary); font-weight: 600;">${course.progress || 0}%</span>
                        </td>
                    </tr>
                `;
            });

            html += '</tbody></table>';
            progressContent.innerHTML = html;
        } else {
            document.getElementById('progressContent').innerHTML = 
                '<p style="color: var(--gray); text-align: center;">No progress data available yet. Enroll in a course to start learning!</p>';
        }
    } catch (error) {
        console.error('Error loading progress:', error);
    }
}

// ================================
// Certificates Section
// ================================
function loadCertificates() {
    showSection('certificatesSection');
    const section = document.getElementById('certificatesSection');

    section.innerHTML = `
        <div class="card">
            <div class="card-header">
                <h3>Your Certificates</h3>
            </div>
            <div class="card-body">
                <div style="text-align: center; padding: 40px; color: var(--gray);">
                    <i class="fas fa-certificate" style="font-size: 60px; margin-bottom: 20px; color: var(--warning);"></i>
                    <p>Complete courses to earn certificates!</p>
                    <p style="font-size: 14px; margin-top: 10px;">Certificates showcase your achievements and skills to employers.</p>
                </div>
            </div>
        </div>
    `;
}

// ================================
// Profile Section
// ================================
function loadProfile() {
    showSection('profileSection');
    
    // Load user data into form
    document.getElementById('profileUsername').value = currentUser.username;
    document.getElementById('profileEmail').value = currentUser.email || '';
    document.getElementById('profileBio').value = currentUser.bio || '';
}

function setupProfileForm() {
    const form = document.getElementById('profileForm');
    if (form) {
        form.addEventListener('submit', handleProfileUpdate);
    }
}

async function handleProfileUpdate(e) {
    e.preventDefault();

    const email = document.getElementById('profileEmail').value;
    const bio = document.getElementById('profileBio').value;

    try {
        const response = await fetch('/api/update-profile', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            credentials: 'same-origin',
            body: JSON.stringify({ email, bio })
        });

        const data = await response.json();

        if (data.status === 'success') {
            currentUser.email = email;
            currentUser.bio = bio;
            localStorage.setItem('user', JSON.stringify(currentUser));
            showAlert('Profile updated successfully!', 'success');
        } else {
            showAlert(data.message || 'Failed to update profile', 'error');
        }
    } catch (error) {
        showAlert('Connection error', 'error');
        console.error('Update error:', error);
    }
}

// ================================
// Utility Functions
// ================================
function showAlert(message, type = 'info') {
    const alertContainer = document.getElementById('alertContainer');
    const alertId = 'alert-' + Date.now();

    const alertHTML = `
        <div id="${alertId}" class="alert alert-${type}" style="animation: slideIn 0.3s ease;">
            <strong>${type.charAt(0).toUpperCase() + type.slice(1)}!</strong> ${message}
        </div>
    `;

    alertContainer.insertAdjacentHTML('beforeend', alertHTML);

    setTimeout(() => {
        const alert = document.getElementById(alertId);
        if (alert) {
            alert.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => alert.remove(), 300);
        }
    }, 4000);
}

function logout() {
    // Destroy server session then clear local storage and redirect
    fetch('/api/logout', { method: 'POST', credentials: 'same-origin' }).catch(() => {});
    localStorage.removeItem('session_id');
    localStorage.removeItem('user');
    window.location.href = '/';
}
