// ================================
// Course Detail Page
// ================================
let courseId = null;
let courseData = null;

document.addEventListener('DOMContentLoaded', () => {
    getQueryParam();
    loadCourseDetails();
    checkUserStatus();
});

// ================================
// Get Course ID from URL
// ================================
function getQueryParam() {
    const urlParams = new URLSearchParams(window.location.search);
    courseId = urlParams.get('id');

    if (!courseId) {
        window.location.href = '/';
    }
}

// ================================
// Load Course Details
// ================================
async function loadCourseDetails() {
    try {
        const response = await fetch(`/api/course-detail?id=${encodeURIComponent(courseId)}`, { credentials: 'same-origin' });
        const data = await response.json();

        if (data.status === 'success') {
            courseData = data.course;
            courseData.lessons = data.lessons || [];
            displayCourseDetails(courseData);
            return;
        }
        throw new Error('Course not found');
    } catch (error) {
        console.error('Error loading course detail:', error);
        // Fallback to previous behaviour
        try {
            const response = await fetch('/api/courses');
            const data = await response.json();
            if (data.status === 'success') {
                let course = data.courses.find(c => c.id === parseInt(courseId));
                if (!course) course = getSampleCourse(parseInt(courseId));
                courseData = course;
                displayCourseDetails(course);
                return;
            }
        } catch (e) {}
        courseData = getSampleCourse(parseInt(courseId));
        displayCourseDetails(courseData);
    }
}

function getSampleCourse(id) {
    const courses = [
        {
            id: 1,
            title: "Complete Web Development Bootcamp",
            description: "Master HTML, CSS, JavaScript, and modern frameworks like React. Build real-world projects and launch your web development career.",
            category: "Web Development",
            instructor_name: "John Smith",
            price: 99.99,
            level: "Beginner",
            duration_hours: 40,
            lessons_count: 14,
            students_count: 5240
        },
        {
            id: 2,
            title: "Python for Data Science",
            description: "Learn data analysis, visualization, and machine learning with Python. Perfect for aspiring data scientists.",
            category: "Data Science",
            instructor_name: "Sarah Johnson",
            price: 89.99,
            level: "Intermediate",
            duration_hours: 35,
            lessons_count: 12,
            students_count: 3120
        },
        {
            id: 3,
            title: "UI/UX Design Fundamentals",
            description: "Create stunning user experiences with modern design principles. Learn tools like Figma and Adobe XD.",
            category: "Design",
            instructor_name: "Emma Davis",
            price: 79.99,
            level: "Beginner",
            duration_hours: 30,
            lessons_count: 10,
            students_count: 2890
        },
        {
            id: 4,
            title: "Mobile App Development with React Native",
            description: "Build cross-platform mobile apps for iOS and Android using React Native and modern JavaScript.",
            category: "Mobile Development",
            instructor_name: "Michael Chen",
            price: 109.99,
            level: "Advanced",
            duration_hours: 45,
            lessons_count: 16,
            students_count: 1950
        },
        {
            id: 5,
            title: "Cloud Computing with AWS",
            description: "Deploy and scale applications on Amazon Web Services. Learn EC2, S3, Lambda, and more.",
            category: "Cloud",
            instructor_name: "Alex Rodriguez",
            price: 119.99,
            level: "Intermediate",
            duration_hours: 50,
            lessons_count: 18,
            students_count: 1640
        },
        {
            id: 6,
            title: "Digital Marketing Mastery",
            description: "Learn SEO, SEM, content marketing, and social media strategies. Grow your online presence effectively.",
            category: "Marketing",
            instructor_name: "Lisa Wang",
            price: 69.99,
            level: "Beginner",
            duration_hours: 25,
            lessons_count: 8,
            students_count: 4320
        }
    ];

    return courses.find(c => c.id === id) || courses[0];
}

// ================================
// Display Course Details
// ================================
function displayCourseDetails(course) {
    // Header section
    document.getElementById('courseTitle').textContent = course.title;
    document.getElementById('courseDescription').textContent = course.description;
    document.getElementById('breadcrumb').textContent = course.category;
    document.getElementById('instructorName').textContent = course.instructor_name;
    document.getElementById('courseLevel').textContent = course.level;
    document.getElementById('courseDuration').textContent = `${course.duration_hours || 40}h Course`;
    document.getElementById('coursePrice').textContent = `$${course.price}`;
    document.getElementById('sidebarPrice').textContent = `$${course.price}`;
    document.getElementById('instructorNameDetail').textContent = course.instructor_name;

    // Curriculum
    displayCurriculum(course);
}

function displayCurriculum(course) {
    const lessons = course.lessons || generateLessons(course);
    const html = lessons.map((lesson, index) => {
        const watched = lesson.progress ? Math.round((lesson.progress.watched_seconds || 0)) : 0;
        const completed = lesson.progress ? lesson.progress.completed : false;
        const durationMinutes = lesson.duration_minutes || lesson.duration || 0;
        const durationText = durationMinutes ? `${durationMinutes} min` : '—';

        const videoEmbed = lesson.video_url ? `<div style="margin-bottom:12px;"><iframe width="100%" height="360" src="${formatYouTubeEmbed(lesson.video_url)}" frameborder="0" allowfullscreen></iframe></div>` : '';

        return `
        <div style="padding: 20px; border-bottom: 1px solid var(--border); transition: var(--transition);">
            <div style="display:flex; gap:16px; align-items:flex-start;">
                <div style="width:40px; height:40px; background:var(--primary); color:white; display:flex; align-items:center; justify-content:center; border-radius:50%; font-weight:700;">${index+1}</div>
                <div style="flex:1;">
                    <h4 style="margin:0 0 8px 0">${escapeHtml(lesson.title || ('Lesson ' + (index+1)))}</h4>
                    <p style="color:var(--gray); margin:0 0 12px 0">${durationText} • ${completed ? 'Completed' : `Watched: ${watched}s`}</p>
                    ${videoEmbed}
                    <div style="display:flex; gap:8px;">
                        <button class="nav-button" onclick="markLessonWatched(${lesson.id}, ${durationMinutes ? durationMinutes*60 : 0})">Mark as Watched</button>
                        <button class="nav-button" onclick="openInNewTab('${lesson.video_url || '#'}')">Open Video</button>
                    </div>
                </div>
            </div>
        </div>`;
    }).join('');

    document.getElementById('curriculumContent').innerHTML = html;
}

function formatYouTubeEmbed(url){
    if (!url) return '';
    // support youtu.be and youtube watch URLs
    try{
        const u = new URL(url);
        let id = '';
        if (u.hostname.includes('youtu.be')){
            id = u.pathname.slice(1);
        } else if (u.hostname.includes('youtube.com')){
            id = u.searchParams.get('v');
        }
        if (!id) return '';
        return `https://www.youtube.com/embed/${id}?rel=0`;
    }catch(e){ return '' }
}

function escapeHtml(s){
    if(!s) return '';
    return s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;');
}

function openInNewTab(url){ if(url && url !== '#') window.open(url, '_blank'); }

async function markLessonWatched(lessonId, seconds){
    if (!currentUser){ showAlert('Please login to track progress','info'); openModal('loginModal'); return; }
    try{
        const resp = await fetch('/api/lesson-progress', {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ lesson_id: lessonId, watched_seconds: seconds || 0, completed: true })
        });
        const data = await resp.json();
        if (data.status === 'success'){
            showAlert('Progress updated','success');
            // reload course details to update UI
            loadCourseDetails();
        } else {
            showAlert(data.message || 'Failed to update progress','error');
        }
    }catch(e){ console.error('Mark watched error', e); showAlert('Connection error','error'); }
}

function generateLessons(course) {
    const lessonTitles = [
        "Getting Started & Course Overview",
        "Fundamentals & Core Concepts",
        "Advanced Techniques",
        "Practical Application",
        "Building Your First Project",
        "Project Development Part 1",
        "Project Development Part 2",
        "Best Practices & Optimization",
        "Real-world Case Study",
        "Troubleshooting & Common Issues",
        "Advanced Topics",
        "Final Project Walkthrough",
        "Career Path & Next Steps",
        "Q&A & Community Discussion"
    ];

    return lessonTitles.slice(0, course.lessons_count || 14).map((title, index) => ({
        title,
        duration: Math.floor(Math.random() * 45) + 15 // 15-60 minutes
    }));
}

// ================================
// Check User Status
// ================================
function checkUserStatus() {
    const user = localStorage.getItem('user');
    if (user) {
        currentUser = JSON.parse(user);
    }
}

// ================================
// Enroll in Course
// ================================
async function enrollNow() {
    if (!currentUser) {
        showAlert('Please login to enroll in this course', 'info');
        openModal('loginModal');
        return;
    }

    try {
        const response = await fetch('/api/enroll-course', {
            method: 'POST',
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                course_id: parseInt(courseId)
            })
        });

        const data = await response.json();

        if (data.status === 'success') {
            showAlert('Successfully enrolled! Redirecting to course...', 'success');
            setTimeout(() => {
                // Redirect to appropriate dashboard based on role
                if (currentUser.role === 'instructor' || currentUser.role === 'admin') {
                    window.location.href = '/instructor_dashboard.html';
                } else {
                    window.location.href = '/student_dashboard.html';
                }
            }, 2000);
        } else {
            showAlert(data.message || 'Enrollment failed. Please try again.', 'error');
        }
    } catch (error) {
        showAlert('Connection error. Please check your internet connection.', 'error');
        console.error('Enrollment error:', error);
    }
}

// ================================
// Utility Functions
// ================================
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('active');
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('active');
    }
}

function showAlert(message, type = 'info') {
    const alertContainer = document.getElementById('alertContainer');
    const alertId = 'alert-' + Date.now();

    const alertHTML = `
        <div id="${alertId}" class="alert alert-${type}" style="animation: slideIn 0.3s ease;">
            <strong>${type.charAt(0).toUpperCase() + type.slice(1)}!</strong> ${message}
        </div>
    `;

    alertContainer.insertAdjacentHTML('beforeend', alertHTML);

    setTimeout(() => {
        const alert = document.getElementById(alertId);
        if (alert) {
            alert.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => alert.remove(), 300);
        }
    }, 4000);
}

function logout() {
    fetch('/api/logout', { method: 'POST', credentials: 'same-origin' }).catch(() => {});
    localStorage.removeItem('session_id');
    localStorage.removeItem('user');
    window.location.href = '/';
}
