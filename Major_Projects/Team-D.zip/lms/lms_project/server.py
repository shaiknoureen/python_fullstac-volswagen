import http.server
import socketserver
import json
import os
import mimetypes
import sqlite3
import uuid
from urllib.parse import urlparse, parse_qs
from database import get_db_connection, init_db
from session_manager import create_session, get_session, destroy_session, SESSION_COOKIE_NAME

PORT = 8000
PUBLIC_DIR = os.path.join(os.path.dirname(__file__), '..', 'templates')

class LMSHandler(http.server.BaseHTTPRequestHandler):
    def _set_headers(self, status=200, content_type='text/html'):
        self.send_response(status)
        self.send_header('Content-type', content_type)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def _set_json_headers(self, status=200):
        self.send_response(status)
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()

    def _get_cookie(self):
        if 'Cookie' in self.headers:
            cookies = self.headers['Cookie']
            for cookie in cookies.split(';'):
                if SESSION_COOKIE_NAME in cookie:
                    return cookie.split('=')[1].strip()
        return None

    def _get_user_from_session(self):
        session_id = self._get_cookie()
        if session_id:
            return get_session(session_id)
        return None

    def do_OPTIONS(self):
        self._set_headers()

    def do_GET(self):
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        
        # Server-side dashboard redirect (supports cookie-based sessions)
        if path in ['/dashboard', '/dashboard.html']:
            user = self._get_user_from_session()
            if not user:
                self.send_response(302)
                self.send_header('Location', '/')
                self.end_headers()
                return
            # Route by role
            role = user.get('role', 'student')
            if role in ['instructor', 'admin']:
                target = '/instructor_dashboard.html'
            else:
                target = '/student_dashboard.html'
            self.send_response(302)
            self.send_header('Location', target)
            self.end_headers()
            return

        # API Routes
        if path.startswith('/api/'):
            self.handle_api_get(path, parse_qs(parsed_path.query))
            return

        # Static File Serving
        if path == '/':
            path = '/index.html'
        
        file_path = os.path.join(PUBLIC_DIR, path.lstrip('/'))
        
        if os.path.exists(file_path) and os.path.isfile(file_path):
            mime_type, _ = mimetypes.guess_type(file_path)
            self._set_headers(content_type=mime_type or 'application/octet-stream')
            with open(file_path, 'rb') as f:
                self.wfile.write(f.read())
        else:
            self._set_headers(404)
            self.wfile.write(b"404 Not Found")

    def do_POST(self):
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        
        # Read request body
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length)
        
        try:
            data = json.loads(body.decode('utf-8'))
        except:
            data = {}

        if path == '/api/register':
            self.handle_register(data)
            return

        if path == '/api/login':
            self.handle_login(data)
            return

        if path == '/api/create-course':
            self.handle_create_course(data)
            return

        if path == '/api/lesson-progress':
            self.handle_lesson_progress(data)
            return

        if path == '/api/enroll-course':
            self.handle_enroll_course(data)
            return

        if path == '/api/update-profile':
            self.handle_update_profile(data)
            return

        if path == '/api/contact':
            self.handle_contact(data)
            return

        if path == '/api/logout':
            self.handle_logout()
            return

        self._set_json_headers(404)
        self.wfile.write(json.dumps({"status": "error", "message": "Endpoint not found"}).encode())

    def handle_register(self, data):
        username = data.get('username')
        password = data.get('password')
        email = data.get('email')
        role = data.get('role', 'student')

        if not username or not password or not email:
            self._set_json_headers(400)
            self.wfile.write(json.dumps({"status": "error", "message": "Missing required fields"}).encode())
            return

        conn = get_db_connection()
        c = conn.cursor()
        
        try:
            c.execute(
                "INSERT INTO users (username, password, email, role) VALUES (?, ?, ?, ?)",
                (username, password, email, role)
            )
            conn.commit()
            user_id = c.lastrowid
            self._set_json_headers(201)
            self.wfile.write(json.dumps({
                "status": "success",
                "message": "User registered successfully",
                "user_id": user_id
            }).encode())
        except sqlite3.IntegrityError:
            self._set_json_headers(400)
            self.wfile.write(json.dumps({"status": "error", "message": "Username or email already exists"}).encode())
        finally:
            conn.close()

    def handle_login(self, data):
        username = data.get('username')
        password = data.get('password')

        if not username or not password:
            self._set_json_headers(400)
            self.wfile.write(json.dumps({"status": "error", "message": "Missing credentials"}).encode())
            return

        conn = get_db_connection()
        c = conn.cursor()
        user = c.execute(
            "SELECT id, username, email, role FROM users WHERE username = ? AND password = ?",
            (username, password)
        ).fetchone()
        conn.close()
        
        if user:
            user_dict = dict(user)
            session_id = create_session(user_dict)
            # Respond with JSON and set an HttpOnly session cookie so server-side redirects work
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            # Set cookie for session (HttpOnly)
            self.send_header('Set-Cookie', f"{SESSION_COOKIE_NAME}={session_id}; Path=/; HttpOnly")
            self.end_headers()
            self.wfile.write(json.dumps({
                "status": "success",
                "message": "Login successful",
                "session_id": session_id,
                "user": user_dict
            }).encode())
        else:
            self._set_json_headers(401)
            self.wfile.write(json.dumps({"status": "error", "message": "Invalid credentials"}).encode())

    def handle_create_course(self, data):
        user = self._get_user_from_session()
        if not user or user.get('role') not in ['admin', 'instructor']:
            self._set_json_headers(401)
            self.wfile.write(json.dumps({"status": "error", "message": "Unauthorized"}).encode())
            return

        title = data.get('title')
        description = data.get('description')
        category = data.get('category', 'General')
        
        if not title:
            self._set_json_headers(400)
            self.wfile.write(json.dumps({"status": "error", "message": "Course title required"}).encode())
            return

        conn = get_db_connection()
        c = conn.cursor()
        try:
            c.execute(
                "INSERT INTO courses (title, description, category, instructor_id) VALUES (?, ?, ?, ?)",
                (title, description, category, user['id'])
            )
            conn.commit()
            course_id = c.lastrowid
            # If lessons array provided, insert lessons
            lessons = data.get('lessons') or []
            for idx, lesson in enumerate(lessons, start=1):
                ltitle = lesson.get('title') or f"Lesson {idx}"
                video_url = lesson.get('video_url')
                duration = lesson.get('duration_minutes') or None
                c.execute(
                    "INSERT INTO lessons (course_id, title, description, video_url, order_index, duration_minutes) VALUES (?, ?, ?, ?, ?, ?)",
                    (course_id, ltitle, lesson.get('description', ''), video_url, idx, duration)
                )
            conn.commit()
            self._set_json_headers(201)
            self.wfile.write(json.dumps({
                "status": "success",
                "message": "Course created successfully",
                "course_id": course_id
            }).encode())
        finally:
            conn.close()

    def handle_enroll_course(self, data):
        user = self._get_user_from_session()
        if not user:
            self._set_json_headers(401)
            self.wfile.write(json.dumps({"status": "error", "message": "Not logged in"}).encode())
            return

        course_id = data.get('course_id')
        if not course_id:
            self._set_json_headers(400)
            self.wfile.write(json.dumps({"status": "error", "message": "Course ID required"}).encode())
            return

        conn = get_db_connection()
        c = conn.cursor()
        try:
            c.execute(
                "INSERT INTO enrollments (user_id, course_id) VALUES (?, ?)",
                (user['id'], course_id)
            )
            conn.commit()
            self._set_json_headers(201)
            self.wfile.write(json.dumps({
                "status": "success",
                "message": "Enrolled successfully"
            }).encode())
        except sqlite3.IntegrityError:
            self._set_json_headers(400)
            self.wfile.write(json.dumps({"status": "error", "message": "Already enrolled"}).encode())
        finally:
            conn.close()

    def handle_update_profile(self, data):
        user = self._get_user_from_session()
        if not user:
            self._set_json_headers(401)
            self.wfile.write(json.dumps({"status": "error", "message": "Not logged in"}).encode())
            return

        conn = get_db_connection()
        c = conn.cursor()
        try:
            if 'email' in data:
                c.execute("UPDATE users SET email = ? WHERE id = ?", (data['email'], user['id']))
            if 'password' in data:
                c.execute("UPDATE users SET password = ? WHERE id = ?", (data['password'], user['id']))
            conn.commit()
            self._set_json_headers(200)
            self.wfile.write(json.dumps({
                "status": "success",
                "message": "Profile updated"
            }).encode())
        finally:
            conn.close()

    def handle_logout(self):
        # Destroy server-side session (if present) and clear cookie
        session_id = self._get_cookie()
        if session_id:
            destroy_session(session_id)

        # Send expired cookie to clear in browser
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Set-Cookie', f"{SESSION_COOKIE_NAME}=; Path=/; HttpOnly; Expires=Thu, 01 Jan 1970 00:00:00 GMT")
        self.end_headers()
        self.wfile.write(json.dumps({"status": "success", "message": "Logged out"}).encode())

    def handle_contact(self, data):
        name = data.get('name')
        email = data.get('email')
        subject = data.get('subject')
        message = data.get('message')

        if not name or not email or not message:
            self._set_json_headers(400)
            self.wfile.write(json.dumps({"status": "error", "message": "Missing required fields"}).encode())
            return

        conn = get_db_connection()
        c = conn.cursor()
        c.execute("INSERT INTO contacts (name, email, subject, message) VALUES (?, ?, ?, ?)", (name, email, subject, message))
        conn.commit()
        conn.close()

        self._set_json_headers(201)
        self.wfile.write(json.dumps({"status": "success", "message": "Message received"}).encode())

    def handle_api_get(self, path, query_params):
        """Handle GET API requests"""
        
        if path == '/api/courses':
            self.get_all_courses()
            return
            
        if path == '/api/my-courses':
            user = self._get_user_from_session()
            if not user:
                self._set_json_headers(401)
                self.wfile.write(json.dumps({"status": "error", "message": "Not logged in"}).encode())
                return
            self.get_user_courses(user['id'])
            return
            
        if path == '/api/user':
            user = self._get_user_from_session()
            if not user:
                self._set_json_headers(401)
                self.wfile.write(json.dumps({"status": "error", "message": "Not logged in"}).encode())
                return
            self._set_json_headers(200)
            self.wfile.write(json.dumps({"status": "success", "user": user}).encode())
            return

        # Course detail with lessons
        if path == '/api/course-detail':
            course_id = query_params.get('id', [None])[0]
            if not course_id:
                self._set_json_headers(400)
                self.wfile.write(json.dumps({"status": "error", "message": "Missing course id"}).encode())
                return
            self.get_course_detail(int(course_id))
            return

        if path == '/api/contact' and self.command == 'POST':
            # should be handled in do_POST, but accept GET here defensively
            self._set_json_headers(405)
            self.wfile.write(json.dumps({"status": "error", "message": "Method not allowed"}).encode())
            return

        self._set_json_headers(404)
        self.wfile.write(json.dumps({"status": "error", "message": "API endpoint not found"}).encode())

    def get_all_courses(self):
        conn = get_db_connection()
        c = conn.cursor()
        courses = c.execute(
            "SELECT c.*, u.username as instructor_name FROM courses c LEFT JOIN users u ON c.instructor_id = u.id"
        ).fetchall()
        conn.close()
        
        courses_list = [dict(course) for course in courses]
        self._set_json_headers(200)
        self.wfile.write(json.dumps({
            "status": "success",
            "courses": courses_list
        }).encode())

    def get_course_detail(self, course_id):
        conn = get_db_connection()
        c = conn.cursor()
        course = c.execute(
            "SELECT c.*, u.username as instructor_name FROM courses c LEFT JOIN users u ON c.instructor_id = u.id WHERE c.id = ?",
            (course_id,)
        ).fetchone()
        if not course:
            conn.close()
            self._set_json_headers(404)
            self.wfile.write(json.dumps({"status": "error", "message": "Course not found"}).encode())
            return

        lessons = c.execute(
            "SELECT * FROM lessons WHERE course_id = ? ORDER BY order_index ASC",
            (course_id,)
        ).fetchall()

        # If user logged in, include per-lesson progress
        user = self._get_user_from_session()
        lesson_progress = {}
        if user:
            rows = c.execute(
                "SELECT lesson_id, watched_seconds, completed FROM lesson_progress WHERE user_id = ? AND lesson_id IN (SELECT id FROM lessons WHERE course_id = ?)",
                (user['id'], course_id)
            ).fetchall()
            for r in rows:
                lesson_progress[r['lesson_id']] = { 'watched_seconds': r['watched_seconds'], 'completed': bool(r['completed']) }

        conn.close()

        course_obj = dict(course)
        lessons_list = []
        for l in lessons:
            ld = dict(l)
            lp = lesson_progress.get(ld['id'], {'watched_seconds': 0, 'completed': False})
            ld['progress'] = lp
            lessons_list.append(ld)

        self._set_json_headers(200)
        self.wfile.write(json.dumps({"status": "success", "course": course_obj, "lessons": lessons_list}).encode())

    def handle_lesson_progress(self, data):
        # data: lesson_id, watched_seconds, completed (optional)
        user = self._get_user_from_session()
        if not user:
            self._set_json_headers(401)
            self.wfile.write(json.dumps({"status": "error", "message": "Not logged in"}).encode())
            return

        lesson_id = data.get('lesson_id')
        watched_seconds = float(data.get('watched_seconds', 0))
        completed = 1 if data.get('completed') else 0

        if not lesson_id:
            self._set_json_headers(400)
            self.wfile.write(json.dumps({"status": "error", "message": "Missing lesson_id"}).encode())
            return

        conn = get_db_connection()
        c = conn.cursor()
        # Upsert into lesson_progress
        existing = c.execute("SELECT id, watched_seconds FROM lesson_progress WHERE lesson_id = ? AND user_id = ?", (lesson_id, user['id'])).fetchone()
        if existing:
            new_watched = max(existing['watched_seconds'], watched_seconds)
            c.execute("UPDATE lesson_progress SET watched_seconds = ?, completed = ?, last_watched = CURRENT_TIMESTAMP WHERE id = ?", (new_watched, completed, existing['id']))
        else:
            c.execute("INSERT INTO lesson_progress (lesson_id, user_id, watched_seconds, completed) VALUES (?, ?, ?, ?)", (lesson_id, user['id'], watched_seconds, completed))
        conn.commit()

        # Recalculate overall enrollment progress for the course
        course_row = c.execute("SELECT course_id FROM lessons WHERE id = ?", (lesson_id,)).fetchone()
        if course_row:
            course_id = course_row['course_id']
            # total lesson seconds
            total = c.execute("SELECT SUM(COALESCE(duration_minutes,0))*60 as total_seconds FROM lessons WHERE course_id = ?", (course_id,)).fetchone()['total_seconds'] or 0
            watched_sum = c.execute("SELECT SUM(watched_seconds) as watched_sum FROM lesson_progress lp JOIN lessons l ON lp.lesson_id = l.id WHERE l.course_id = ? AND lp.user_id = ?", (course_id, user['id'])).fetchone()['watched_sum'] or 0
            progress_pct = 0
            if total > 0:
                progress_pct = min(100, round((watched_sum / total) * 100))
            # update enrollments.progress
            c.execute("UPDATE enrollments SET progress = ? WHERE user_id = ? AND course_id = ?", (progress_pct, user['id'], course_id))
            conn.commit()

        conn.close()
        self._set_json_headers(200)
        self.wfile.write(json.dumps({"status": "success", "message": "Progress updated"}).encode())

    def get_user_courses(self, user_id):
        conn = get_db_connection()
        c = conn.cursor()
        # Include enrollment progress and enrolled_at from enrollments
        courses = c.execute(
            "SELECT c.*, e.progress as progress, e.enrolled_at as enrolled_at FROM courses c JOIN enrollments e ON c.id = e.course_id WHERE e.user_id = ?",
            (user_id,)
        ).fetchall()
        conn.close()
        
        courses_list = [dict(course) for course in courses]
        self._set_json_headers(200)
        self.wfile.write(json.dumps({
            "status": "success",
            "courses": courses_list
        }).encode())


if __name__ == "__main__":
    os.chdir(os.path.dirname(__file__))
    init_db()
    with socketserver.TCPServer(("", PORT), LMSHandler) as httpd:
        print(f"LMS Server running at http://localhost:{PORT}")
        print(f"Access the platform in your browser")
        httpd.serve_forever()
