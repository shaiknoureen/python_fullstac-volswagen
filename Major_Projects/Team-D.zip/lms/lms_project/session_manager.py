import uuid
import json
from datetime import datetime, timedelta

SESSIONS = {}
SESSION_COOKIE_NAME = "lms_session"
SESSION_TIMEOUT = timedelta(hours=24)

def create_session(user_data):
    """Create a new session for a user"""
    session_id = str(uuid.uuid4())
    SESSIONS[session_id] = {
        'user': user_data,
        'created_at': datetime.now(),
        'last_activity': datetime.now()
    }
    return session_id

def get_session(session_id):
    """Get session data if valid"""
    if not session_id or session_id not in SESSIONS:
        return None
    
    session = SESSIONS[session_id]
    
    # Check if session has expired
    if datetime.now() - session['created_at'] > SESSION_TIMEOUT:
        del SESSIONS[session_id]
        return None
    
    # Update last activity
    session['last_activity'] = datetime.now()
    return session['user']

def destroy_session(session_id):
    """Destroy a session"""
    if session_id in SESSIONS:
        del SESSIONS[session_id]
        return True
    return False

def is_session_valid(session_id):
    """Check if session is valid"""
    return get_session(session_id) is not None
