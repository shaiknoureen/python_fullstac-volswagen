const form = document.getElementById("pickupForm");
const result = document.getElementById("result");

const rates = {
    "Dry Waste": 5,
    "Wet Waste": 3,
    "E-Waste": 10,
    "Plastic Waste": 7
};

if (form) {
    form.addEventListener("submit", function (e) {
        e.preventDefault();

        const type = document.getElementById("wasteType").value;
        const qty = Number(document.getElementById("quantity").value);
        const address = document.getElementById("address").value;

        const cost = rates[type] * qty;

        const request = {
            type: type,
            qty: qty,
            address: address,
            cost: cost
        };

        // Get existing data
        let requests = JSON.parse(localStorage.getItem("requests")) || [];

        // Push new request
        requests.push(request);

        // Save back to localStorage
        localStorage.setItem("requests", JSON.stringify(requests));

        // ✅ POPUP CONFIRMATION
        alert("✅ Your pickup request has been saved successfully!");

        // ✅ ON-PAGE CONFIRMATION
        result.innerHTML = `
            <h3>Pickup Request Saved</h3>
            <p><b>Waste Type:</b> ${type}</p>
            <p><b>Quantity:</b> ${qty} kg</p>
            <p><b>Cost:</b> ₹${cost}</p>
            <p><b>Address:</b> ${address}</p>
        `;

        form.reset();
    });
}
