document.addEventListener('DOMContentLoaded', () => {
    initNavigation();
    initScrollEffects();
    initCounters();
    initTiltEffect();
    initMarqueeInteraction();
    initScrollToTop();
    initContactForm();
});

// Navigation
function initNavigation() {
    const navToggle = document.getElementById('nav-toggle');
    const navMenu = document.getElementById('nav-menu');
    const navbar = document.getElementById('navbar');

    // Mobile Menu
    if (navToggle) {
        navToggle.addEventListener('click', () => {
            navMenu.classList.toggle('active');
            const icon = navToggle.querySelector('i');
            if (icon) {
                icon.classList.toggle('fa-bars');
                icon.classList.toggle('fa-xmark');
            }
        });
    }

    // Close menu on link click
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', () => {
            if (navMenu) navMenu.classList.remove('active');
            const icon = navToggle ? navToggle.querySelector('i') : null;
            if (icon) {
                icon.classList.remove('fa-xmark');
                icon.classList.add('fa-bars');
            }
        });
    });

    //  Scroll Trigger
    window.addEventListener('scroll', () => {
        if (navbar) {
            if (window.scrollY > 20) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        }
    }, { passive: true });
}

// Parallax & Reveal Animations 
function initScrollEffects() {
    // Parallax Hero
    const heroBg = document.querySelector('.hero-bg');
    if (heroBg) {
        window.addEventListener('scroll', () => {
            const scrolled = window.scrollY;
            if (scrolled < window.innerHeight) {
                // TranslateY for slow movement, Scale for depth
                heroBg.style.transform = `translate3d(0, ${scrolled * 0.5}px, 0) scale(1.1)`;
            }
        }, { passive: true });
    }

    // Intersection Observer for Sections 
    const observerOptions = { threshold: 0.15, rootMargin: "0px 0px -50px 0px" };

    const revealObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
                revealObserver.unobserve(entry.target);
            }
        });
    }, observerOptions);

    
    const elementsToReveal = document.querySelectorAll('.service-card, .price-card, .review-card, .section-title, .about-content');

    elementsToReveal.forEach((el, index) => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(40px)';
        el.style.transition = 'all 0.8s cubic-bezier(0.16, 1, 0.3, 1)'; 

        
        if (el.classList.contains('service-card') || el.classList.contains('price-card')) {
            
            const delay = (index % 3) * 100;
            el.style.transitionDelay = `${delay}ms`;
        }

        revealObserver.observe(el);
    });
}

// Number Counter Animation
function initCounters() {
    const stats = document.querySelectorAll('.stat-item h3');

    const countObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const el = entry.target;
                const originalText = el.innerText;
                const finalValue = parseInt(originalText);

                let suffix = '';
                if (!isNaN(finalValue)) {
                    suffix = originalText.replace(finalValue.toString(), '');
                } else {
                    return; 
                }

                animateValue(el, 0, finalValue, 2000, suffix);
                countObserver.unobserve(el);
            }
        });
    }, { threshold: 0.5 });

    stats.forEach(stat => countObserver.observe(stat));
}

function animateValue(obj, start, end, duration, suffix) {
    let startTimestamp = null;
    const step = (timestamp) => {
        if (!startTimestamp) startTimestamp = timestamp;
        const progress = Math.min((timestamp - startTimestamp) / duration, 1);
        const easeProgress = 1 - Math.pow(1 - progress, 3); // Cubic ease out

        obj.innerHTML = Math.floor(easeProgress * (end - start) + start) + suffix;

        if (progress < 1) {
            window.requestAnimationFrame(step);
        }
    };
    window.requestAnimationFrame(step);
}

// 3D Tilt Effect 
function initTiltEffect() {
    const cards = document.querySelectorAll('.service-card, .price-card');

    cards.forEach(card => {
        card.addEventListener('mousemove', (e) => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;

            const xRot = -1 * ((y - rect.height / 2) / rect.height * 10);
            const yRot = (x - rect.width / 2) / rect.width * 10;

            card.style.transform = `perspective(1000px) rotateX(${xRot}deg) rotateY(${yRot}deg) scale(1.02)`;
            card.style.zIndex = '10';
        });

        card.addEventListener('mouseleave', () => {
            card.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) scale(1)';
            card.style.zIndex = '1';
        });
    });
}

// Marquee Interaction
function initMarqueeInteraction() {
    const marquee = document.querySelector('.marquee-content');
    if (marquee) {
        marquee.addEventListener('mouseenter', () => {
            marquee.style.animationPlayState = 'paused';
        });
        marquee.addEventListener('mouseleave', () => {
            marquee.style.animationPlayState = 'running';
        });
    }
}

// Scroll to Top 
function initScrollToTop() {
    const scrollToTopBtn = document.getElementById('scrollToTopBtn');

    if (scrollToTopBtn) {
        
        window.addEventListener('scroll', () => {
            if (window.scrollY > 300) {
                scrollToTopBtn.classList.add('visible');
            } else {
                scrollToTopBtn.classList.remove('visible');
            }
        }, { passive: true });

        
        scrollToTopBtn.addEventListener('click', () => {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }
}

// Contact Form Handling 
function initContactForm() {
    const contactForm = document.getElementById('contactForm');
    const customAlert = document.getElementById('customAlert');

    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();

            // Show Custom Alert
            if (customAlert) {
                customAlert.classList.add('active');
                setTimeout(() => {
                    customAlert.classList.remove('active');
                }, 4000); 
            }

            contactForm.reset(); 
        });
    }
}
