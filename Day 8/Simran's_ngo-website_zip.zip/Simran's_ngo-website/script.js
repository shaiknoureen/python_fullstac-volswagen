// ===============================
// GLOBAL VARIABLES
// ===============================
let isScrolled = false;

// ===============================
// DOM CONTENT LOADED
// ===============================
document.addEventListener('DOMContentLoaded', function() {
    initializeNavbar();
    initializeCounters();
    initializeFormValidation();
    initializeNotifications();
    initializeScrollAnimations();
    initializeProjectFilters();
    initializeProjectDetails();
});

// ===============================
// NAVBAR FUNCTIONALITY
// ===============================
function initializeNavbar() {
    const navbar = document.querySelector('.navbar');
    
    window.addEventListener('scroll', function() {
        if (window.scrollY > 100 && !isScrolled) {
            navbar.classList.add('scrolled');
            isScrolled = true;
        } else if (window.scrollY <= 100 && isScrolled) {
            navbar.classList.remove('scrolled');
            isScrolled = false;
        }
    });
}

// ===============================
// ANIMATED COUNTERS
// ===============================
function initializeCounters() {
    const counters = document.querySelectorAll('.counter-number');
    const observerOptions = {
        threshold: 0.5,
        rootMargin: '0px 0px -100px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                animateCounter(entry.target);
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    counters.forEach(counter => {
        observer.observe(counter);
    });
}

function animateCounter(element) {
    const target = parseInt(element.getAttribute('data-target'));
    const duration = 2000; // 2 seconds
    const increment = target / (duration / 16); // 60fps
    let current = 0;

    const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
            element.textContent = formatNumber(target);
            clearInterval(timer);
        } else {
            element.textContent = formatNumber(Math.floor(current));
        }
    }, 16);
}

function formatNumber(num) {
    if (num >= 1000) {
        return (num / 1000).toFixed(0) + 'K+';
    }
    return num.toLocaleString();
}

// ===============================
// FORM VALIDATION
// ===============================
function initializeFormValidation() {
    // Newsletter form validation
    const newsletterForm = document.getElementById('newsletter-form');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            validateNewsletterForm();
        });
    }

    // Contact form validation (if exists)
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            validateContactForm();
        });
    }

    // Volunteer form validation (if exists)
    const volunteerForm = document.getElementById('volunteer-form');
    if (volunteerForm) {
        volunteerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            validateVolunteerForm();
        });
    }

    // Donation form validation (if exists)
    const donationForm = document.getElementById('donation-form');
    if (donationForm) {
        donationForm.addEventListener('submit', function(e) {
            e.preventDefault();
            validateDonationForm();
        });
    }

    // Add gentle real-time validation
    addGentleValidation();
}

function addGentleValidation() {
    // Completely disable real-time validation to prevent red errors on valid inputs
    // Only validate on form submission
    const allInputs = document.querySelectorAll('input, textarea, select');

    allInputs.forEach(input => {
        // Clear any existing validation classes when user starts typing
        input.addEventListener('input', function() {
            clearValidationState(this);
        });

        // Clear validation state when user focuses on field
        input.addEventListener('focus', function() {
            clearValidationState(this);
        });
    });
}

function showPositiveFeedback(input) {
    // Only show positive feedback after successful form submission
    input.classList.remove('is-invalid');
    input.classList.add('is-valid');
}

function clearValidationState(input) {
    input.classList.remove('is-valid', 'is-invalid');
}

function validateOnSubmit(form) {
    const inputs = form.querySelectorAll('input[required], textarea[required], select[required]');
    let isValid = true;
    let firstInvalidField = null;

    inputs.forEach(input => {
        const value = input.value.trim();
        let fieldValid = true;

        // Clear previous validation state
        clearValidationState(input);

        // Only validate required fields that are actually empty or clearly invalid
        if (input.type === 'email') {
            if (value === '') {
                fieldValid = false;
            } else if (value.length > 0 && !validateEmail(value)) {
                fieldValid = false;
            }
        } else if (input.type === 'tel') {
            if (value === '') {
                fieldValid = false;
            } else if (value.length > 0 && !validatePhone(value)) {
                fieldValid = false;
            }
        } else if (input.type === 'number') {
            if (value === '') {
                fieldValid = false;
            } else {
                const numValue = parseFloat(value);
                const min = parseFloat(input.getAttribute('min')) || 0;
                if (isNaN(numValue) || numValue < min) {
                    fieldValid = false;
                }
            }
        } else {
            // Text, textarea, select - only fail if completely empty
            if (value === '') {
                fieldValid = false;
            }
        }

        if (!fieldValid) {
            input.classList.add('is-invalid');
            isValid = false;
            if (!firstInvalidField) {
                firstInvalidField = input;
            }
        } else {
            input.classList.add('is-valid');
        }
    });

    // Focus on first invalid field
    if (firstInvalidField) {
        firstInvalidField.focus();
    }

    return isValid;
}

function validateNewsletterForm() {
    const emailInput = document.getElementById('newsletter-email');
    const email = emailInput.value.trim();
    
    clearValidationState(emailInput);
    
    if (email === '' || !validateEmail(email)) {
        emailInput.classList.add('is-invalid');
        emailInput.focus();
        return;
    }
    
    emailInput.classList.add('is-valid');
    showNotification('Thank you for subscribing to our newsletter!', 'success');
    emailInput.value = '';
    
    setTimeout(() => {
        clearValidationState(emailInput);
    }, 3000);
}

function validateContactForm() {
    const form = document.getElementById('contact-form');
    
    // Check for interest checkboxes if this is volunteer form
    const interestCheckboxes = document.querySelectorAll('.interest-checkbox');
    if (interestCheckboxes.length > 0) {
        const isAnyInterestSelected = Array.from(interestCheckboxes).some(checkbox => checkbox.checked);
        
        if (!isAnyInterestSelected) {
            const interestSection = document.querySelector('.interest-checkbox').closest('.col-12');
            const feedback = interestSection.querySelector('.invalid-feedback');
            if (feedback) {
                feedback.style.display = 'block';
                interestSection.querySelector('.form-label').style.color = 'var(--danger-color)';
            }
            return;
        } else {
            const interestSection = document.querySelector('.interest-checkbox').closest('.col-12');
            const feedback = interestSection.querySelector('.invalid-feedback');
            if (feedback) {
                feedback.style.display = 'none';
                interestSection.querySelector('.form-label').style.color = 'var(--text-dark)';
            }
        }
    }
    
    if (validateOnSubmit(form)) {
        showNotification('Thank you for your message! We will get back to you soon.', 'success');
        form.reset();
        
        // Clear all validation states
        setTimeout(() => {
            const inputs = form.querySelectorAll('input, textarea, select');
            inputs.forEach(input => {
                clearValidationState(input);
            });
        }, 3000);
    }
}

function validateVolunteerForm() {
    validateContactForm(); // Same logic
}

function validateDonationForm() {
    const form = document.getElementById('donation-form');
    
    if (validateOnSubmit(form)) {
        showNotification('Thank you for your donation! Redirecting to payment gateway...', 'success');
        setTimeout(() => {
            showNotification('Payment gateway integration required for live donations.', 'info');
        }, 2000);
    }
}

// ===============================
// VALIDATION HELPERS
// ===============================
function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function validatePhone(phone) {
    // Remove all non-digit characters for validation
    const cleanPhone = phone.replace(/[\s\-\(\)\+\.]/g, '');
    
    // Accept various formats - be very lenient:
    // - 10 digits (Indian mobile)
    // - 11 digits (with country code like 91xxxxxxxxxx)
    // - 12+ digits (international formats)
    // - Even accept shorter numbers for landlines
    
    if (cleanPhone.length >= 7 && cleanPhone.length <= 15) {
        // Check if it contains mostly digits (allow some flexibility)
        const digitCount = (cleanPhone.match(/\d/g) || []).length;
        return digitCount >= 7; // At least 7 digits
    }
    
    return false;
}

// ===============================
// NOTIFICATIONS
// ===============================
function initializeNotifications() {
    // Create notification container if it doesn't exist
    if (!document.getElementById('notification-container')) {
        const container = document.createElement('div');
        container.id = 'notification-container';
        container.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            max-width: 400px;
        `;
        document.body.appendChild(container);
    }
}

function showNotification(message, type = 'info', duration = 5000) {
    const container = document.getElementById('notification-container');
    const notification = document.createElement('div');
    
    const typeClasses = {
        success: 'alert-success',
        error: 'alert-danger',
        warning: 'alert-warning',
        info: 'alert-info'
    };
    
    const icons = {
        success: 'bi-check-circle-fill',
        error: 'bi-exclamation-triangle-fill',
        warning: 'bi-exclamation-triangle-fill',
        info: 'bi-info-circle-fill'
    };
    
    notification.className = `alert ${typeClasses[type]} alert-dismissible fade show`;
    notification.style.cssText = `
        margin-bottom: 10px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        border: none;
        border-radius: 10px;
    `;
    
    notification.innerHTML = `
        <i class="bi ${icons[type]} me-2"></i>
        ${message}
        <button type="button" class="btn-close" onclick="this.parentElement.remove()"></button>
    `;
    
    container.appendChild(notification);
    
    // Auto remove after duration
    setTimeout(() => {
        if (notification.parentElement) {
            notification.classList.remove('show');
            setTimeout(() => {
                if (notification.parentElement) {
                    notification.remove();
                }
            }, 150);
        }
    }, duration);
}

function closeNotification() {
    const notificationBar = document.getElementById('notification-bar');
    if (notificationBar) {
        notificationBar.style.display = 'none';
    }
}

// ===============================
// SCROLL ANIMATIONS
// ===============================
function initializeScrollAnimations() {
    const animatedElements = document.querySelectorAll('.service-card, .counter-item');
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    });

    animatedElements.forEach(element => {
        element.style.opacity = '0';
        element.style.transform = 'translateY(30px)';
        element.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(element);
    });
}



// ===============================
// DONATION AMOUNT SELECTOR
// ===============================
function selectDonationAmount(amount) {
    // Remove active class from all buttons
    document.querySelectorAll('.donation-amount').forEach(btn => {
        btn.classList.remove('active');
    });
    
    // Add active class to selected button
    event.target.classList.add('active');
    
    // Update custom amount input
    const customInput = document.getElementById('custom-amount');
    if (customInput) {
        customInput.value = amount;
    }
}

// ===============================
// SEARCH FUNCTIONALITY
// ===============================
function initializeSearch() {
    const searchInput = document.getElementById('search-input');
    const searchResults = document.getElementById('search-results');
    
    if (searchInput && searchResults) {
        searchInput.addEventListener('input', function() {
            const query = this.value.trim();
            if (query.length > 2) {
                performSearch(query);
            } else {
                searchResults.innerHTML = '';
                searchResults.style.display = 'none';
            }
        });
    }
}

function performSearch(query) {
    // Simulate search results
    const mockResults = [
        { title: 'Education Program', url: 'education.html', description: 'Quality education for underprivileged children' },
        { title: 'Healthcare Initiative', url: 'healthcare.html', description: 'Free medical camps and health awareness' },
        { title: 'Volunteer Opportunities', url: 'volunteer.html', description: 'Join our team of dedicated volunteers' }
    ];
    
    const filteredResults = mockResults.filter(result => 
        result.title.toLowerCase().includes(query.toLowerCase()) ||
        result.description.toLowerCase().includes(query.toLowerCase())
    );
    
    displaySearchResults(filteredResults);
}

function displaySearchResults(results) {
    const searchResults = document.getElementById('search-results');
    
    if (results.length === 0) {
        searchResults.innerHTML = '<div class="p-3 text-muted">No results found</div>';
    } else {
        searchResults.innerHTML = results.map(result => `
            <div class="search-result-item p-3 border-bottom">
                <h6><a href="${result.url}" class="text-decoration-none">${result.title}</a></h6>
                <p class="mb-0 text-muted small">${result.description}</p>
            </div>
        `).join('');
    }
    
    searchResults.style.display = 'block';
}

// ===============================
// LAZY LOADING IMAGES
// ===============================
function initializeLazyLoading() {
    const images = document.querySelectorAll('img[data-src]');
    
    const imageObserver = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.remove('lazy');
                imageObserver.unobserve(img);
            }
        });
    });

    images.forEach(img => {
        imageObserver.observe(img);
    });
}

// ===============================
// THEME TOGGLE (Optional)
// ===============================
function toggleTheme() {
    document.body.classList.toggle('dark-theme');
    const isDark = document.body.classList.contains('dark-theme');
    localStorage.setItem('theme', isDark ? 'dark' : 'light');
}

// Load saved theme
document.addEventListener('DOMContentLoaded', function() {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
        document.body.classList.add('dark-theme');
    }
});

// ===============================
// UTILITY FUNCTIONS
// ===============================
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    }
}
// ===============================
// PROJECT FILTERING
// ===============================
function initializeProjectFilters() {
    const filterBtns = document.querySelectorAll('.filter-btn');
    const projectCards = document.querySelectorAll('.project-card');
    
    if (filterBtns.length === 0 || projectCards.length === 0) return;
    
    filterBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            // Remove active class from all buttons
            filterBtns.forEach(b => b.classList.remove('active'));
            // Add active class to clicked button
            this.classList.add('active');
            
            const filter = this.getAttribute('data-filter');
            
            projectCards.forEach(card => {
                const categories = card.getAttribute('data-category');
                
                if (filter === 'all' || categories.includes(filter)) {
                    card.style.display = 'block';
                    setTimeout(() => {
                        card.style.opacity = '1';
                        card.style.transform = 'translateY(0)';
                    }, 100);
                } else {
                    card.style.opacity = '0';
                    card.style.transform = 'translateY(20px)';
                    setTimeout(() => {
                        card.style.display = 'none';
                    }, 300);
                }
            });
        });
    });
}

// ===============================
// PROJECT DETAILS MODAL
// ===============================
function initializeProjectDetails() {
    const viewDetailsBtns = document.querySelectorAll('.project-overlay .btn, .btn[href="#"]');
    
    viewDetailsBtns.forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Get project information from the card
            const projectCard = this.closest('.project-card') || this.closest('.featured-project');
            if (!projectCard) return;
            
            const projectTitle = projectCard.querySelector('h3, h4').textContent;
            const projectDescription = projectCard.querySelector('p').textContent;
            const projectCategory = projectCard.querySelector('.project-category').textContent;
            const projectImage = projectCard.querySelector('img').src;
            
            showProjectModal(projectTitle, projectDescription, projectCategory, projectImage);
        });
    });
}

function showProjectModal(title, description, category, image) {
    // Create modal HTML
    const modalHTML = `
        <div class="modal fade" id="projectModal" tabindex="-1">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">${title}</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6">
                                <img src="${image}" alt="${title}" class="img-fluid rounded mb-3">
                                <span class="badge bg-primary mb-3">${category}</span>
                            </div>
                            <div class="col-md-6">
                                <p>${description}</p>
                                <h6>Project Details:</h6>
                                <ul>
                                    <li>Duration: 12-18 months</li>
                                    <li>Target Beneficiaries: 1,000+ people</li>
                                    <li>Implementation Area: Rural communities</li>
                                    <li>Partners: Local NGOs and government</li>
                                </ul>
                                <div class="mt-4">
                                    <a href="donate.html" class="btn btn-donate me-2">
                                        <i class="bi bi-heart-fill me-1"></i>Support This Project
                                    </a>
                                    <a href="volunteer.html" class="btn btn-outline-primary">
                                        <i class="bi bi-people-fill me-1"></i>Volunteer
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Remove existing modal if any
    const existingModal = document.getElementById('projectModal');
    if (existingModal) {
        existingModal.remove();
    }
    
    // Add modal to body
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    // Show modal
    const modal = new bootstrap.Modal(document.getElementById('projectModal'));
    modal.show();
    
    // Clean up modal after it's hidden
    document.getElementById('projectModal').addEventListener('hidden.bs.modal', function() {
        this.remove();
    });
}

// ===============================
// SECTION HIGHLIGHTING
// ===============================
function highlightSection(sectionId) {
    // Remove highlight from all sections
    document.querySelectorAll('.section-highlight').forEach(section => {
        section.classList.remove('active');
    });
    
    // Add highlight to target section
    const targetSection = document.querySelector(sectionId);
    if (targetSection) {
        targetSection.classList.add('section-highlight', 'active');
        
        // Remove highlight after 3 seconds
        setTimeout(() => {
            targetSection.classList.remove('active');
        }, 3000);
    }
}

// Enhanced smooth scrolling with highlighting
document.querySelectorAll('a[href*="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        const href = this.getAttribute('href');
        
        // Check if it's a same-page anchor link
        if (href.startsWith('#')) {
            e.preventDefault();
            const target = document.querySelector(href);
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
                highlightSection(href);
            }
        }
        // Check if it's a cross-page anchor link (like about.html#team)
        else if (href.includes('#') && href.includes('.html')) {
            const [page, hash] = href.split('#');
            const currentPage = window.location.pathname.split('/').pop();
            
            // If we're on the same page, scroll to section
            if (page === currentPage || page === `./${currentPage}`) {
                e.preventDefault();
                const target = document.querySelector(`#${hash}`);
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                    highlightSection(`#${hash}`);
                }
            }
            // Otherwise, let the browser navigate normally and handle on load
        }
    });
});

// Enhanced hash handling on page load
document.addEventListener('DOMContentLoaded', function() {
    if (window.location.hash) {
        setTimeout(() => {
            const target = document.querySelector(window.location.hash);
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
                highlightSection(window.location.hash);
            }
        }, 300); // Increased delay to ensure all content is loaded
    }
});