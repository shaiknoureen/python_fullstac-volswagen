# Images Directory

This directory contains all the images used in the Hope Foundation website.

## Required Images:

### Favicon Files:
- favicon.ico (16x16, 32x32, 48x48 pixels)
- apple-touch-icon.png (180x180 pixels)

### High-Quality Images:
All images should be high-resolution (minimum 1920x1080 for hero images, 800x600 for content images)

### Image Sources:
- Hero backgrounds: Community development, education, healthcare themes
- Service icons: Education, healthcare, environment, women empowerment
- Team photos: Professional headshots of leadership team
- Project photos: Real impact photos from field work
- Volunteer photos: People working together, helping communities

### Recommended Image Specifications:
- Format: JPG for photos, PNG for graphics with transparency
- Quality: 80-90% for web optimization
- Alt text: Always include descriptive alt text for accessibility

### Image Optimization:
- Use responsive images with srcset for different screen sizes
- Implement lazy loading for better performance
- Compress images without losing quality

## Usage Guidelines:
- All images should be relevant to NGO work and social impact
- Maintain consistent color scheme with website design
- Ensure images are culturally appropriate and respectful
- Use diverse representation in people photos