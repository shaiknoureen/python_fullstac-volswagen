(function(){
  const buses = [
    { id: 'B100', name: 'Swift Travels', type: 'AC Seater', fare: 450, dep: '08:00', arr: '12:00' },
    { id: 'B200', name: 'CityLines', type: 'Non-AC', fare: 300, dep: '09:30', arr: '14:00' },
    { id: 'B300', name: 'ComfortMove', type: 'AC Sleeper', fare: 700, dep: '21:00', arr: '05:00' }
  ];

  function saveSearch(from,to,date){
    localStorage.setItem('search', JSON.stringify({from,to,date}));
  }
  function getSearch(){ return JSON.parse(localStorage.getItem('search')||'null'); }

  function goToBusList(){ window.location.href = 'bus_list.html'; }

  // Home page search
  const searchForm = document.getElementById('searchForm');
  if(searchForm){
    searchForm.addEventListener('submit', function(e){
      e.preventDefault();
      const from = document.getElementById('from').value;
      const to = document.getElementById('to').value;
      const date = document.getElementById('date').value;
      saveSearch(from,to,date);
      goToBusList();
    });
    const s = getSearch(); if(s){ document.getElementById('from').value=s.from; document.getElementById('to').value=s.to; document.getElementById('date').value=s.date; }
  }

  // Bus list
  const busContainer = document.getElementById('busContainer');
  if(busContainer){
    const s = getSearch();
    busContainer.innerHTML = '';
    buses.forEach(b=>{
      const div = document.createElement('div');
      div.className = 'mb-3 p-3 border rounded';
      div.innerHTML = `
        <h5>${b.name} (${b.id})</h5>
        <p>${b.type} • Fare: ₹${b.fare}</p>
        <p><strong>${b.dep}</strong> → <strong>${b.arr}</strong></p>
        <button class="btn btn-primary selectSeatBtn" data-id="${b.id}">Select Seat</button>`;
      busContainer.appendChild(div);
    });
    document.querySelectorAll('.selectSeatBtn').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        const id = btn.dataset.id; localStorage.setItem('selectedBus', id); window.location.href='seat_selection.html';
      });
    });
  }

  // Seat selection
  const seatsDiv = document.getElementById('seats');
  if(seatsDiv){
    const busId = localStorage.getItem('selectedBus');
    const bus = buses.find(x=>x.id===busId) || buses[0];
    document.getElementById('busInfo').innerHTML = `<h5>${bus.name} (${bus.id}) — ${bus.type}</h5>`;
    
    const booked = JSON.parse(localStorage.getItem('booked_'+bus.id)||'[]');
    const selected = new Set(JSON.parse(localStorage.getItem('selectedSeats')||'[]'));
    
    const isSleeper = bus.type.toLowerCase().includes('sleeper');
    const seatsPerRow = 4;
    const totalSeats = 40;
    
    function renderSeats(){
      seatsDiv.innerHTML = '';
      
      if(isSleeper){
        // Sleeper bus: Upper and Lower berths
        const upperDiv = document.createElement('div');
        upperDiv.className = 'bus-section';
        upperDiv.innerHTML = '<div class="section-title">🛏️ Upper Berths</div>';
        const upperGrid = document.createElement('div');
        upperGrid.className = 'seats-grid';
        
        const lowerDiv = document.createElement('div');
        lowerDiv.className = 'bus-section';
        lowerDiv.innerHTML = '<div class="section-title">🛏️ Lower Berths</div>';
        const lowerGrid = document.createElement('div');
        lowerGrid.className = 'seats-grid';
        
        for(let i=1; i<=totalSeats; i++){
          const btn = createSeatButton(i, booked, selected, isSleeper);
          if(i <= totalSeats/2){
            upperGrid.appendChild(btn);
          } else {
            lowerGrid.appendChild(btn);
          }
        }
        
        upperDiv.appendChild(upperGrid);
        lowerDiv.appendChild(lowerGrid);
        
        const layoutDiv = document.createElement('div');
        layoutDiv.className = 'seat-layout';
        layoutDiv.appendChild(upperDiv);
        layoutDiv.appendChild(lowerDiv);
        seatsDiv.appendChild(layoutDiv);
        
      } else {
        // Regular seater bus: 10 rows x 4 columns
        const sectionDiv = document.createElement('div');
        sectionDiv.className = 'bus-section';
        sectionDiv.innerHTML = '<div class="section-title">💺 Seating Layout</div>';
        const grid = document.createElement('div');
        grid.className = 'seats-grid';
        
        for(let i=1; i<=totalSeats; i++){
          const btn = createSeatButton(i, booked, selected, isSleeper);
          grid.appendChild(btn);
        }
        
        sectionDiv.appendChild(grid);
        seatsDiv.appendChild(sectionDiv);
      }
      
      // Add legend
      const legend = document.createElement('div');
      legend.className = 'legend';
      legend.innerHTML = `
        <div class="legend-item">
          <div class="legend-box legend-available"></div>
          <span>Available</span>
        </div>
        <div class="legend-item">
          <div class="legend-box legend-selected"></div>
          <span>Selected</span>
        </div>
        <div class="legend-item">
          <div class="legend-box legend-booked"></div>
          <span>Booked</span>
        </div>
      `;
      seatsDiv.appendChild(legend);
      
      document.getElementById('proceedBtn').disabled = selected.size===0;
    }
    
    function createSeatButton(seatNum, booked, selected, isSleeper){
      const btn = document.createElement('button');
      btn.className = 'btn seat btn-sm';
      btn.innerHTML = `<span>${seatNum}</span>`;
      if(isSleeper){
        const berthType = seatNum <= totalSeats/2 ? 'U' : 'L';
        btn.innerHTML += `<span class="seat-label">${berthType}</span>`;
      }
      btn.dataset.seat = seatNum;
      
      if(booked.includes(seatNum)) { 
        btn.classList.add('btn-danger'); 
        btn.disabled=true; 
      } else if(selected.has(String(seatNum))){ 
        btn.classList.add('btn-success'); 
      } else { 
        btn.classList.add('btn-outline-secondary'); 
      }
      
      btn.addEventListener('click', ()=>{
        if(selected.has(String(seatNum))){ 
          selected.delete(String(seatNum)); 
          btn.classList.remove('btn-success'); 
          btn.classList.add('btn-outline-secondary'); 
        } else { 
          selected.add(String(seatNum)); 
          btn.classList.remove('btn-outline-secondary'); 
          btn.classList.add('btn-success'); 
        }
        localStorage.setItem('selectedSeats', JSON.stringify(Array.from(selected)));
        document.getElementById('proceedBtn').disabled = selected.size===0;
      });
      
      return btn;
    }
    
    renderSeats();
    document.getElementById('proceedBtn').addEventListener('click', ()=>{ window.location.href='passenger_details.html'; });
  }

  // Passenger details
  const passengerList = document.getElementById('passengerList');
  if(passengerList){
    const seats = JSON.parse(localStorage.getItem('selectedSeats')||'[]');
    if(seats.length===0){ passengerList.innerHTML = '<p>No seats selected. Go back to select seats.</p>'; }
    seats.forEach((seat, idx)=>{
      const div = document.createElement('div');
      div.className = 'mb-3 p-3 border rounded';
      div.innerHTML = `
        <h5>Passenger for Seat ${seat}</h5>
        <div class="mb-2">
          <label>Name:</label>
          <input name="name_${idx}" class="form-control" required>
        </div>
        <div class="mb-2">
          <label>Age:</label>
          <input name="age_${idx}" type="number" class="form-control" required>
        </div>
        <div class="mb-2">
          <label>Gender:</label>
          <select name="gender_${idx}" class="form-select" required><option>Male</option><option>Female</option><option>Other</option></select>
        </div>
        <div class="mb-2">
          <label>Phone:</label>
          <input name="phone_${idx}" class="form-control" required>
        </div>`;
      passengerList.appendChild(div);
    });
    document.getElementById('passengerForm').addEventListener('submit', function(e){
      e.preventDefault();
      const data = { seats: JSON.parse(localStorage.getItem('selectedSeats')||'[]'), passengers: [] };
      seats.forEach((seat, idx)=>{
        data.passengers.push({ seat, name: this[`name_${idx}`].value, age: this[`age_${idx}`].value, gender: this[`gender_${idx}`].value, phone: this[`phone_${idx}`].value });
      });
      // mark seats booked
      const busId = localStorage.getItem('selectedBus');
      const key = 'booked_'+busId;
      const booked = JSON.parse(localStorage.getItem(key)||'[]');
      const newBooked = booked.concat(data.seats.map(s=>Number(s)));
      localStorage.setItem(key, JSON.stringify(newBooked));
      localStorage.setItem('booking', JSON.stringify(Object.assign({ busId, bookingId: 'BK'+Date.now() }, data)));
      // clear selected seats
      localStorage.removeItem('selectedSeats');
      window.location.href='confirmation.html';
    });
  }

  // Confirmation page and notifications
  const bookingSummary = document.getElementById('bookingSummary');
  if(bookingSummary){
    const booking = JSON.parse(localStorage.getItem('booking')||'null');
    if(!booking){ bookingSummary.innerHTML = '<p>No booking found.</p>'; }
    else{
      const bus = buses.find(b=>b.id===booking.busId)||{};
      bookingSummary.innerHTML = `
        <p><strong>Booking ID:</strong> ${booking.bookingId}</p>
        <p><strong>Bus:</strong> ${bus.name} (${booking.busId})</p>
        <p><strong>Seats:</strong> ${booking.seats.join(', ')}</p>
        <p><strong>Passengers:</strong></p>
        <ul>${booking.passengers.map(p=>`<li>${p.name} (Seat ${p.seat})</li>`).join('')}</ul>
      `;
    }

    const statusBox = document.getElementById('notificationStatus');
    function showInlineStatus(message, type){
      if(!statusBox) return;
      statusBox.style.display = 'block';
      statusBox.textContent = message;
      statusBox.className = 'mt-3 p-2 border rounded';
      const color = type==='success' ? 'bg-success text-white' : type==='warning' ? 'bg-warning text-dark' : type==='danger' ? 'bg-danger text-white' : 'bg-light text-dark';
      statusBox.className += ' ' + color;
    }

    function showNotification(title, body){
      // Always show inline status for immediate feedback
      showInlineStatus(title + ' - ' + body, 'light');
      // Try browser notification first
      if('Notification' in window){
        if(Notification.permission === 'granted'){
          try {
            new Notification(title, { 
              body: body,
              icon: 'https://via.placeholder.com/128/007bff/ffffff?text=Bus'
            });
            return;
          } catch(e) {
            console.log('Notification error:', e);
          }
        } else if(Notification.permission === 'default'){
          Notification.requestPermission().then(perm => {
            if(perm === 'granted'){
              new Notification(title, { 
                body: body,
                icon: 'https://via.placeholder.com/128/007bff/ffffff?text=Bus'
              });
              showInlineStatus('Browser notifications enabled.', 'success');
            } else {
              showInlineStatus('Notifications blocked by browser. Showing alert fallback.', 'warning');
              alert(title + '\n\n' + body);
            }
          });
          return;
        } else if(Notification.permission === 'denied'){
          showInlineStatus('Notifications are denied. Use browser settings to allow them. Showing alert fallback.', 'warning');
        }
      } else {
        showInlineStatus('Notifications not supported in this browser. Showing alert fallback.', 'danger');
      }
      // Fallback to alert
      alert(title + '\n\n' + body);
    }

    // Permission check and button
    const enableBtn = document.getElementById('enableNotifs');
    if(enableBtn){
      enableBtn.addEventListener('click', function(){
        if('Notification' in window){
          Notification.requestPermission().then(perm => {
            if(perm === 'granted') showInlineStatus('Browser notifications enabled.', 'success');
            else showInlineStatus('Notifications blocked. You will see alerts instead.', 'warning');
          });
        } else {
          showInlineStatus('Notifications not supported. You will see alerts instead.', 'danger');
        }
      });
      // Show current status
      if('Notification' in window){
        if(Notification.permission === 'granted') showInlineStatus('Browser notifications are enabled.', 'success');
        else if(Notification.permission === 'denied') showInlineStatus('Notifications are denied. Use browser settings to allow them. Alerts will be shown.', 'warning');
        else showInlineStatus('Click "Enable Notifications" to allow browser notifications.', 'light');
      } else {
        showInlineStatus('Notifications not supported in this browser. Alerts will be shown.', 'danger');
      }
    }

    document.getElementById('notifyStart').addEventListener('click', function(){
      window.location.href = 'trip_started.html';
    });

    document.getElementById('notifyEnd').addEventListener('click', function(){
      window.location.href = 'trip_ended.html';
    });

    const demoScheduleBtn = document.getElementById('demoSchedule');
    if(demoScheduleBtn){
      demoScheduleBtn.addEventListener('click', function(){
        showNotification('📅 Auto Demo Started', 'Trip notifications coming in 3 seconds...');
        
        setTimeout(() => {
          showNotification('🚌 Your Trip Started', 'Bus has departed. Estimated arrival: 4 hours');
        }, 3000);
        
        setTimeout(() => {
          const endOptions = [
            { title: '✓ Trip Ended', body: 'You have reached your destination. Thank you!' },
            { title: '⏰ Drop Delayed by 5 min', body: 'Your drop point is delayed. Please wait.' },
            { title: '⏰ Pickup Delayed by 5 min', body: 'Your pickup is delayed. Please wait.' }
          ];
          const selected = endOptions[Math.floor(Math.random() * endOptions.length)];
          showNotification(selected.title, selected.body);
        }, 10000);
      });
    }
  }

})();
