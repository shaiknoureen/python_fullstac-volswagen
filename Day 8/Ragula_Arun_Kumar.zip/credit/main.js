// Navigation function to show/hide sections
function showSection(sectionName) {
    document.getElementById('homeSection').classList.add('section-hidden');
    document.getElementById('servicesSection').classList.add('section-hidden');
    document.getElementById('aboutSection').classList.add('section-hidden');
    document.getElementById('contactSection').classList.add('section-hidden');
    document.getElementById(sectionName + 'Section').classList.remove('section-hidden');
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
    });
    event.target.classList.add('active');
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function scrollToFindCard(event) {
    event.preventDefault();
    const findCardSection = document.getElementById('findCard');
    findCardSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function validatePAN(pan) {
    const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
    return panRegex.test(pan);
}

function getDeterministicCreditScore(pan) {
    let hash = 0;
    for (let i = 0; i < pan.length; i++) {
        hash += pan.charCodeAt(i);
    }
    return 650 + (hash % 201);
}

function checkCreditScore() {
    const panInput = document.getElementById('panInput');
    const panError = document.getElementById('panError');
    const pan = panInput.value.toUpperCase();
    if (!pan) {
        panError.textContent = 'Please enter your PAN card number';
        return;
    }
    if (!validatePAN(pan)) {
        panError.textContent = 'Invalid PAN format. Please enter a valid PAN (e.g., ABCDE1234F)';
        return;
    }
    panError.textContent = '';
    const creditScore = getDeterministicCreditScore(pan);
    document.getElementById('creditScoreDisplay').textContent = creditScore;
    document.getElementById('resultsSection').style.display = 'block';
    generateCardRecommendations(creditScore);
    setTimeout(() => {
        document.getElementById('resultsSection').scrollIntoView({ behavior: 'smooth' });
    }, 300);
}

function generateCardRecommendations(score) {
    const cardsContainer = document.getElementById('cardsContainer');
    let cards = [];
    if (score >= 750) {
        cards = [
            { name: 'HDFC Regalia', type: 'Premium', features: ['5% cashback on dining', 'Airport lounge access', 'Reward points on every purchase', 'Zero forex markup'] },
            { name: 'SBI Elite', type: 'Premium', features: ['10X rewards on online shopping', 'Complimentary golf games', 'Travel insurance', 'Fuel surcharge waiver'] },
            { name: 'ICICI Sapphiro', type: 'Premium', features: ['2 reward points per ₹100', 'Movie ticket offers', 'Dining privileges', 'Milestone benefits'] }
        ];
    } else if (score >= 700) {
        cards = [
            { name: 'Axis Flipkart', type: 'Standard', features: ['4% cashback on Flipkart', 'Unlimited cashback', 'No annual fee', 'Contactless payment'] },
            { name: 'HDFC MoneyBack', type: 'Standard', features: ['Cashback on online shopping', 'Fuel surcharge waiver', 'Reward points', 'Easy EMI options'] },
            { name: 'SBI SimplyCLICK', type: 'Standard', features: ['10X rewards online', 'Movie vouchers', 'Dining offers', 'Low annual fee'] }
        ];
    } else {
        cards = [
            { name: 'ICICI Coral', type: 'Basic', features: ['Reward points', 'Fuel benefits', 'Dining offers', 'Easy approval'] },
            { name: 'Axis MyZone', type: 'Basic', features: ['Cashback on dining', 'Movie discounts', 'No joining fee', 'Flexible credit limit'] },
            { name: 'HDFC Freedom', type: 'Basic', features: ['Cashback rewards', 'Fuel waiver', 'EMI conversion', 'Online shopping benefits'] }
        ];
    }
    cardsContainer.innerHTML = cards.map(card => `
        <div class="card-item">
            <div class="card-header-custom">
                <div class="card-name">${card.name}</div>
                <div class="card-badge">${card.type}</div>
            </div>
            <div class="card-features">
                ${card.features.map(feature => `
                    <div class="feature-item">
                        <i class="fas fa-check-circle"></i>
                        <span>${feature}</span>
                    </div>
                `).join('')}
            </div>
            <button class="btn-apply" onclick="openApplicationModal('${card.name}')">
                <i class="fas fa-credit-card"></i> Apply Now
            </button>
        </div>
    `).join('');
}

let currentCardName = '';
function openApplicationModal(cardName) {
    currentCardName = cardName;
    document.getElementById('modalCardName').textContent = `Apply for ${cardName}`;
    const modal = new bootstrap.Modal(document.getElementById('applicationModal'));
    modal.show();
}

document.getElementById('applicationForm').addEventListener('submit', function (e) {
    e.preventDefault();
    const userName = document.getElementById('userName').value;
    const userEmail = document.getElementById('userEmail').value;
    const userPhone = document.getElementById('userPhone').value;
    const userAddress = document.getElementById('userAddress').value;
    const application = {
        id: Date.now(),
        cardName: currentCardName,
        userName: userName,
        userEmail: userEmail,
        userPhone: userPhone,
        userAddress: userAddress,
        appliedDate: new Date().toLocaleDateString(),
        timestamp: new Date().toISOString()
    };
    let applications = JSON.parse(localStorage.getItem('creditCardApplications')) || [];
    applications.push(application);
    localStorage.setItem('creditCardApplications', JSON.stringify(applications));
    displayAppliedCards();
    const modal = bootstrap.Modal.getInstance(document.getElementById('applicationModal'));
    modal.hide();
    this.reset();
    alert(`Application submitted successfully for ${currentCardName}! We'll contact you at ${userEmail} soon.`);
});

function displayAppliedCards() {
    const appliedCardsSection = document.getElementById('appliedCardsSection');
    const appliedCardsContainer = document.getElementById('appliedCardsContainer');
    let applications = JSON.parse(localStorage.getItem('creditCardApplications')) || [];
    if (applications.length === 0) {
        appliedCardsSection.style.display = 'none';
        return;
    }
    appliedCardsContainer.innerHTML = applications.map(app => `
        <div class="applied-card-item">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                <div><strong>${app.cardName}</strong></div>
                <span class="badge-applied">Applied on ${app.appliedDate}</span>
            </div>
        </div>
    `).join('');
    appliedCardsSection.style.display = 'block';
}

window.addEventListener('DOMContentLoaded', function () {
    displayAppliedCards();
});

document.getElementById('contactForm').addEventListener('submit', function (e) {
    e.preventDefault();
    const contactData = {
        name: this.querySelector('input[type="text"]').value,
        email: this.querySelector('input[type="email"]').value,
        message: this.querySelector('textarea').value,
        timestamp: new Date().toISOString()
    };
    let contacts = JSON.parse(localStorage.getItem('contactSubmissions')) || [];
    contacts.push(contactData);
    localStorage.setItem('contactSubmissions', JSON.stringify(contacts));
    alert('Thank you for contacting us! We will get back to you soon.');
    this.reset();
});

document.getElementById('panInput').addEventListener('input', function (e) {
    this.value = this.value.toUpperCase();
});
